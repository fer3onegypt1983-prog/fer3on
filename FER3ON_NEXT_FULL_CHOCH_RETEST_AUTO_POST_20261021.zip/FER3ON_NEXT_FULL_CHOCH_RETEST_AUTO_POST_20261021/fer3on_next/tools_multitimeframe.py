from __future__ import annotations
import json, sys
from pathlib import Path
from fer3on_next.backtest import load_csv, run
from fer3on_next.domain import BotConfig
from fer3on_next.acceptance import AcceptancePolicy, evaluate_walk_forward

STRATEGIES=('DONCHIAN','FVG','ORDER_BLOCK')
TIMEFRAMES=('1m','5m','15m','30m','1h','4h','1d','1w','1Month')

def windows(n: int):
    if n >= 5000: return 1500,500,500
    if n >= 1000: return 600,200,200
    if n >= 300: return 200,50,50
    return max(40,n//2), max(20,n//5), max(10,n//5)

def run_one(path: Path, name: str):
    candles=load_csv(path); n=len(candles); train,test,step=windows(n); folds=[]; trade_rows=[]; start=0
    while start+train+test<=n:
        segment=candles[start:start+train+test]
        cfg=BotConfig(primary_strategy=name,active_strategies=(name,))
        result=run(segment,cfg,1000.0,start_at=train,data_source=f'kaggle_xauusd_{path.stem}')
        gp=sum(t.pnl for t in result['trades'] if t.pnl and t.pnl>0); gl=-sum(t.pnl for t in result['trades'] if t.pnl and t.pnl<0)
        folds.append({'trades':result['trade_count'],'wins':result['wins'],'losses':result['losses'],'gross_profit':gp,'gross_loss':gl,'net_pnl':result['net_pnl'],'max_drawdown':result['max_drawdown'],'wait_reasons':result['wait_reasons']})
        trade_rows.extend({'pnl':t.pnl} for t in result['trades']); start+=step
    gate=evaluate_walk_forward(folds,trade_rows,AcceptancePolicy.final())
    return {'timeframe':path.stem.replace('xauusd_',''),'rows':n,'train':train,'test':test,'folds':len(folds),'trades':sum(x['trades'] for x in folds),'net_pnl':sum(x['net_pnl'] for x in folds),'profit_factor':(sum(x['gross_profit'] for x in folds)/sum(x['gross_loss'] for x in folds)) if sum(x['gross_loss'] for x in folds) else None,'exploration_pass':gate['exploration_pass'],'production_eligible':gate['production_eligible'],'acceptance':gate}

def main(data_dir: str, output: str):
    root=Path(data_dir); report={'source':str(root),'strategies':{}}
    for tf in TIMEFRAMES:
        path=root/f'xauusd_{tf}.csv'
        if not path.exists(): report['strategies'][tf]={'status':'MISSING'}; continue
        # 1m is intentionally reported as pending for the full engine until the chunked runner is used.
        if tf=='1m': report['strategies'][tf]={'status':'PENDING_CHUNKED_FULL_RUN','rows':sum(1 for _ in path.open())-1}; continue
        for name in STRATEGIES:
            report['strategies'].setdefault(tf,{})[name]=run_one(path,name)
    Path(output).write_text(json.dumps(report,indent=2,default=str)); return report

if __name__=='__main__':
    if len(sys.argv)!=3: raise SystemExit('usage: tools_multitimeframe.py NORMALIZED_DIR REPORT_JSON')
    print(json.dumps(main(*sys.argv[1:]),indent=2,default=str))
