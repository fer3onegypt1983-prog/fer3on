#!/usr/bin/env python3
"""Post-analysis of closed trades; observational only, never a strategy or broker path.

Example:
  python tools/trade_post_analysis.py \
    --trades reports/stage6/.../trades_tsm.csv \
    --candles data/xauusd_15m.csv \
    --out reports/post_analysis_tsm

The tool expects trade columns named entry_time/exit_time, side, fill_open or
entry, stop, target, exit, exit_reason/reason. Candle CSV needs time (or
 timestamp/date) and open/high/low/close.
"""
from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def dt(value: str) -> datetime:
    value = (value or "").strip().replace("Z", "+00:00")
    parsed = datetime.fromisoformat(value)
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def num(row: dict[str, Any], *names: str, default: float | None = None) -> float | None:
    for name in names:
        value = row.get(name)
        if value not in (None, ""):
            return float(value)
    return default


def load_candles(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open(newline="", encoding="utf-8-sig") as stream:
        for raw in csv.DictReader(stream):
            raw_time = raw.get("time") or raw.get("timestamp") or raw.get("date")
            if not raw_time:
                continue
            try:
                t = dt(raw_time)
                rows.append({"time": t, "open": float(raw["open"]),
                             "high": float(raw["high"]), "low": float(raw["low"]),
                             "close": float(raw["close"])})
            except (KeyError, TypeError, ValueError):
                continue
    return sorted(rows, key=lambda row: row["time"])


def analyse_trade(trade: dict[str, Any], candles: list[dict[str, Any]], post_exit_bars: int) -> dict[str, Any]:
    entry_time = dt(trade.get("entry_time") or trade.get("signal_time") or "")
    exit_time_raw = trade.get("exit_time")
    exit_time = dt(exit_time_raw) if exit_time_raw else entry_time
    side = str(trade.get("side") or "").upper()
    entry = num(trade, "fill_open", "entry", "signal_close_entry")
    stop = num(trade, "stop")
    target = num(trade, "target")
    exit_price = num(trade, "exit")
    if entry is None or stop is None or target is None:
        raise ValueError("trade is missing entry/stop/target")
    risk = abs(entry - stop)
    if risk <= 0 or side not in {"BUY", "SELL"}:
        raise ValueError("trade has invalid side or stop distance")

    holding = [c for c in candles if entry_time <= c["time"] <= exit_time]
    after = [c for c in candles if c["time"] > exit_time][:max(0, post_exit_bars)]
    if not holding:
        holding = [c for c in candles if c["time"] >= entry_time][:1]

    if side == "BUY":
        mfe = max((c["high"] - entry for c in holding), default=0.0)
        mae = max((entry - c["low"] for c in holding), default=0.0)
        target_after = any(c["high"] >= target for c in after)
        target_same = any(c["high"] >= target for c in holding if c["time"] == exit_time)
        stop_breached = any(c["low"] <= stop for c in holding)
    else:
        mfe = max((entry - c["low"] for c in holding), default=0.0)
        mae = max((c["high"] - entry for c in holding), default=0.0)
        target_after = any(c["low"] <= target for c in after)
        target_same = any(c["low"] <= target for c in holding if c["time"] == exit_time)
        stop_breached = any(c["high"] >= stop for c in holding)

    exit_reason = str(trade.get("exit_reason") or trade.get("reason") or "").upper()
    is_loss = exit_reason in {"STOP", "AMBIGUOUS_STOP_FIRST", "LOSS"} or (num(trade, "normalized_pnl", "pnl", default=0.0) or 0.0) < 0
    return {
        **trade,
        "mfe_price": round(mfe, 8),
        "mae_price": round(mae, 8),
        "mfe_r": round(mfe / risk, 6),
        "mae_r": round(mae / risk, 6),
        "holding_bars": len(holding),
        "post_exit_bars_checked": len(after),
        "stop_breached_during_holding": stop_breached,
        "target_reached_same_exit_candle": target_same,
        "target_reached_after_exit": target_after,
        "target_reached_after_stop": bool(is_loss and (target_same or target_after)),
        "target_reached_after_stop_within_window": bool(is_loss and target_after),
        "classification": (
            "AMBIGUOUS_STOP_AND_TARGET_SAME_CANDLE" if is_loss and target_same else
            "STOP_THEN_TARGET_AFTER_EXIT" if is_loss and target_after else
            "STOP_WITHOUT_TARGET_RECLAIM" if is_loss else
            "NON_LOSS"
        ),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Compute MFE/MAE and post-exit path for closed trades")
    parser.add_argument("--trades", required=True, type=Path)
    parser.add_argument("--candles", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path, help="output prefix or directory")
    parser.add_argument("--post-exit-bars", type=int, default=20)
    args = parser.parse_args(argv)
    if args.post_exit_bars < 0:
        parser.error("--post-exit-bars must be non-negative")
    candles = load_candles(args.candles)
    if not candles:
        raise SystemExit("No valid candles found")
    with args.trades.open(newline="", encoding="utf-8-sig") as stream:
        trades = list(csv.DictReader(stream))
    analysed = []
    errors = []
    for index, trade in enumerate(trades):
        try:
            analysed.append(analyse_trade(trade, candles, args.post_exit_bars))
        except (TypeError, ValueError) as exc:
            errors.append({"row": index + 2, "error": str(exc)})

    out = args.out
    out_dir = out if out.suffix == "" else out.parent
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = out.name if out.suffix == "" else out.stem
    csv_path = out_dir / f"{stem}_trades.csv"
    json_path = out_dir / f"{stem}_summary.json"
    fields = sorted({key for row in analysed for key in row})
    with csv_path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(analysed)

    losses = [row for row in analysed if row["classification"] != "NON_LOSS"]
    summary = {
        "schema": "fer3on.trade_post_analysis.v1",
        "trades_input": str(args.trades.resolve()), "candles_input": str(args.candles.resolve()),
        "post_exit_bars": args.post_exit_bars, "trades_read": len(trades),
        "trades_analysed": len(analysed), "errors": errors,
        "losses_analysed": len(losses),
        "mfe_r_mean_losses": (sum(row["mfe_r"] for row in losses) / len(losses)) if losses else None,
        "mae_r_mean_losses": (sum(row["mae_r"] for row in losses) / len(losses)) if losses else None,
        "classifications": {name: sum(row["classification"] == name for row in analysed)
                            for name in ("STOP_WITHOUT_TARGET_RECLAIM", "STOP_THEN_TARGET_AFTER_EXIT",
                                         "AMBIGUOUS_STOP_AND_TARGET_SAME_CANDLE", "NON_LOSS")},
        "annotated_csv": str(csv_path.resolve()),
    }
    json_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
