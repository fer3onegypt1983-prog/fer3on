from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


def analyze(run_dir: Path, costs: tuple[float, ...]) -> dict:
    by_strategy: dict[str, dict] = {}
    for ledger in sorted(run_dir.glob("*_ledger.jsonl")):
        decisions = Counter()
        status = Counter()
        trades: list[float] = []
        strategy = ledger.stem.removesuffix("_ledger").upper()
        with ledger.open(encoding="utf-8") as stream:
            for raw in stream:
                if not raw.strip():
                    continue
                row = json.loads(raw)
                event = row.get("event")
                if event in {"DECISION", "OPPORTUNITY"}:
                    decisions[str(row.get("reason") or "UNKNOWN")] += 1
                    status[str(row.get("status") or row.get("action") or "UNKNOWN")] += 1
                elif event == "TRADE":
                    r = row.get("r_multiple")
                    if r is None:
                        r = row.get("metadata", {}).get("r_multiple")
                    if r is not None:
                        trades.append(float(r))
        gross_wins = sum(x for x in trades if x > 0)
        gross_losses = abs(sum(x for x in trades if x < 0))
        cost_sensitivity = {}
        for cost in costs:
            net = [x - cost for x in trades]
            wins = sum(x for x in net if x > 0)
            losses = abs(sum(x for x in net if x < 0))
            cost_sensitivity[str(cost)] = {
                "total_r": round(sum(net), 6),
                "expectancy_r": round(sum(net) / len(net), 6) if net else None,
                "profit_factor": round(wins / losses, 6) if losses else None,
            }
        by_strategy[strategy] = {
            "decision_count": sum(decisions.values()),
            "trade_count": len(trades),
            "gross_total_r": round(sum(trades), 6),
            "gross_profit_factor": round(gross_wins / gross_losses, 6) if gross_losses else None,
            "status_counts": dict(status),
            "top_rejection_reasons": decisions.most_common(20),
            "cost_sensitivity_r_per_trade": cost_sensitivity,
        }
    return {"run_dir": str(run_dir), "costs_are_synthetic_r_per_trade": True, "strategies": by_strategy}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--costs", default="0,0.05,0.10,0.20")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    costs = tuple(float(x) for x in args.costs.split(",") if x.strip())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(analyze(args.run_dir, costs), indent=2), encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
