from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fer3on_next.stage6_replay import STRATEGY_IDS, load_semicolon_ohlcv, run_replay
from settings import load_settings


def write_csv(path: Path, rows: list[dict]) -> None:
    columns = sorted({key for row in rows for key in row})
    if not columns:
        columns = ["strategy_id", "entry_time", "exit_time", "r_multiple"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description="Exploratory causal M15 replay; no broker-cost qualification")
    parser.add_argument("--data", required=True, help="XAU_15m_data.csv (semicolon delimited)")
    parser.add_argument("--out-dir", default="reports/stage6", help="output parent directory")
    parser.add_argument("--history-bars", type=int, default=512)
    parser.add_argument("--last-bars", type=int, default=4536, help="replay only the newest N rows; 0 explicitly means all rows")
    parser.add_argument("--starting-equity", type=float, default=1.0, help="normalized equity only; not USD")
    parser.add_argument("--strategies", default="all", help="all or comma-separated strategy IDs")
    args = parser.parse_args()

    settings = load_settings()
    if args.strategies.strip().lower() == "all":
        selected = list(STRATEGY_IDS)
    else:
        selected = [part.strip().upper() for part in args.strategies.split(",") if part.strip()]
        if len(selected) != len(set(selected)):
            parser.error("duplicate strategy IDs are not allowed")
        if set(selected) - set(settings.strategies):
            parser.error(f"unknown strategy IDs: {sorted(set(selected) - set(settings.strategies))}")
    data_path = Path(args.data).expanduser().resolve()
    candles, data_digest = load_semicolon_ohlcv(data_path)
    source_rows = len(candles)
    source_first_time = candles[0].time.isoformat()
    source_last_time = candles[-1].time.isoformat()
    if args.last_bars:
        if args.last_bars <= args.history_bars:
            parser.error("--last-bars must be greater than --history-bars")
        candles = candles[-args.last_bars:]
    run_id = datetime.now(timezone.utc).strftime("stage6_%Y%m%dT%H%M%SZ")
    out_dir = Path(args.out_dir).expanduser().resolve() / run_id
    out_dir.mkdir(parents=True, exist_ok=False)

    def progress(index: int, total: int, trade_count: int) -> None:
        print(f"progress bars={index}/{total} trades_closed={trade_count}", flush=True)

    print(f"loaded rows={len(candles)} sha256={data_digest} strategies={','.join(selected)}", flush=True)
    results = run_replay(
        candles, settings.strategies, selected=selected,
        starting_equity=args.starting_equity, history_bars=args.history_bars,
        progress_callback=progress,
    )
    results.update({
        "run_id": run_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "data_file_name": data_path.name,
        "data_sha256": data_digest,
        "source_rows": source_rows,
        "source_first_time": source_first_time,
        "source_last_time": source_last_time,
        "replay_rows": len(candles),
        "replay_first_time": candles[0].time.isoformat(),
        "replay_last_time": candles[-1].time.isoformat(),
        "replay_tail_rows_requested": args.last_bars,
        "source_data_qualification": "exploratory only; timezone and broker identity not verified; OHLCV only",
        "settings_sha256": settings.config_sha256,
        "strategy_config_sha256": {name: settings.strategies[name].config_sha256 for name in selected},
        "strategy_versions": {name: settings.strategies[name].version for name in selected},
        "selection_policy": "settings unchanged during replay; do not rank/promote on gross R before costed walk-forward",
        "known_exclusions": [
            "M1 omitted by user request",
            "time-of-day session reference levels disabled due unknown timezone",
            "bid/ask, spread, commission, swap and slippage unavailable",
            "profit/loss expressed only in normalized R; no USD claims",
            "daily/weekly boundaries use source-date clock and remain unverified",
        ],
        "data_folds": {
            "2004-2010": "early historical regime; diagnostic only",
            "2011-2016": "middle historical regime; diagnostic only",
            "2017-2021": "later historical regime; diagnostic only",
            "2022-2026": "recent historical regime; overlaps previously reviewed 4,536-bar sample and is not a pristine holdout",
        },
    })
    for name, payload in results["strategies"].items():
        write_csv(out_dir / f"trades_{name.lower()}.csv", payload.pop("trades_ledger"))
    write_csv(out_dir / "trades_portfolio.csv", sorted(
        [row for name in selected for row in read_trade_file(out_dir, name)],
        key=lambda row: (row["exit_time"], row["entry_time"], row["strategy_id"]),
    ))
    summary_path = out_dir / "summary.json"
    summary_path.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")
    print(f"completed summary={summary_path}", flush=True)
    return 0


def read_trade_file(out_dir: Path, name: str) -> list[dict]:
    path = out_dir / f"trades_{name.lower()}.csv"
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
