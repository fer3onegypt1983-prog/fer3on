from __future__ import annotations

"""FER3ON Next entry point (bootstrap stage).

Inspection and offline CSV backtests never initialize MT5. An explicit --mode
mt5/demo/live selects the account-aware MT5 runner, which opens and manages
orders; LIVE additionally requires a separate exact acknowledgement.
"""

import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import inspect
import json
from pathlib import Path
import sys

from fer3on_next.backtest import load_csv, run as run_backtest
from fer3on_next.identity import BUILD_ID, new_run_id
from fer3on_next.runtime import run_mt5_history_sync_once, run_mt5_history_watch, run_mt5_loop
from settings import AppSettings, SettingsError, load_settings


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="FER3ON Next — safe bootstrap for settings and independent research backtests"
    )
    parser.add_argument("--config", default=None, help="global settings TOML (default: config/settings.toml)")
    parser.add_argument("--mode", choices=("inspect", "backtest", "paper", "history", "history-watch", "mt5", "demo", "live"), default=None)
    parser.add_argument("--strategies", default="all", help="all or comma-separated strategy ids")
    parser.add_argument("--data", help="historical OHLCV CSV; required for backtest/paper modes")
    parser.add_argument("--starting-equity", type=float, default=None, help="override the backtest starting equity")
    parser.add_argument("--once", action="store_true", help="evaluate one closed-candle MT5 cycle and exit")
    parser.add_argument("--interval", type=int, default=60, help="seconds between closed-candle MT5 evaluation cycles")
    parser.add_argument("--history-db", default=None, help="SQLite path for MT5 closed-trade history")
    parser.add_argument("--history-lookback-days", type=int, default=30, help="initial MT5 history import window")
    return parser


def _selected_strategies(settings: AppSettings, requested: str) -> list[str]:
    enabled = settings.enabled_strategies
    if requested.strip().lower() == "all":
        return list(enabled)
    names = [part.strip().upper() for part in requested.split(",") if part.strip()]
    if not names:
        raise SettingsError("--strategies must be 'all' or a comma-separated non-empty list")
    duplicates = sorted({name for name in names if names.count(name) > 1})
    if duplicates:
        raise SettingsError(f"Duplicate strategy id(s): {', '.join(duplicates)}")
    unknown = sorted(set(names) - set(settings.strategies))
    if unknown:
        raise SettingsError(f"Unknown strategy id(s): {', '.join(unknown)}")
    disabled = sorted(name for name in names if not settings.strategies[name].enabled)
    if disabled:
        raise SettingsError(f"Strategy disabled in its own config: {', '.join(disabled)}")
    return names


def _config_summary(settings: AppSettings, selected: list[str]) -> dict:
    return {
        "app": settings.app_name,
        "default_mode": settings.default_mode,
        "config_sha256": settings.config_sha256,
        "symbol": settings.symbol,
        "timeframe": settings.timeframe,
        "mt5_history_db": str(settings.mt5_history_db),
        "selected_strategies": [
            {
                "id": name,
                "enabled": settings.strategies[name].enabled,
                "version": settings.strategies[name].version,
                "strategy_config_sha256": settings.strategies[name].config_sha256,
                "parameters": settings.strategies[name].parameters,
            }
            for name in selected
        ],
        "safety": {
            "mt5_imported": False,
            "mt5_adapter_available": True,
            "orders_sent_during_inspect": False,
            "live_requires_explicit_ack": True,
        },
    }


def _run_offline(settings: AppSettings, selected: list[str], data_path: str, equity: float | None) -> dict:
    csv_path = Path(data_path).expanduser().resolve()
    if not csv_path.is_file():
        raise SettingsError(f"Historical CSV not found: {csv_path}")
    csv_digest = hashlib.sha256(csv_path.read_bytes()).hexdigest()
    candles = load_csv(csv_path)
    if not candles:
        raise SettingsError(f"No OHLCV rows found in {csv_path}")

    start_equity = settings.starting_equity if equity is None else float(equity)
    if start_equity <= 0:
        raise SettingsError("--starting-equity must be greater than zero")
    run_id = new_run_id("bootstrap")
    run_dir = settings.reports_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    results: dict[str, dict] = {}
    for strategy_id in selected:
        profile = settings.strategies[strategy_id]
        strategy_run_id = f"{run_id}-{strategy_id.lower()}"
        journal_path = run_dir / f"{strategy_id.lower()}_ledger.jsonl"
        result = run_backtest(
            candles,
            profile.bot_config,
            starting_equity=start_equity,
            journal_path=journal_path,
            run_id=strategy_run_id,
            data_source="historical_csv_bootstrap",
            strategy_version=profile.version,
        )
        results[strategy_id] = {
            "strategy_version": profile.version,
            "strategy_config_sha256": profile.config_sha256,
            "trade_count": result["trade_count"],
            "wins": result["wins"],
            "losses": result["losses"],
            "net_pnl": result["net_pnl"],
            "profit_factor": result["profit_factor"],
            "max_drawdown": result["max_drawdown"],
            "ending_equity": result["ending_equity"],
            "wait_reasons": result["wait_reasons"],
            "status_counts": result["status_counts"],
            "ledger": journal_path.name,
        }

    report = {
        "schema": "fer3on.bootstrap.backtest.v1",
        "run_id": run_id,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "build_id": BUILD_ID,
        "mode": "offline_backtest",
        "settings_sha256": settings.config_sha256,
        "symbol": settings.symbol,
        "timeframe": settings.timeframe,
        "data_file": str(csv_path),
        "data_sha256": csv_digest,
        "data_rows": len(candles),
        "starting_equity": start_equity,
        "note": "Strategies were backtested separately. This is not MT5 paper/demo/live execution; broker costs and cross-strategy portfolio netting are not qualified by this bootstrap.",
        "strategies": results,
    }
    report_path = run_dir / "summary.json"
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    return {"report_path": str(report_path), "summary": report}


def main(argv: list[str] | None = None) -> int:
    parser = _parser()
    args = parser.parse_args(argv)
    try:
        settings = load_settings(args.config)
        mode = (args.mode or settings.default_mode).lower()
        if args.mode is None and mode in {"history", "history-watch", "mt5", "demo", "live"}:
            raise SettingsError("MT5 connection requires an explicit --mode history/history-watch/demo/mt5/live CLI selection")
        selected = _selected_strategies(settings, args.strategies)

        if mode in {"history", "history-watch"}:
            if args.history_lookback_days < 1 or args.interval < 1:
                raise SettingsError("--history-lookback-days and --interval must be at least 1")
            history_db = args.history_db or settings.mt5_history_db
            if mode == "history":
                result = run_mt5_history_sync_once(settings.symbol, "DEMO", history_db, args.history_lookback_days)
            else:
                result = run_mt5_history_watch(settings.symbol, "DEMO", history_db, args.history_lookback_days, args.interval)
            print(json.dumps(result, indent=2, sort_keys=True))
            return 0

        if mode in {"demo", "live", "mt5"}:
            if args.interval < 1:
                raise SettingsError("--interval must be at least 1 second")
            strategy_configs = {
                name: (settings.strategies[name].bot_config, settings.strategies[name].version)
                for name in selected
            }
            mt5_mode = "AUTO" if mode == "mt5" else mode.upper()
            loop_kwargs = {"mode": mt5_mode, "interval_seconds": args.interval, "once": args.once}
            if "history_db_path" in inspect.signature(run_mt5_loop).parameters:
                loop_kwargs.update({"history_db_path": args.history_db or settings.mt5_history_db,
                                    "history_lookback_days": args.history_lookback_days})
            result = run_mt5_loop(strategy_configs, **loop_kwargs)
            print(json.dumps(result, indent=2, sort_keys=True))
            return 0

        if mode == "paper":
            print(
                "ERROR: streaming PAPER mode is not implemented yet. Use offline --mode backtest "
                "or an explicitly selected --mode mt5/--mode demo/--mode live.",
                file=sys.stderr,
            )
            return 3

        if mode == "inspect":
            print(json.dumps(_config_summary(settings, selected), indent=2, sort_keys=True))
            return 0

        if mode != "backtest":
            raise SettingsError(f"Unsupported mode: {mode}")
        if not args.data:
            parser.error("--data is required for --mode backtest")
        result = _run_offline(settings, selected, args.data, args.starting_equity)
        print(json.dumps({"report_path": result["report_path"], "summary": result["summary"]}, indent=2, sort_keys=True))
        return 0
    except SettingsError as exc:
        print(f"CONFIGURATION ERROR: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"RUN ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
