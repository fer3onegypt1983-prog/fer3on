from __future__ import annotations

"""Backward-compatible launcher; loads enabled strategy profiles from TOML."""

import argparse

from settings import load_settings
from fer3on_next.runtime import run_mt5_loop


parser = argparse.ArgumentParser(description="FER3ON Next account-aware MT5 runner")
parser.add_argument("--mode", choices=("AUTO", "DEMO", "LIVE"), default="AUTO")
parser.add_argument("--once", action="store_true", help="evaluate one closed-candle cycle")
parser.add_argument("--interval", type=int, default=60)
parser.add_argument("--strategies", default="all", help="all or comma-separated strategy ids")
args = parser.parse_args()
settings = load_settings()
selected = settings.enabled_strategies if args.strategies.strip().lower() == "all" else tuple(
    part.strip().upper() for part in args.strategies.split(",") if part.strip()
)
unknown = sorted(set(selected) - set(settings.strategies))
if unknown:
    parser.error(f"Unknown strategy id(s): {', '.join(unknown)}")
strategy_configs = {
    name: (settings.strategies[name].bot_config, settings.strategies[name].version)
    for name in selected
}
run_mt5_loop(strategy_configs, mode=args.mode, interval_seconds=args.interval, once=args.once)
