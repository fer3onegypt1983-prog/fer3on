from __future__ import annotations
import csv,json,sys
from datetime import datetime,timezone
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from fer3on_next.backtest import load_csv,run
from fer3on_next.domain import BotConfig
from fer3on_next.analytics import analyze_opportunities
from fer3on_next.acceptance import AcceptancePolicy,evaluate_walk_forward


def convert(raw_path,csv_path):
    raw=json.loads(Path(raw_path).read_text())['chart']['result'][0]
    q=raw['indicators']['quote'][0]; rows=[]
    for i,t in enumerate(raw['timestamp']):
        vals={k:q[k][i] for k in ('open','high','low','close','volume')}
        if any(v is None for v in vals.values()): continue
        rows.append({'time':datetime.fromtimestamp(t,tz=timezone.utc).isoformat(),**vals})
    with open(csv_path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['time','open','high','low','close','volume']); w.writeheader(); w.writerows(rows)


def walk(candles,cfg,train=1500,test=500,step=500):
    folds=[]; all_opportunities=[]; all_trades=[]; start=0
    while start+train+test<=len(candles):
        segment=candles[start:start+train+test]
        result=run(segment,cfg,1000.0,start_at=train,data_source='historical_ohlcv_walk_forward')
        all_opportunities.extend(result['opportunities'])
        all_trades.extend([{'pnl':t.pnl,'reason':t.reason,'metadata':t.metadata} for t in result['trades']])
        gross_profit=sum(t.pnl for t in result['trades'] if t.pnl and t.pnl>0); gross_loss=-sum(t.pnl for t in result['trades'] if t.pnl and t.pnl<0)
        folds.append({'build_id':result['build_id'],'run_id':result['run_id'],'data_source':result['data_source'],'start':segment[train].time.isoformat(),'end':segment[-1].time.isoformat(),'trades':result['trade_count'],'wins':result['wins'],'losses':result['losses'],'win_rate':result['wins']/result['trade_count'] if result['trade_count'] else None,'gross_profit':gross_profit,'gross_loss':gross_loss,'net_pnl':result['net_pnl'],'profit_factor':result['profit_factor'],'max_drawdown':result['max_drawdown'],'wait_reasons':result['wait_reasons'],'status_counts':result['status_counts']})
        start+=step
    return folds,all_opportunities,all_trades


if __name__=='__main__':
    if len(sys.argv) not in {4,5}:
        raise SystemExit('usage: tools_walk.py RAW_JSON OUTPUT_CSV REPORT_JSON [TSM|DONCHIAN]')
    raw,csv_path,report=sys.argv[1:4]
    strategy=sys.argv[4] if len(sys.argv)==5 else 'TSM'
    convert(raw,csv_path); candles=load_csv(csv_path)
    cfg=BotConfig(primary_strategy=strategy.upper(), active_strategies=(strategy.upper(),))
    folds,opportunities,trade_rows=walk(candles,cfg)
    trades=sum(x['trades'] for x in folds); wins=sum(x['wins'] for x in folds); gp=sum(x['gross_profit'] for x in folds); gl=sum(x['gross_loss'] for x in folds)
    acceptance=evaluate_walk_forward(folds,trade_rows,AcceptancePolicy())
    summary={'build_id':folds[0]['build_id'] if folds else None,'strategy':cfg.primary_strategy,'schema_version':'trade-ledger.v2','data_source':'historical_ohlcv_walk_forward','source':'Yahoo Finance GC=F Gold Futures, 15m, range=60d','instrument_note':'GC=F is COMEX gold futures, not broker-specific XAUUSD spot','candles':len(candles),'folds':len(folds),'trades':trades,'wins':wins,'losses':trades-wins,'win_rate':wins/trades if trades else None,'gross_profit':gp,'gross_loss':gl,'net_pnl_sum':sum(x['net_pnl'] for x in folds),'aggregate_profit_factor':gp/gl if gl else None,'profitable_folds':sum(x['net_pnl']>0 for x in folds),'acceptance':acceptance,'opportunity_analysis':analyze_opportunities(opportunities),'folds_detail':folds}
    Path(report).write_text(json.dumps(summary,indent=2,default=str)); Path(str(report).replace('.json','.ledger.jsonl')).write_text('\n'.join(json.dumps(x,default=str) for x in opportunities)+'\n'); print(json.dumps(summary,indent=2,default=str))
