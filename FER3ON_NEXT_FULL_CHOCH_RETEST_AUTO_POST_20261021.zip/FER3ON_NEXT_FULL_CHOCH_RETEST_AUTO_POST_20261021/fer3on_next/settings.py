from __future__ import annotations

"""Validated settings loader for the FER3ON Next bootstrap.

Loading configuration is side-effect free: this module never initializes MT5
or sends trading orders.
"""

from dataclasses import dataclass, fields
from hashlib import sha256
from pathlib import Path
import tomllib
from typing import Any

from fer3on_next.domain import BotConfig

ROOT = Path(__file__).resolve().parent
DEFAULT_SETTINGS_PATH = ROOT / "config" / "settings.toml"

STRATEGY_PARAMETERS: dict[str, set[str]] = {
    "TSM": {"momentum_lookback", "tsm_require_choch_retest", "tsm_choch_max_age_bars",
             "tsm_choch_retest_tolerance_atr", "tsm_choch_confirmation_body_atr", "tsm_choch_min_score"},
    "DONCHIAN": {
        "donchian_entry_window", "donchian_exit_window",
        "donchian_buffer_atr", "donchian_relaxed_context",
        "donchian_require_retest", "donchian_retest_max_bars",
        "donchian_retest_tolerance_atr", "donchian_min_breakout_body_atr",
        "donchian_max_breakout_body_atr",
    },
    "FVG_MODERATE": {"fvg_min_gap_atr", "fvg_max_age", "fvg_min_displacement_atr"},
    "BOS": set(),
    "ORDER_BLOCK_MODERATE": {
        "ob_max_age", "ob_min_displacement_atr", "ob_max_width_atr",
        "ob_structure_left", "ob_structure_right", "ob_4h_max_age",
        "ob_4h_min_displacement_atr", "ob_4h_max_width_atr",
        "ob_4h_structure_left", "ob_4h_structure_right",
    },
    "LEVEL_MAP_SCENARIO_TREE": {
        "scenario_swing_left", "scenario_swing_right", "scenario_max_levels_each_side",
        "scenario_merge_distance_atr", "scenario_reference_half_width_atr",
        "scenario_approach_distance_atr", "scenario_touch_tolerance_atr",
        "scenario_break_buffer_atr", "scenario_break_min_body_atr",
        "scenario_bounce_confirmation_atr", "scenario_stop_buffer_atr",
        "scenario_min_reward_risk", "scenario_max_retest_bars", "scenario_max_plan_age_bars",
        "scenario_probability_window_days", "scenario_min_probability_samples",
        "scenario_fallback_target_rr",
    },
    "IMPULSE_RETEST": {
        "impulse_min_body_atr", "impulse_max_age_bars", "impulse_confirmation_body_atr",
        "impulse_stop_buffer_atr", "impulse_min_reward_risk",
    },
    "IMPULSE_MIDPOINT_REVERSAL": {
        "impulse_min_body_atr", "impulse_max_age_bars", "impulse_confirmation_body_atr",
        "impulse_stop_buffer_atr", "midpoint_retrace_fraction", "midpoint_min_reward_risk",
    },
    "P2_PULLBACK_CONFIRMATION": {
        "pullback_depth_atr", "pullback_ttl_bars", "pullback_confirmation_body_atr",
        "pullback_min_reward_risk", "pullback_max_risk_atr",
    },
}

STRATEGY_ORDER = (
    "TSM", "DONCHIAN", "FVG_MODERATE", "BOS", "ORDER_BLOCK_MODERATE",
    "LEVEL_MAP_SCENARIO_TREE", "IMPULSE_RETEST", "IMPULSE_MIDPOINT_REVERSAL",
    "P2_PULLBACK_CONFIRMATION",
)

GLOBAL_BOT_FIELDS = {
    "symbol", "timeframe",
    "lookback", "atr_period", "impulse_window", "min_atr",
    "min_reaction_body_atr", "min_displacement_atr", "max_entry_extension",
    "min_target_rr", "target_rr", "cooldown_bars", "spread_limit",
    "allow_short", "session_start_utc", "session_end_utc", "require_market_event",
    "enable_entry_quality_guard", "enable_repeat_thesis_guard",
    "tsm_require_choch_retest", "tsm_choch_max_age_bars", "tsm_choch_retest_tolerance_atr",
    "tsm_choch_confirmation_body_atr", "tsm_choch_min_score",
    "donchian_require_retest", "donchian_retest_max_bars",
    "donchian_retest_tolerance_atr", "donchian_min_breakout_body_atr",
    "donchian_max_breakout_body_atr",
    "enable_volatility_sizing", "volatility_target_atr", "point_value", "max_unit_size",
    "enable_break_even", "break_even_trigger_r", "break_even_buffer_points",
    "enable_partial_profit", "partial_profit_trigger_r", "partial_profit_fraction",
    "enable_strategy_loss_pause", "strategy_loss_pause_fraction", "strategy_loss_pause_hours",
    "h4_conflict_min_confidence", "h1_conflict_min_confidence", "context_level_min_rr",
}
RISK_FIELDS = {"risk_per_trade", "max_daily_loss", "max_daily_loss_cash", "max_concurrent"}
TIMEFRAMES = {"M1", "M5", "M15", "M30", "H1", "H4", "D1"}
MODES = {"inspect", "backtest", "paper", "demo", "live"}


class SettingsError(ValueError):
    """Raised for malformed, ambiguous, or unsupported configuration."""


@dataclass(frozen=True)
class StrategyProfile:
    strategy_id: str
    enabled: bool
    version: str
    parameters: dict[str, Any]
    bot_config: BotConfig
    config_path: Path
    config_sha256: str


@dataclass(frozen=True)
class AppSettings:
    settings_path: Path
    app_name: str
    default_mode: str
    symbol: str
    timeframe: str
    starting_equity: float
    spread: float
    reports_dir: Path
    mt5_history_db: Path
    strategies: dict[str, StrategyProfile]
    config_sha256: str

    @property
    def enabled_strategies(self) -> tuple[str, ...]:
        return tuple(k for k in STRATEGY_ORDER if k in self.strategies and self.strategies[k].enabled)


def _read_toml(path: Path) -> dict[str, Any]:
    try:
        with path.open("rb") as stream:
            value = tomllib.load(stream)
    except FileNotFoundError as exc:
        raise SettingsError(f"Settings file not found: {path}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise SettingsError(f"Invalid TOML in {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SettingsError(f"Expected TOML tables in {path}")
    return value


def _check_unknown(table: dict[str, Any], allowed: set[str], label: str) -> None:
    unknown = sorted(set(table) - allowed)
    if unknown:
        raise SettingsError(f"Unknown {label} key(s): {', '.join(unknown)}")


def _coerce(name: str, value: Any, default: Any, label: str) -> Any:
    if isinstance(default, bool):
        if type(value) is not bool:
            raise SettingsError(f"{label}.{name} must be true or false")
        return value
    if isinstance(default, int):
        if type(value) is not int:
            raise SettingsError(f"{label}.{name} must be an integer")
        return value
    if isinstance(default, float):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise SettingsError(f"{label}.{name} must be numeric")
        return float(value)
    if isinstance(default, str):
        if not isinstance(value, str):
            raise SettingsError(f"{label}.{name} must be text")
        return value
    raise SettingsError(f"Unsupported setting type for {name}")


def _load_strategy(path: Path, defaults: dict[str, Any], shared: dict[str, Any]) -> StrategyProfile:
    raw = _read_toml(path)
    _check_unknown(raw, {"strategy", "parameters"}, str(path))
    identity, parameters = raw.get("strategy"), raw.get("parameters", {})
    if not isinstance(identity, dict) or not isinstance(parameters, dict):
        raise SettingsError(f"{path}: expected [strategy] and [parameters] tables")
    _check_unknown(identity, {"id", "enabled", "version", "description"}, f"{path} [strategy]")

    raw_id = identity.get("id")
    if not isinstance(raw_id, str) or raw_id.upper().strip() not in STRATEGY_PARAMETERS:
        raise SettingsError(f"{path}: strategy.id must be one of {sorted(STRATEGY_PARAMETERS)}")
    strategy_id = raw_id.upper().strip()
    enabled = identity.get("enabled", True)
    version = identity.get("version", "baseline-1")
    if type(enabled) is not bool:
        raise SettingsError(f"{path}: strategy.enabled must be true or false")
    if not isinstance(version, str) or not version.strip():
        raise SettingsError(f"{path}: strategy.version must be non-empty text")
    _check_unknown(parameters, STRATEGY_PARAMETERS[strategy_id], f"{path} [parameters]")

    values = dict(defaults)
    values.update(shared)
    for name, value in parameters.items():
        values[name] = _coerce(name, value, defaults[name], f"{strategy_id}.parameters")
    # A profile always evaluates its own strategy only; the portfolio layer is a later phase.
    values["primary_strategy"] = strategy_id
    values["active_strategies"] = (strategy_id,)
    try:
        bot_config = BotConfig(**values)
    except (TypeError, ValueError) as exc:
        raise SettingsError(f"Invalid BotConfig for {strategy_id}: {exc}") from exc

    return StrategyProfile(
        strategy_id=strategy_id,
        enabled=enabled,
        version=version.strip(),
        parameters=dict(parameters),
        bot_config=bot_config,
        config_path=path,
        config_sha256=sha256(path.read_bytes()).hexdigest(),
    )


def load_settings(path: str | Path | None = None) -> AppSettings:
    """Load global and strategy settings; never imports MT5 or opens a broker."""
    settings_path = Path(path) if path is not None else DEFAULT_SETTINGS_PATH
    if not settings_path.is_absolute():
        settings_path = ROOT / settings_path
    settings_path = settings_path.resolve()
    raw = _read_toml(settings_path)
    allowed_sections = {"application", "bot", "risk", "backtest", "paths"}
    _check_unknown(raw, allowed_sections, str(settings_path))
    sections = {key: raw.get(key, {}) for key in allowed_sections}
    if any(not isinstance(value, dict) for value in sections.values()):
        raise SettingsError("Each configuration section must be a TOML table")
    _check_unknown(sections["application"], {"name", "default_mode"}, "[application]")
    _check_unknown(sections["bot"], GLOBAL_BOT_FIELDS, "[bot]")
    _check_unknown(sections["risk"], RISK_FIELDS, "[risk]")
    _check_unknown(sections["backtest"], {"starting_equity", "spread"}, "[backtest]")
    _check_unknown(sections["paths"], {"reports_dir", "mt5_history_db"}, "[paths]")

    app_name = sections["application"].get("name", "FER3ON Next")
    if not isinstance(app_name, str) or not app_name.strip():
        raise SettingsError("[application].name must be non-empty text")
    default_mode = str(sections["application"].get("default_mode", "inspect")).lower()
    if default_mode not in MODES:
        raise SettingsError(f"default_mode must be one of {sorted(MODES)}")

    defaults = {item.name: item.default for item in fields(BotConfig)}
    shared: dict[str, Any] = {}
    for section_name in ("bot", "risk"):
        for name, value in sections[section_name].items():
            shared[name] = _coerce(name, value, defaults[name], f"[{section_name}]")

    symbol = shared.get("symbol", defaults["symbol"])
    timeframe = shared.get("timeframe", defaults["timeframe"]).upper()
    if not isinstance(symbol, str) or not symbol.strip():
        raise SettingsError("[bot].symbol must be non-empty text")
    if timeframe not in TIMEFRAMES:
        raise SettingsError(f"[bot].timeframe must be one of {sorted(TIMEFRAMES)}")
    if not 0 < shared.get("risk_per_trade", defaults["risk_per_trade"]) <= 1:
        raise SettingsError("risk_per_trade must be in (0, 1]")
    if not 0 < shared.get("max_daily_loss", defaults["max_daily_loss"]) <= 1:
        raise SettingsError("max_daily_loss must be in (0, 1]")
    if shared.get("max_concurrent", defaults["max_concurrent"]) < 1:
        raise SettingsError("max_concurrent must be at least 1")

    starting_equity = sections["backtest"].get("starting_equity", 1000.0)
    spread = sections["backtest"].get("spread", 0.0)
    for key, value in (("starting_equity", starting_equity), ("spread", spread)):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise SettingsError(f"[backtest].{key} must be numeric")
    starting_equity, spread = float(starting_equity), float(spread)
    if starting_equity <= 0 or spread < 0:
        raise SettingsError("starting_equity must be positive and spread non-negative")

    strategy_dir = ROOT / "config" / "strategies"
    files = sorted(strategy_dir.glob("*.toml"))
    if not files:
        raise SettingsError(f"No strategy configuration files found under {strategy_dir}")
    strategies: dict[str, StrategyProfile] = {}
    for strategy_path in files:
        profile = _load_strategy(strategy_path, defaults, shared)
        if profile.strategy_id in strategies:
            raise SettingsError(f"Duplicate strategy id: {profile.strategy_id}")
        strategies[profile.strategy_id] = profile

    reports_value = sections["paths"].get("reports_dir", "reports/runs")
    if not isinstance(reports_value, str) or not reports_value.strip():
        raise SettingsError("[paths].reports_dir must be a non-empty path")
    reports_dir = Path(reports_value)
    if not reports_dir.is_absolute():
        reports_dir = ROOT / reports_dir

    history_value = sections["paths"].get("mt5_history_db", "reports/mt5_closed_trades.sqlite3")
    if not isinstance(history_value, str) or not history_value.strip():
        raise SettingsError("[paths].mt5_history_db must be a non-empty path")
    history_db = Path(history_value)
    if not history_db.is_absolute():
        history_db = ROOT / history_db

    digest = sha256(settings_path.read_bytes())
    for strategy_path in files:
        digest.update(strategy_path.name.encode("utf-8"))
        digest.update(strategy_path.read_bytes())
    return AppSettings(
        settings_path=settings_path,
        app_name=app_name.strip(),
        default_mode=default_mode,
        symbol=symbol.strip(),
        timeframe=timeframe,
        starting_equity=starting_equity,
        spread=spread,
        reports_dir=reports_dir.resolve(),
        mt5_history_db=history_db.resolve(),
        strategies=strategies,
        config_sha256=digest.hexdigest(),
    )
