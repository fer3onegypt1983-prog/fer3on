# تقرير بحثي: المناهج التي تستحق الاختبار في FER3ON Next على XAUUSD

**نطاق التقرير:** هذا التقرير يترجم نتائج الأبحاث المستقلة المعطاة إلى ترتيب بحثي قابل للتنفيذ على XAUUSD فقط. وهو لا يثبت ربحية أي منهج، ولا يقدّم توصية استثمارية، ولا يجيز التداول الحقيقي. لم تُعدّل ملفات كود التداول.

## الخلاصة التنفيذية

المنهج الذي يستحق أولوية الاختبار هو **قرار واحد فقط من LONG أو SHORT أو FLAT** مبني على إشارة اتجاه زمنية بسيطة، مع وقف خسارة بنيوي تكيفي، وتحجيم مخاطرة محدود، وتنفيذ مؤجل ومكلف بصورة محافظة. الدافع هو أن أدلة time-series momentum الأصلية واسعة وطويلة تاريخياً، لكنها مبنية غالباً على عقود آجلة ومحافظ متعددة الأصول، لا على XAUUSD الفوري أو عقد CFD لدى وسيط محدد. لذلك فهي تبرر فرضية اختبار، ولا تبرر نقل النتيجة إلى الذهب مباشرة. [1] [2] [3]

يأتي **Donchian/trend-breakout** كبديل بسيط قابل للمقارنة، لا كحقيقة مثبتة. أما **تحجيم التقلب** فيدخل بوصفه طبقة لإدارة المخاطر فقط، لا إشارة اتجاه مستقلة؛ فالدليل على فائدته مختلط خارج العينة، وقد يؤدي إلى زيادة التعرض عندما يضيق الوقف أو ينخفض التقلب بصورة خادعة. [4] [5] [6]

يستحق **mean reversion/statistical arbitrage** اختباراً مشروطاً فقط. لا يدخل هذا المسار في الاختبار الرئيسي إلا إذا وُجدت علاقة أو spread محدد، قابل للقياس، ومستقر حديثاً، مع اختبار structural break وhedge ratio وhalf-life. وتبقى النتائج التاريخية في الأسهم أو النفط غير قابلة للنقل تلقائياً إلى XAUUSD. [7] [8] [9] [10]

أما **order-flow imbalance (OFI)، وmulti-level OFI، وVPIN، وحجم التداول** فتدخل في Shadow أو A/B فقط ما لم تتوافر بيانات حقيقية ومؤرخة للصفقات ودفتر الأوامر من مصدر XAUUSD المستهدف. بيانات tick volume أو حجم عقد COMEX GC ليست بديلاً عن دفتر XAUUSD الفوري لدى الوسيط. [11] [12] [13] [14]

معيار القبول ليس win rate، ولا Sharpe داخل العينة، ولا أفضل parameter set. يجب أن يبقى **صافي expectancy موجباً** بعد spread وslippage وcommission وfinancing أو swap، وأن يكون profit factor وmax drawdown وloss streak والاستقرار عبر الفترات مقبولاً في holdout لم يُستخدم في الضبط. كما يجب تسجيل عدد التجارب وتصحيح أثر البحث المتعدد؛ فاحتمال أن يكون أفضل backtest ناتجاً عن الاختيار وحده يرتفع بسرعة مع كثرة النماذج. [15] [16] [17] [18]

## 1. ما الذي يثبته الدليل، وما الذي لا يثبته؟

تثبت دراسة Moskowitz وOoi وPedersen أن العائد السابق لمدة تقارب 12 شهراً كان مرتبطاً إيجابياً بالعائد التالي في 58 أداة سائلة عبر مؤشرات الأسهم والعملات والسلع والسندات، مع استمرار الإشارة تقريباً سنة ثم انعكاس جزئي في الآفاق الأطول. هذه نتيجة تاريخية مهمة لفرضية time-series momentum، لكنها لا تثبت أن XAUUSD الفوري مربح، ولا أن تكاليف وسيط بعينه تسمح باستخراجه. [1]

وتوسع دراسة Hurst وOoi وPedersen الاختبار إلى 67 سوقاً خلال 1880–2016، وتستخدم إشارات 1 و3 و12 شهراً واستهداف تقلب 10%. إلا أن الدراسة نفسها تحذر من عدم يقين التكاليف، ومن عدم احتساب بعض تكاليف rolling futures كاملاً؛ لذلك لا يصح قراءة الأداء التاريخي الإجمالي على أنه صافي تنفيذ متاح في XAUUSD. [2]

في المقابل، تعيد دراسة Huang وLi وWang وZhou فحص الدليل خارج العينة على مستوى الأصل. فقد استخدمت أول 15 سنة للتدريب واختبرت 2000–2015، ووجدت أن 45 من 55 أصلاً كان لها R² خارج العينة سالباً، مع متوسط يقارب −0.67%، وثلاثة أصول فقط موجبة ومعنوية عند 10%. هذا لا ينفي وجود أثر تاريخي في كل سياق، لكنه يمنع وصفه بأنه دليل أكاديمي متفق عليه أو أنه ينتقل تلقائياً إلى عقد منفرد. [3]

وتؤكد الأدلة الصناعية أن trend following قد يمتلك skew موجباً أو أداءً تاريخياً في بيئات أزمات، لكنها توثق أيضاً whipsaw وdrawdown وفشل الإشارة عندما يكون الانعكاس أسرع من نافذة الاتجاه. فقد أبلغ Man Group أن عائد SG Trend المتحرك 12 شهراً بلغ −18.6% حتى 30 أبريل 2025، مع خسارة سابقة −16.0% في يناير 2019. هذه أرقام لتحديد سيناريوهات الفشل، لا وعد بأن الخسارة ستنعكس حتماً. [19]

كما أن وجود win rate مرتفع لا يثبت edge. فالربحية تعتمد على payoff ratio، وحجم الخسائر الذيلية، ومدة الصفقات، والتكاليف، والرافعة، والانزلاق، والقدرة على التنفيذ. قد يعوض عدد قليل من الاتجاهات الكبيرة سلسلة خسائر صغيرة في trend following، وقد تخفي mean reversion خسارة نادرة كبيرة خلف نسبة صفقات رابحة مرتفعة. [1] [7] [16]

## 2. ترتيب الأولوية لـ FER3ON Next

### أ. المسار الأساسي: يدخل في الاختبار الرئيسي

**1) Time-series momentum بإشارة واحدة.** يبدأ الاختبار بإشارات اتجاه مشتقة من عائد XAUUSD السابق على نوافذ محددة مسبقاً، مثل 1 و3 و12 شهراً أو نسخ يومية مكافئة. لا تُختار النافذة الأفضل بعد رؤية النتائج. ويمكن مقارنة الإشارة الموحّدة بنسخة أبطأ لتقليل turnover والتكلفة. هذه صياغة اختبارية مستوحاة من الأدلة الأصلية، وليست ادعاءً بأن النوافذ نفسها مثلى للذهب. [1] [2] [3]

**2) Donchian كخط أساس بديل، لا كفلتر إضافي تلقائي.** تُختبر نسخ 20/10 و55/20، حيث يعني الرقم الأول طول قناة الدخول والثاني طول قناة الخروج، مع استبعاد الشمعة الحالية ومنع look-ahead. هذه القيم مأخوذة من تعريف Turtle تطبيقي على SAFEX، ولذلك يجب اعتبارها فرضيات مجمدة لا معلمات مثبتة لـXAUUSD. [20]

**3) وقف خسارة بنيوي تكيفي.** يحدد الوقف خلف آخر swing أو مستوى إبطال structure صالح عند لحظة القرار، مع buffer مرتبط بالتقلب والسبريد. لا يجوز توسيع المخاطرة بعد الدخول لجعل الصفقة تبدو أفضل، ويجب تسجيل سبب كل تعديل. الوقف ليس ضماناً للتعبئة عند السعر المحدد، خصوصاً أثناء gap أو خبر؛ لذلك يحسب الاختبار خسارة تتجاوز R النظري في سيناريوهات الضغط. [2] [19] [21]

**4) تحجيم مخاطرة محكوم، لا Kelly كامل.** الصيغة العملية الأولية هي:

> `R_per_unit = مسافة الوقف × قيمة النقطة/الأونصة + تكلفة الدخول والخروج المقدرة`
>
> `الحجم = min(risk_budget / R_per_unit, exposure_cap, margin_cap)`

يُختبر تحجيم ثابت صغير مقابل EWMA/ATR بطيء يستخدم بيانات متاحة قبل القرار فقط. ويجب منع انخفاض مسافة الوقف أو انخفاض التقلب من رفع الحجم فوق سقف التعرض. يدعم بعض الدليل تحجيم التعرض عكسياً مع التقلب، لكن نتائج خارج العينة تشير إلى أنه ليس تفوقاً عاماً ولا حماية دائمة. [4] [5] [6]

**5) سياق structure/trend/levels/events.** تفصل المنظومة بين بنية السعر، وإشارة الاتجاه، والمستوى التنفيذي، وحدث السوق. لا يُسمح للرواية الإخبارية أو الانطباع اليدوي أن يغير القرار خارج قاعدة معلنة. ويمكن جعل event window وspread وgap مرشحات جودة تنفيذ أو أسباباً لـFLAT، لا إشارات اتجاه مستقلة. [21] [22]

### ب. مسار مشروط: يدخل في A/B أو Shadow بعد إثبات متطلبات البيانات

**1) Mean reversion وstatistical arbitrage.** لا يُسمح بصفقة ارتداد لمجرد ارتفاع z-score. يجب أولاً تحديد spread أو residual أو hedge ratio، وقياس stationarity وhalf-life واختبار break على نافذة rolling. إذا فشلت العلاقة أو استمر spread في الاتساع تحت trend قوي، يكون القرار NO_TRADE. أظهر Fanelli وآخرون أن علاقة عقود النفط تعرضت لـstructural break، وأظهرت أعمال Avellaneda وLee أن drawdown المفاجئ ممكن حتى في استراتيجية تبدو market-neutral. [7] [8] [9]

**2) volatility regime.** يمكن وسم low/normal/high باستخدام EWMA أو ATR أو نموذج regime محدد مسبقاً، ثم استخدام الوسم لتخفيض الحجم أو حظر التنفيذ عند سيولة رديئة. لا يدخل regime كإشارة دخول مستقلة في النسخة الأولى. كما تُقارن كل نسخة بنسخة no-regime؛ وإلا يصعب فصل أثر المرشح عن أثر الاتجاه الأساسي. [4] [6] [23]

**3) OFI وMLOFI والميزات المجهرية.** يمكن إدخالها في A/B بوصفها تأكيداً أو مرشح سيولة فقط. الأدلة على OFI تقيس علاقة قصيرة بين أحداث دفتر الأوامر وتغير mid-price في أسهم أو دفاتر أوامر مركزية، وبعضها أظهر تحسناً خارج العينة مع مستويات أعمق، لكنه لا يثبت ربحاً صافياً في XAUUSD OTC. يجب فرض lag، وتضمين bid/ask وpartial fills وlatency، واستخدام Ridge أو نموذج بسيط عند كثرة الميزات. [11] [12] [13]

**4) VPIN أو imbalance المرتبط بتسمم التدفق.** يبقى Shadow لأنه حساس لطول bucket، وطريقة تصنيف الصفقات، وتعريف volume. يمكن استخدامه لتخفيض التعرض عند toxic-flow أو اتساع السبريد، لا كإنذار حتمي للانهيار أو كمولد اتجاه. [14]

### ج. يبقى Shadow/A-B حتى تتوافر أدلة مستقلة

يبقى أي نموذج ML متعدد الميزات، أو Markov switching، أو مرشح سريع للغاية، أو دمج يضيف مؤشرات كثيرة، في Shadow/A-B. السبب ليس أن هذه الأدوات مستحيلة، بل أن كل درجة حرية إضافية توسّع فضاء التجارب واحتمال أن يكون الأداء الأفضل نتيجة انتقاء. يجب أن يكون لكل Build مواصفات ثابتة وBUILD_ID جديد، وأن تظهر نتائج كل المحاولات لا أفضل مسار فقط. [15] [16] [17]

يبقى استخدام حجم COMEX GC أو open interest كمتغير سياقي في Shadow فقط. تذكر CME أن عقد GC مركزي وشبه مستمر وبحجم كبير، لكن ذلك لا يمثل تلقائياً حجم أو عمق spot XAUUSD لدى وسيط معين. يمكن أن يكون GC proxy للسياق الكلي، ولا يمكن وصفه بأنه volume XAUUSD. [24]

### د. يرفض في نطاق المشروع

يُرفض ادعاء أن win rate المرتفع أو R² أو p-value وحده يثبت الربحية. ويُرفض نقل نتائج futures أو الأسهم أو النفط إلى XAUUSD دون اختبار خاص بالرمز والوسيط. ويُرفض backtest باستخدام mid فقط أو تعبئة مثالية أو تكلفة ثابتة متفائلة. كما يُرفض تعديل lookback أو SL أو event guard بعد رؤية holdout، وتحويل Demo إلى تصريح بالتداول الحقيقي. [3] [9] [15] [18]

يُرفض أيضاً ادعاء **OFI أو VPIN أو volume حقيقي** إذا لم توجد بيانات DOM/L2 أو trade prints ذات timestamps موثوقة. لا يمكن إثبات منهج order-flow على XAUUSD الفوري باستخدام OHLC أو tick volume وحده؛ يمكن فقط اختبار proxy موسوم بوضوح، أو إبقاء الفرضية Shadow. [11] [12] [13] [14]

## 3. جدول المقارنة والأولوية

| المنهج | نوع الدليل | فرضية الاختبار على XAUUSD | متطلبات البيانات | القرار في FER3ON Next | سبب القبول أو التأجيل |
|---|---|---|---|---|---|
| Time-series momentum البسيط | أكاديمي واسع، لكن غير خاص بـXAUUSD | sign لعائد 1/3/12 شهراً، بإشارة واحدة وتنفيذ t+1 | OHLC موثوق، bid/ask للتنفيذ | **أولوية P0** | أبسط فرضية قابلة للتفنيد، مع نزاع حقيقي حول OOS على مستوى الأصل [1] [2] [3] |
| Donchian 20/10 و55/20 | تطبيق جامعي على SAFEX، لا دليل ذهب مباشر | اختراق قناة سابقة مع خروج محدد | OHLC، spread، gaps | **P0 كخط أساس A/B** | قاعدة قابلة لإعادة الإنتاج، لكنها معرضة لـwhipsaw وdata snooping [20] |
| وقف بنيوي تكيفي | مبدأ إدارة تنفيذ ومخاطر | swing/structure invalidation مع buffer محافظ | OHLC، ATR/EWMA، spread | **P0 كجزء من التنفيذ** | يحاكي تغير التقلب، لكنه لا يضمن fill ولا يجوز ضبطه بعد النتائج [21] |
| تحجيم volatility | دليل مختلط أكاديمياً وصناعياً | EWMA/ATR لتخفيض التعرض، مع cap ثابت | OHLC، equity، مواصفات العقد/الوسيط | **P0 للمقارنة، لا للإشارة** | قد يحسن المخاطر تاريخياً لكنه قد يفشل OOS ويضخم الحجم إن غاب cap [4] [5] [6] |
| Event/session/spread guard | مبدأ تنفيذ، لا edge مستقل | FLAT أو خفض مخاطرة عند خبر/اتساع spread | تقويم أحداث، quotes، timezone | **P0 كاختبار تنفيذ** | يقيس قابلية التنفيذ، ولا يدعي توقع اتجاه الخبر |
| Mean reversion منفرد | أدلة أسهم/نفط مع structural breaks | spread/z-score مع stationarity وtime-stop | leg/hedge، bid/ask، بيانات متزامنة | **P1 مشروط أو Shadow** | لا صفقة بلا علاقة مستقرة حديثاً؛ لا نقل مباشر إلى الذهب [7] [8] [9] |
| Markov/regime filter | دليل على تغير تقلب الذهب، لا ربح breakout | استخدام regime للحجم أو الحظر | تاريخ طويل، مواصفات regime مجمدة | **P1 A/B** | يختبر جودة التنفيذ والمخاطر، لا يفترض أنه يحسن العائد [23] |
| OFI/MLOFI | علاقة قصيرة في أسهم وLOB مركزي | تأكيد اتجاه أو مرشح سيولة | DOM/L2 وtrades حقيقية وlatency | **Shadow ثم A/B** | لا يمكن إثباته من bar أو tick volume [11] [12] [13] |
| VPIN | مقياس تدفق حساس للمعلمات | خفض تداول عند toxic-flow | trade classification وvolume حقيقي | **Shadow** | ليس إنذاراً حتمياً، والنتيجة حساسة للبناء [14] |
| GC volume/open interest | سياق futures مركزي | متغير سياقي لا volume XAUUSD | بيانات CME ومزامنة زمنية | **Shadow** | proxy فقط؛ لا يمثل OTC spot [24] |
| ML متعدد الميزات | معرض لتعدد الاختبارات | score أو filter بعد تثبيت pipeline | بيانات واسعة، nested WFO، purge/embargo | **Shadow/A-B متأخر** | لا يقبل قبل PBO/DSR وسجل كل التجارب [15] [16] [17] |
| win rate أو backtest غير مكلف | لا يثبت edge | — | — | **مرفوض** | لا يلتقط payoff، الذيل، التكلفة أو drawdown [3] [18] |
| Demo أو شهادة مستخدم | قصصي وغير مستقل | — | — | **مرفوض كدليل** | Paper/Demo اختبار تنفيذ، لا إثبات ربحية [25] |

## 4. بروتوكول اختبار موحد على XAUUSD

### 4.1 عقد البيانات ومنع التسرب

يجب تثبيت symbol وbroker/feed والمنطقة الزمنية وتعريف الشمعة ومصدر bid/ask قبل أول تشغيل. تُحفظ نسخة البيانات أو hash لها، مع data vintage، وجودة ticks أو bars، وفترات الانقطاع، وقواعد التعامل مع gaps وrollover. إن كان الرمز spot أو CFD، تُوثق قيمة النقطة، وحجم العقد، وساعات التداول، والتمويل أو swap، وسياسة إعادة التسعير الخاصة بالوسيط. لا تكفي مواصفات COMEX GC لإثبات مواصفات XAUUSD. [21] [24]

عند إغلاق bar عند الزمن `t` تُحسب الإشارة مما كان متاحاً عند `t` فقط. يكون التنفيذ الافتراضي عند أول سعر قابل للتنفيذ في `t+1` أو بعد تأخير محدد. لا تستخدم high أو low أو close لم يكتمل عند لحظة القرار، ولا event calendar بعد نشر الخبر بأثر رجعي. يجب اختبار مزامنة آلي يكشف أي feature أو label يتجاوز وقت القرار. [1] [18] [26]

### 4.2 التقسيم الزمني وwalk-forward

يُقسّم التاريخ إلى **development** و**validation** و**sealed holdout OOS** بالترتيب الزمني. داخل development تُستخدم نافذة rolling أو expanding للتدريب، وتُختار المعلمات في validation فقط. ثم يتحرك الاختبار إلى الأمام من دون تعديل بناءً على holdout. إذا كان label أو مدة الصفقة يمتدان عبر الحدود، تُستخدم purge وembargo بمدة تغطي أفق العائد وتداخل الصفقات. [15] [26]

الـwalk-forward ليس ضماناً ضد overfitting؛ فهو مسار تاريخي واحد ويمكن أن يخطئ إذا أُعيد استعمال نتائجه للاختيار أو حُرّكت النوافذ بطريقة تكشف المستقبل. لذلك يُحفظ كل fold، وتُعرض النتائج لكل fold ولكل regime، لا المتوسط الكلي فقط. [15] [26]

### 4.3 سيناريوهات التكلفة والتنفيذ

يجب تشغيل كل Build على الأقل في السيناريوهات الآتية، وتثبيتها قبل رؤية النتائج:

1. **منخفض:** spread وslippage وcommission عند تقديرات متفائلة ولكن موثقة من feed/وسيط محدد.
2. **أساسي:** bid/ask الفعليان أو تقدير محافظ مستخرج من بيانات quotes، مع commission وfinancing/swap.
3. **مرتفع:** مضاعفة spread وslippage، وتأخير تعبئة، ورسوم تمويل أعلى.
4. **ضغط:** spread widening وgap وpartial/missed fills أثناء الأخبار أو rollover، مع عدم افتراض أن الوقف ينفذ عند سعره.
5. **حساسية:** شبكة تكلفة تُظهر break-even cost؛ أي أقل تكلفة تجعل expectancy صفراً.

يجب عرض gross وnet بعد كل عنصر منفرداً ومجتمعاً. لا يجوز استبدال تكلفة XAUUSD بتقدير Managed Futures أو round-trip لسهم أو زوج آخر. وتوضح الأدلة أن market impact والعمولة والسبريد والتأخير قد تلغي عائداً ظاهرياً، خاصة عندما يكون turnover مرتفعاً. [8] [18] [21] [27]

### 4.4 تقسيم regimes والفترات الصعبة

يُعرّف regime قبل القياس ولا يُنتقى بعد النتائج. الحد الأدنى هو تقسيم حسب volatility منخفض/عادي/مرتفع، trend/range، جلسة لندن ونيويورك وoverlap، event window، واتساع spread. ويمكن إضافة اتجاه العائد أو gap، بشرط أن يكون تعريفه مستنداً إلى بيانات متاحة عند القرار. تُقارن النسخة الأساسية بنسخة no-regime، وتُبلغ النتائج في كل كتلة زمنية لا في المتوسط فقط. [2] [19] [23]

يجب إنشاء اختبارات ضغط للفشل السريع، وwhipsaw، وسلسلة خسائر متتالية، وغياب بيانات، ورفض الأوامر، وانقطاع الاتصال. trend following لا يحمي دائماً من أزمة؛ الصدمة الأسرع من الإشارة قد تسبب خسارة قبل أن تتكيف القاعدة. [2] [19]

### 4.5 تعدد الاختبارات والتصحيح الإحصائي

ينشئ كل تغيير في feature أو lookback أو SL أو event guard أو cost model أو cadence **BUILD_ID جديداً**. يُسجل `trial_count` كاملاً، بما في ذلك النماذج الملغاة والفاشلة. عند اتساع البحث يُستخدم PBO/CSCV أو بديل search-aware، ويُحسب Deflated Sharpe Ratio أو عقوبة معلنة للانتقاء، مع الحذر من تقديم هذه الأدوات كضمانات. [15] [16]

لا يُعاد استخدام sealed holdout لاختيار النموذج. إذا فُحص holdout ثم عُدّل النظام، يصبح جزءاً من development عملياً ويجب إنشاء holdout جديد. كما ينبغي رفع معيار الإثبات مع عدد الفرضيات؛ فالقيمة التقليدية لـt أكبر من 2 ليست معياراً كافياً في بيئة بحث واسعة. [17]

### 4.6 القرار والحجم والوقف

تُمرّر كل bar أو event عبر قرار موحّد: `LONG` أو `SHORT` أو `FLAT/NO_TRADE` أو `EXIT`. لا تُجمع قرارات متعارضة من momentum وmean reversion وOFI. إذا لم تتوافر البيانات أو اتسع spread أو فشلت علاقة hedge، تكون النتيجة FLAT. يستطيع ML أو OFI إنتاج score أو confirmation، لكنه لا ينشئ قراراً ثانياً مستقلاً.

يُحسب حجم المركز بعد تحديد الوقف البنيوي وتكلفة الخروج. توجد سقوف منفصلة للمخاطرة لكل صفقة، ولكل يوم أو جلسة، وللأحداث عالية المخاطر، وللتعرض الكلي. لا يُعامل margin المتاح كميزانية خسارة. ويُختبر fractional sizing فقط بعد إثبات الاستقرار، مع منع Kelly الكامل في النسخة الأولية. [4] [5] [21]

### 4.7 سجل القرار والشفافية

يحتوي ledger غير القابل للالتباس على الأقل على: `BUILD_ID`، و`run_id`، وtimestamp/timezone، وsymbol/timeframe، ومصدر البيانات وhash، وفترات train/validation/test، وstructure وtrend وlevels وevents، وfeatures وlabel horizon، والمعلمات، والقرار، ووقت الإشارة والتنفيذ، وbid/ask، وentry/exit، وسبب SL، وحجم المركز، وrisk budget، وspread/slippage/commission/financing/latency، والسيناريو، وP&L gross/net، وMFE/MAE، والـregime، وسبب `NO_TRADE`، وحالة Paper/Demo.

تُحفظ التجارب الفاشلة، ونتائج A/B، والتعديلات، وعدد المحاولات. لا يُسمح بتعديل سجل قديم لإخفاء تغيير في القرار أو في تعريف الوقف. هذا الشرط مهم لأن إعادة ضبط المعلمات بعد رؤية النتائج تحول الاختبار إلى تطوير غير معلن. [15] [18]

## 5. مقاييس القبول والرفض

لا يُقبل Build لمجرد أن win rate مرتفع. يصف التقرير على مستوى كل fold وregime وسيناريو تكلفة:

- **Expectancy الصافي لكل صفقة**: متوسط الربح والخسارة بعد جميع التكاليف، ويفضل التعبير عنه نقداً وبوحدات R.
- **Profit factor**: إجمالي الأرباح مقسوماً على إجمالي الخسائر، مع إظهار عدد الصفقات حتى لا تضخم عينة صغيرة النسبة.
- **Payoff ratio** وmedian win/median loss، لأن المتوسط قد يخفي tail.
- **Sharpe وSortino** بحذر، مع فواصل عدم يقين وعدم معاملتهما كإثبات سببي.
- **Max drawdown** وUlcer index ومدة التعافي، إضافة إلى أسوأ خسارة منفردة.
- **Loss streak**: أطول سلسلة خسائر متتالية، وتوزيعها حسب regime، لأن القدرة النفسية والمالية على تحملها جزء من قابلية التنفيذ.
- **Turnover وexposure ومدة الصفقة**، مع adverse/favorable excursion وfill rate وmissed-fill rate.
- **Break-even cost** وحساسية النتائج لمضاعفة spread وslippage والتأخير.
- **ثبات الفروع**: عدد folds الموجبة، ونتيجة holdout، وأداء كل regime، وتغير المعلمة حول القيمة الأساسية.

يكون acceptance gate مبدئياً كالتالي: لا يدعي النظام edge إلا إذا بقي expectancy موجباً بعد السيناريو الأساسي والمرتفع، ولم ينهَر بالكامل في holdout أو في regime ضغط معقول، وكانت الخسارة القصوى وسلسلة الخسائر ضمن سقف محدد مسبقاً، وكان turnover قابلاً للتنفيذ. إذا فشل أي شرط جوهري، تكون الحالة `FLAT/REJECT BUILD`، لا إعادة ضبط انتقائية. عدم الدلالة الإحصائية لا يثبت أن edge معدوم، لكنه سبب كافٍ لعدم زيادة المخاطر أو تقديم وعد ربح. [3] [15] [16] [18]

## 6. ما الذي لا يمكن إثباته دون DOM/volume حقيقية؟

لا يمكن إثبات أن **OFI** أو **MLOFI** يتنبأان بحركة XAUUSD، أو أن **VPIN** يكتشف toxic-flow، أو أن عمق دفتر الأوامر يحسن التنفيذ، إذا كانت البيانات المتاحة لا تحتوي على دفتر أوامر L2/L3 مؤرخاً، أو trade prints قابلة لتصنيف aggressor، أو quotes bid/ask متزامنة مع latency وfills. دراسات OFI المذكورة استخدمت TAQ أو دفاتر أوامر مركزية في أسهم، وبعضها احتاج مستويات أعمق ونماذج regularization؛ هذه البيئة ليست بالضرورة بيئة XAUUSD OTC. [11] [12] [13]

ولا يمكن اعتبار tick volume من منصة واحدة حجماً عالمياً لـXAUUSD. لا يوجد في OTC spot دفتر مركزي موحد يساوي ما يراه كل وسيط. كذلك لا يمكن اعتبار volume أو open interest لعقد GC قياساً لحجم XAUUSD الفوري؛ يمكن استخدامه كسياق proxy مع تسمية صريحة وحدود واضحة، لكن لا يُبنى عليه ادعاء order-flow خاص بالرمز. [14] [24]

إذا لم تتوافر هذه البيانات، تبقى فرضيات microstructure في Shadow، ويقتصر الاختبار على مراقبة الارتباط أو جودة التنفيذ دون ادعاء قابلية تنبؤية أو ربح صاف. ويجب أن يستخدم القرار الأساسي OHLC وbid/ask الواقعيين فقط، مع إعلان أن غياب DOM يمنع إثبات هذه الفئة من المناهج.

## 7. الترتيب التنفيذي المقترح

**المرحلة الأولى: baseline قابل للتفنيد.** يُشغّل time-series momentum البسيط وDonchian كبديلين منفصلين، مع قرار واحد ووقف بنيوي وتحجيم ثابت محدود، ثم مقارنة no-regime وvolatility-scaling. تُجمّد المواصفات، وتُطبق WFO، وسيناريوهات التكلفة، والـholdout sealed.

**المرحلة الثانية: تحسين قابلية التنفيذ لا تعظيم العائد.** تُضاف event/session/spread guards، وقياس slippage والـlatency والرفض، ويُفصل أثر كل guard في A/B مستقل. لا تُضاف مؤشرات اتجاه كثيرة، ولا يُختار guard لأنه حسّن أفضل منحنى فقط.

**المرحلة الثالثة: mean reversion مشروط.** لا يبدأ هذا المسار إلا بعد تعريف leg أو spread قابل للتداول، وقياس استقرار وbreak وhalf-life في نافذة rolling. يُعطّل عند structural break أو استمرار trend، ويُقارن بنسخة FLAT لا بصفقة عكسية دائمة.

**المرحلة الرابعة: microstructure وML في Shadow.** عند توفر DOM/trade data حقيقية، تُختبر OFI وMLOFI وVPIN مع lag وexecution model. ويُشغّل ML في nested WFO مع purge/embargo وtrial_count وPBO/DSR. إذا لم تتوافر البيانات، لا تُستبدل بفرضية volume زائفة.

**المرحلة الخامسة: Paper/Demo فقط.** بعد اجتياز بوابة البحث، يُشغل نفس BUILD_ID دون إعادة tuning على بيانات حية. تُقارن الإشارة والتعبئة النظرية بالفعلية، وتُسجل latency وspread وgap ورفض الأوامر وswap. Paper/Demo يختبر البيانات والتنفيذ، لكنه لا يثبت ربحية ولا يجيز الحساب الحقيقي. [25]

## الخلاصة النهائية

تستحق FER3ON Next أن تبدأ بفرضية اتجاه بسيطة قابلة لإعادة الإنتاج، لا بتجميع مؤشرات أو تعظيم win rate. الدليل الأكاديمي يبرر اختبار time-series momentum وقياساً محافظاً للتقلب، لكنه مختلط خارج العينة وغير خاص بـXAUUSD. وDonchian مفيد كخط أساس واضح، لا كبرهان على edge. mean reversion يحتاج علاقة مستقرة واختبار break. OFI وMLOFI وVPIN تحتاج بيانات DOM/volume حقيقية، وتبقى Shadow دونها. [1] [3] [7] [11]

النتيجة الوحيدة المقبولة قبل أي توسع هي نتيجة تبقى موجبة أو مقبولة تحت تكاليف محافظة، وwalk-forward، وholdout لم يُستخدم للاختيار، وتقسيم regimes، وتصحيح تعدد الاختبارات، مع قياس expectancy وprofit factor وmax drawdown وloss streak وبقية تشخيصات الذيل. لا توجد في هذه المراجعة نتيجة تثبت ربحاً مستمراً لـFER3ON أو XAUUSD، ولذلك يظل الاستخدام المقترح بحثاً وPaper/Demo فقط، وليس توصية استثمارية أو تصريحاً بالتداول الحقيقي.

## References

[1]: https://w4.stern.nyu.edu/facdir/lpederse/papers/TimeSeriesMomentum.pdf "Time Series Momentum — Moskowitz, Ooi & Pedersen"

[2]: https://fairmodel.econ.yale.edu/ec439/hurst.pdf "A Century of Evidence on Trend-Following Investing — Hurst, Ooi & Pedersen"

[3]: https://ink.library.smu.edu.sg/context/lkcsb_research/article/7520/viewcontent/Time_series_momentum_JFE_sv.pdf "Time-series momentum: Is it there? — Huang, Li, Wang & Zhou"

[4]: https://www.nber.org/system/files/working_papers/w22208/w22208.pdf "Volatility Managed Portfolios — Moreira & Muir"

[5]: https://www.sciencedirect.com/science/article/abs/pii/S0304405X2030132X "On the performance of volatility-managed portfolios — Cederburg et al."

[6]: https://www.aqr.com/-/media/AQR/Documents/Insights/White-Papers/Understanding-Risk-Parity.pdf "Understanding Risk Parity — AQR"

[7]: https://www.nyu.edu/inmemoriam/avellaneda/AvellanedaLeeStatArb20090616.pdf "Statistical Arbitrage in the U.S. Equities Market — Avellaneda & Lee"

[8]: https://www.econstor.eu/bitstream/10419/116783/1/833997289.pdf "Statistical arbitrage pairs trading strategies: Review and outlook — Krauss"

[9]: https://www.mdpi.com/2227-9091/12/7/106 "Mean-Reverting Statistical Arbitrage Strategies in Crude Oil — Fanelli et al."

[10]: https://www.nber.org/system/files/working_papers/w7032/w7032.pdf "Pairs Trading — Gatev, Goetzmann & Rouwenhorst"

[11]: https://arxiv.org/abs/1011.6402 "The Price Impact of Order Book Events — Cont, Kukanov & Stoikov"

[12]: https://arxiv.org/html/1907.06230v2 "Multi-Level Order-Flow Imbalance in a Limit Order Book — Xu, Gould & Howison"

[13]: https://www.tandfonline.com/doi/full/10.1080/14697688.2023.2236159 "Cross-impact of order flow imbalance in equity markets"

[14]: https://www.stern.nyu.edu/sites/default/files/assets/documents/con_035928.pdf "Flow Toxicity and Liquidity in a High Frequency World — Easley, López de Prado & O’Hara"

[15]: https://www.davidhbailey.com/dhbpapers/backtest-prob.pdf "The Probability of Backtest Overfitting — Bailey et al."

[16]: https://www.davidhbailey.com/dhbpapers/deflated-sharpe.pdf "The Deflated Sharpe Ratio — Bailey & López de Prado"

[17]: https://www.nber.org/system/files/working_papers/w20592/w20592.pdf "... and the Cross-Section of Expected Returns — Harvey, Liu & Zhu"

[18]: https://ml4trading.io/third-edition/chapters/16_strategy_simulation/ "Strategy Simulation — ML for Trading, Third Edition"

[19]: https://www.man.com/insights/is-this-time-different "Is this time different? — Man Group"

[20]: https://open.uct.ac.za/handle/11427/21754 "Testing a price breakout strategy using Donchian Channels — Swart"

[21]: https://www.quantconnect.com/docs/v2/writing-algorithms/reality-modeling/slippage/key-concepts "Slippage — Key Concepts — QuantConnect"

[22]: https://www.cmegroup.com/education/lessons/product-gold "Gold Product Overview — CME Group"

[23]: https://www.sciencedirect.com/science/article/pii/S0301421510002570 "Volatility behavior of oil, industrial commodity and stock markets in a regime-switching environment — Choi & Hammoudeh"

[24]: https://www.cmegroup.com/markets/metals/precious/gold.html "Gold Futures Overview — CME Group"

[25]: https://www.quantconnect.com/docs/v2/cloud-platform/live-trading/brokerages/quantconnect-paper-trading "QuantConnect Paper Trading"

[26]: https://portfoliooptimizationbook.com/book/8.4-backtesting-market-data.html "Backtesting with Historical Market Data"

[27]: https://www.tandfonline.com/doi/full/10.1080/0015198X.2019.1567190 "Transaction Costs of Factor Strategies — Li et al."
