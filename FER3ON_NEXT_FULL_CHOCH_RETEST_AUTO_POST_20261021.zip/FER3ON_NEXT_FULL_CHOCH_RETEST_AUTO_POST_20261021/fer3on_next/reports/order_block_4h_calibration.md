# معايرة Order Block لفريم 4h

## الهدف

زيادة حساسية رصد BOS وDisplacement على الفريم الكبير دون تغيير إعدادات Order Block على 1h أو الفريمات الأخرى.

## الإعدادات الجديدة

```toml
ob_4h_max_age = 30
ob_4h_min_displacement_atr = 0.45
ob_4h_max_width_atr = 2.25
ob_4h_structure_left = 1
ob_4h_structure_right = 1
```

مقابل الإعداد العام:

```toml
ob_max_age = 20
ob_min_displacement_atr = 0.80
ob_max_width_atr = 1.50
ob_structure_left = 2
ob_structure_right = 2
```

## سبب التعديل

الفريم 4h يحتاج عددًا أقل من شموع التأكيد حول Pivot حتى لا يتأخر BOS، كما أن Displacement النسبي قد يكون أقل من 0.80 ATR رغم أن الحركة مهمة بنيويًا. لذلك تم تخفيض عتبة Displacement وتوسيع عمر المنطقة وعرضها بصورة محدودة.

## النتيجة

على نافذة Smoke Test نفسها:

| الفريم | قبل | بعد |
|---|---:|---:|
| 1h Order Block | 16 | 16 |
| 4h Order Block | 0 | 1 |

إشارة 4h الجديدة كانت SELL. بقيت الأسباب الرئيسية لعدم الدخول:

```text
NO_BOS_FOR_ORDER_BLOCK: 1013
ORDER_BLOCK_NO_DISPLACEMENT: 456
ORDER_BLOCK_NOT_RETESTED: 22
NO_OPPOSITE_ORDER_BLOCK: 8
```

هذا يؤكد أن التعديل زاد الحساسية جزئيًا، لكنه لم يحول الوحدة إلى مولد صفقات كثيف، وهو مقصود لتجنب فتح صفقات كثيرة من بنية ضعيفة.

## الحكم

الإعدادات جاهزة لاختبار ربحية مستقل على 4h، وليست مقبولة للترقية بناءً على Smoke Test. يجب قياس Profit Factor وExpectancy وDrawdown على تقسيم زمني مستقل، وعدم تعديل هذه القيم مرة أخرى بناءً على نفس نافذة الاختبار.
