# تدقيق انتقائي للنسخ القديمة

## النتيجة التنفيذية

تمت مراجعة بنية `FER3ON_ADAPTIVE_SL_CONTROL_AND_R2_UPDATED` والنسخة المدققة وسجل الصفقات. لا توجد فائدة في نسخ المجلدات القديمة كاملة؛ معظمها يعيد تعريف القرار أو المخاطر أو التنفيذ في مسارات متوازية. تم نقل المبادئ القابلة للعزل فقط إلى `fer3on_next`.

سجل `mt5_trade_history.csv` يحتوي 191 صفقة: 167 SMC بصافي -34.21 دولار، و10 SCALP بصافي -60.94 دولار، و14 MANUAL بصافي +61.33 دولار. إجمالي السجل -33.82 دولار، مع 97 خسارة و94 فوزًا، و157 حالة متتابعة لنفس اتجاه/استراتيجية الصفقة السابقة وفق فحص أولي. هذه الأرقام لا تثبت أن كل قاعدة قديمة سيئة، لكنها تمنعنا من نقل SMC/SCALP كسلطات تداول جاهزة.

## ما تم نقله أو إعادة بنائه

| فكرة قديمة | المصدر | وضعها في النواة الجديدة | سبب القرار |
|---|---|---|---|
| Pivot confirmation وHH/HL/LH/LL | `core/market_structure.py` | موجودة في `structure.py` | أساس صالح، مع منع look-ahead |
| H4/H1/M15 alignment | `core/choch_engine.py` و`market_structure.py` | موجود في `mtf.py` و`trend.py` | نُقل كمصفاة واحدة لا كاستراتيجيات متعددة |
| BOS/CHOCH | `core/choch_engine.py` | موجود في `market_events.py` | أُعيدت صياغته بإغلاق مؤكد وRetest |
| FVG وliquidity sweep | وحدات SMC القديمة | موجود في `market_events.py` و`liquidity.py` | دخلت في `ENTER_READY` فقط عند توافق الشموع |
| Volume Profile | `core/volume_profile.py` | حُسّن في `volume_profile.py` | تم نقل توزيع الحجم على مدى الشمعة ومصدر الحجم |
| Structural SL | `core/adaptive_sl_tp_engine.py` | موجود في `structural_sl_tp.py` | تم حذف عوامل الاستراتيجية القديمة والقيم الثابتة |
| TP ladder وBreak-even | `core/exit_manager.py` و`breakeven_policy.py` | خطة في `trade_management.py` | لا تُترك كأنظمة خروج متنافسة |
| Execution quality | `core/execution_quality.py` | موجود في `execution_quality.py` | RR/Spread/SL-ATR بوابة واحدة |
| Loss pause بعد الخسائر | `core/loss_pause_guard.py` | أضيف إلى `AccountState` والـPaper Broker | يستخدم حدث BOS/CHOCH للإفراج بدل إعادة الدخول العشوائي |
| Demo account check وorder_check | `core/account_protection.py` و`core/execution/mt5_broker.py` | أضيف إلى `mt5_demo.py` | يمنع الحساب غير التجريبي ويفحص الوسيط قبل الإرسال |
| Data validation | `core/data_quality.py` | موجود في `data_quality.py` | يمنع OHLC غير الصالح والفجوات الزمنية |
| Idempotency / magic identity | `core/trade_identity.py` | مفتاح قرار موجود؛ magic ثابت Demo | لا تُنقل خرائط الاستراتيجيات القديمة لأنها متعددة السلطات |

## ما تم استبعاده

لم يتم نقل `SCALP`, `SWING`, `MICRO`, `RECOVERY`, `SURVIVAL`, `FAIE`, `MASR`, `ML/RL`, `shadow`, `adaptive weighting`, `brain`, أو `opportunity allocator` كمسارات تداول. هذه الوحدات إما غير موصلة بمسار التنفيذ، أو تعتمد على مصادر قرار متعددة، أو تعيد ضبط المخاطر والوقف في أماكن مختلفة.

كما لم يتم نقل عوامل مثل `strategy_factor`, `regime_factor`, `session_factor`, و`lot_factor` من `adaptive_sl_tp_engine.py`؛ لأنها تجعل SL نتيجة عشرات المعاملات، ولا تجعل نقطة الإبطال أكثر صحة. النواة الجديدة تستخدم سبب الصفقة والهيكل ثم تضيف ATR buffer واضحًا.

## فجوات ما زالت تحتاج اختبارًا

1. إدارة partial close وtrailing الفعلية في MT5 لم تُفعّل بعد؛ خطة TP موجودة في القرار، لكن التنفيذ الحي يجب أن يمر عبر مدير خروج واحد.
2. Loss Pause محفوظ داخل الجلسة الورقية؛ يحتاج Demo إلى مزامنة نتيجة الصفقات المغلقة من سجل MT5 قبل اعتباره دائمًا بعد إعادة التشغيل.
3. يجب اختبار كل طبقة بمفردها عبر ablation: baseline، ثم structure، ثم levels، ثم MTF، ثم events، ثم execution quality.
4. يجب استخدام بيانات XAUUSD M15 من نفس الوسيط قبل أي استنتاج، لأن `GC=F` المستخدم في التقرير العام Futures وليس Spot.

## الحكم

لا يوجد كود قديم واضح نحتاج إلى نسخه كما هو. ما يحتاجه البوت هو **مبادئ محددة** وقد تم إدخالها في وحدات صغيرة ذات سلطة واحدة. أما الملفات القديمة نفسها فإبقاؤها خارج المشروع هو جزء من الإصلاح، وليس فقدانًا للميزات.
