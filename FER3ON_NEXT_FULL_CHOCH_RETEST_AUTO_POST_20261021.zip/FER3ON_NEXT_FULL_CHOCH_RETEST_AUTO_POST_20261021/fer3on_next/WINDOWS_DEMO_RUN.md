# تشغيل FER3ON Next على Windows وVS Code عبر MT5 Demo

## الفرق عن النسخة القديمة

النسخة القديمة كانت تُشغّل:

```powershell
python main.py
```

أما FER3ON Next فتستخدم مشغلًا منفصلًا وواضحًا:

```powershell
python run_demo.py
```

لا تستخدم `main.py` في المشروع الجديد. كما أن موصل MT5 الجديد لا يسمح بالتشغيل إلا عندما تكون بيئة التشغيل Demo صراحةً.

## المتطلبات

يجب أن يكون على نفس جهاز Windows:

1. MetaTrader 5 مثبتًا.
2. حساب Demo مفتوحًا ومُسجل الدخول داخل MT5.
3. الرمز المطلوب ظاهرًا في نافذة Market Watch، والاسم مطابق للإعدادات؛ قد يكون `XAUUSD` أو اسمًا مثل `XAUUSDm` حسب الوسيط.
4. Python 3.11 أو أحدث.
5. اتصال مستقر بالوسيط.

الموصل يستدعي `MetaTrader5.initialize()`. قد يعثر على محطة MT5 المثبتة تلقائيًا، لكن لا يعتمد على تسجيل الدخول تلقائيًا. الأفضل فتح MT5 وتسجيل الدخول إلى حساب Demo قبل تشغيل البوت.

## فتح المشروع

افتح مجلد المشروع في VS Code، مثل:

```text
D:\fer3on_next
```

ثم افتح Terminal من داخل VS Code واختر PowerShell.

## إنشاء البيئة الافتراضية

نفّذ مرة واحدة:

```powershell
cd D:\fer3on_next
py -3.11 -m venv .venv
```

إذا كان الأمر `py -3.11` غير متاح، استخدم:

```powershell
python -m venv .venv
```

## تفعيل البيئة وتثبيت الحزمة

في كل Terminal جديد:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
python -m pip install MetaTrader5
```

إذا ظهرت علامة البيئة في بداية السطر، مثل:

```text
(.venv) PS D:\fer3on_next>
```

فالتفعيل صحيح.

## إعداد حساب Demo

افتح MT5 يدويًا، ثم:

1. سجّل الدخول إلى حساب Demo.
2. تأكد أن اسم الحساب ليس Real.
3. افتح Market Watch.
4. فعّل الرمز الفعلي لدى الوسيط، مثل `XAUUSD` أو `XAUUSDm`.
5. اترك MT5 مفتوحًا.

## متغيرات الأمان المطلوبة

في PowerShell الحالي:

```powershell
$env:FER3ON_MODE = "DEMO"
$env:FER3ON_DEMO_CONFIRM = "YES"
$env:FER3ON_DEMO_JOURNAL = "reports\live_demo_ledger.jsonl"
```

هذه المتغيرات مؤقتة لهذا Terminal فقط، وهي مناسبة للاختبار. عند إغلاق Terminal يجب ضبطها مرة أخرى.

## تعديل الرمز والفريم

الإعدادات الافتراضية في `BotConfig` هي:

```text
symbol = XAUUSD
timeframe = M15
```

إذا كان وسيطك يستخدم اسمًا مختلفًا، لا تغيّر موصل MT5؛ غيّر `BotConfig` أو أنشئ ملف إعدادات/مشغلًا يمرر الرمز الصحيح، مثل `XAUUSDm`.

للتجربة الحالية يجب التأكد من أن الرمز الموجود في MT5 يطابق `cfg.symbol`.

## اختبار الاتصال دون دورة مستمرة

شغّل أولًا دورة واحدة:

```powershell
python run_demo.py --once
```

هذا يقرأ شموعًا مغلقة، يبني القرار، ويفحص الحساب. إذا كان القرار `WAIT` فلن يرسل أمرًا، وهذا طبيعي. إذا كان القرار `ENTER` في Demo، فسيجتاز فحص `order_check` ثم يرسل أمر Demo.

## تشغيل الدورة المستمرة

بعد نجاح اختبار `--once`:

```powershell
python run_demo.py --interval 60
```

يعني ذلك تقييم دورة كل 60 ثانية. لإيقافه:

```text
Ctrl+C
```

يمكن استخدام فاصل أطول أثناء البداية:

```powershell
python run_demo.py --interval 300
```

## فحص سجل الصفقات

السجل الحي يكتب أحداثًا Append-only في:

```text
reports\live_demo_ledger.jsonl
```

كل قرار أو أمر أو نتيجة يحمل:

- `event_id`
- `correlation_id`
- `strategy_id`
- `build_id`
- `run_id`
- وقت الحدث
- سبب الدخول أو الرفض
- الوقف والهدف والحجم
- رقم تذكرة MT5 عند توفره

لفحص آخر السجل:

```powershell
Get-Content reports\live_demo_ledger.jsonl -Tail 20
```

## حواجز الأمان

الموصل يرفض التشغيل إذا:

- لم يتم تعيين `FER3ON_MODE=DEMO`.
- لم يتم تعيين `FER3ON_DEMO_CONFIRM=YES`.
- تعذر قراءة الحساب.
- كان الحساب Real.
- فشل `order_check`.
- كان الوقف داخل الحد الأدنى الذي يفرضه الوسيط.
- فشل جلب السعر أو الرمز أو المراكز المفتوحة.

لا توجد في هذا المسار طريقة لتفعيل Live؛ الحساب الحقيقي مرفوض برمجيًا.

## الفرق بين `--once` و`--interval`

| الأمر | الوظيفة |
|---|---|
| `python run_demo.py --once` | دورة واحدة للفحص والتجربة |
| `python run_demo.py --interval 60` | تشغيل Demo مستمر كل 60 ثانية |

## فحص الاختبارات محليًا

قبل Demo أو بعد أي تعديل:

```powershell
python -m pytest -q
```

## المشاكل الشائعة

### `Install MetaTrader5`

نفّذ:

```powershell
python -m pip install MetaTrader5
```

وتأكد أن التثبيت داخل `.venv` الفعالة.

### `Set FER3ON_MODE=DEMO`

نفّذ:

```powershell
$env:FER3ON_MODE = "DEMO"
```

### `Set FER3ON_DEMO_CONFIRM=YES`

نفّذ:

```powershell
$env:FER3ON_DEMO_CONFIRM = "YES"
```

### `Non-DEMO account detected`

أغلق الحساب الحالي وسجّل الدخول إلى حساب Demo داخل MT5. لا تحاول تجاوز الحارس.

### `No rates` أو `symbol_info unavailable`

تأكد من اسم الرمز في Market Watch، ثم عدّل `cfg.symbol` ليتطابق مع اسم الوسيط.

### لا توجد صفقة

إذا كان القرار `WAIT`، اقرأ `reason` في السجل. عدم وجود صفقة ليس خطأ؛ يعني أن شروط الدخول لم تكتمل.

### `retcode=10019` أو `comment='No money'`

هذا يعني أن MT5 رفض الأمر لأن الحساب لا يملك رصيدًا أو هامشًا حرًا كافيًا. افتح `Toolbox -> Trade` داخل MT5 وتحقق من `Balance` و`Equity` و`Free Margin`. إذا كانت القيم صفرًا، سجّل الدخول إلى حساب Demo صالح أو اطلب من وسيط الـDemo إعادة تعبئة الرصيد. لا تتجاوز فحص `order_check` ولا تخفّض الحجم عشوائيًا.

في الإصدارات المحدثة، رفض الأمر يُكتب في السجل كحدث `ORDER_REJECTED` وتستمر حلقة المراقبة بدل توقف البرنامج. لا يُعتبر الأمر المرفوض صفقة ولا يُحسب كخسارة.
