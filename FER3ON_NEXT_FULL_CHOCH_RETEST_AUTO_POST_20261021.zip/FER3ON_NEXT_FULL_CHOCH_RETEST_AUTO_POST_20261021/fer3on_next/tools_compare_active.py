from __future__ import annotations
import json
import sys
from pathlib import Path
from fer3on_next.backtest import load_csv
from fer3on_next.domain import BotConfig
from fer3on_next.acceptance import AcceptancePolicy, evaluate_walk_forward
from tools_walk import walk

STRATEGIES = ("TSM", "DONCHIAN", "FVG", "BOS", "ORDER_BLOCK")


def compare(csv_path: str, report_path: str) -> dict:
    candles = load_csv(csv_path)
    rows = {}
    for name in STRATEGIES:
        cfg = BotConfig(primary_strategy=name, active_strategies=(name,))
        folds, opportunities, trade_rows = walk(candles, cfg)
        gate = evaluate_walk_forward(folds, trade_rows, AcceptancePolicy.final())
        rows[name] = {
            "strategy": name,
            "candles": len(candles),
            "folds": len(folds),
            "trades": sum(f["trades"] for f in folds),
            "net_pnl": sum(f["net_pnl"] for f in folds),
            "profit_factor": (sum(f["gross_profit"] for f in folds) / sum(f["gross_loss"] for f in folds)) if sum(f["gross_loss"] for f in folds) else None,
            "exploration_pass": gate["exploration_pass"],
            "production_eligible": gate["production_eligible"],
            "acceptance": gate,
        }
    output = {"source": csv_path, "instrument_note": "Use broker-specific XAUUSD data for any real conclusion", "strategies": rows}
    Path(report_path).write_text(json.dumps(output, indent=2, default=str))
    return output


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: tools_compare_active.py INPUT_CSV REPORT_JSON")
    print(json.dumps(compare(sys.argv[1], sys.argv[2]), indent=2, default=str))
