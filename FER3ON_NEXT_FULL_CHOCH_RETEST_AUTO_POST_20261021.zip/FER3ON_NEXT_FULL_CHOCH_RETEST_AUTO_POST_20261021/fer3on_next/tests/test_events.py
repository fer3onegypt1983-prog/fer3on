from datetime import datetime,timedelta,timezone
from fer3on_next.domain import Candle, Side
from fer3on_next.market_events import find_fvgs
from fer3on_next.trade_management import build_profit_plan,management_action

def test_fvg_and_profit_plan():
    b=datetime(2026,1,1,tzinfo=timezone.utc)
    cs=[Candle(b,100,101,99,100,100),Candle(b+timedelta(minutes=15),100,101,99.5,100.8,100),Candle(b+timedelta(minutes=30),102,103,101.5,102.5,100)]
    assert find_fvgs(cs)
    plan=build_profit_plan(Side.BUY,100,98,104)
    assert management_action(Side.BUY,102,plan)=='TAKE_PARTIAL_1_MOVE_BE'
    assert management_action(Side.BUY,104,plan)=='CLOSE_FULL_TARGET'
