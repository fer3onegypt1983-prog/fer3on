from datetime import datetime, timezone, timedelta
import pytest
from fer3on_next.domain import AccountState, BotConfig, Candle, Decision, Side
from fer3on_next.execution import RiskError, validate_risk

def c(i,o,h,l,cl): return Candle(datetime(2026,1,1,tzinfo=timezone.utc)+timedelta(minutes=i),o,h,l,cl)

def test_buy_geometry_and_risk():
    cfg=BotConfig(risk_per_trade=.01)
    d=Decision('ENTER',Side.BUY,100,98,104,risk_fraction=.01)
    assert validate_risk(d,AccountState(1000,1000),cfg)==10

def test_invalid_geometry_rejected():
    cfg=BotConfig()
    d=Decision('ENTER',Side.BUY,100,101,104,risk_fraction=.01)
    with pytest.raises(RiskError): validate_risk(d,AccountState(1000,1000),cfg)

def test_cash_daily_loss_cap_is_stricter_than_percentage_when_configured():
    cfg = BotConfig(max_daily_loss=0.05, max_daily_loss_cash=50.0)
    d = Decision('ENTER', Side.BUY, 100, 98, 104, risk_fraction=.01)
    with pytest.raises(RiskError, match="daily loss limit"):
        validate_risk(d, AccountState(940, 1000), cfg)

def test_wait_on_insufficient_data():
    from fer3on_next.strategy import decide
    out=decide([c(i,100,101,99,100.2) for i in range(10)],AccountState(1000,1000),BotConfig())
    assert out.action=='WAIT'
