from datetime import datetime, timedelta, timezone
import csv
import json
from pathlib import Path

from fer3on_next.domain import Candle
from fer3on_next.primary_signals import tsm_choch_retest
from tools.trade_post_analysis import analyse_trade


def bars(values):
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    return [Candle(start + timedelta(minutes=15*i), x, x + 0.2, x - 0.2, x, 100) for i, x in enumerate(values)]


def test_tsm_choch_retest_never_accepts_direct_fvg_only():
    signal = tsm_choch_retest(bars([100 + i * 0.1 for i in range(40)]), 12)
    assert signal.side is None
    assert signal.reason in {"TSM_WAITING_FOR_CHOCH_RETEST", "TSM_CHOCH_RETEST_WAITING_ACCEPTANCE"}
    assert signal.metadata["blocked_direct_fvg"] is True


def test_post_analysis_calculates_mfe_mae_and_stop_then_target():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    candles = [
        {"time": start, "open": 100, "high": 101, "low": 99, "close": 100},
        {"time": start + timedelta(minutes=15), "open": 100, "high": 100.5, "low": 98.5, "close": 99},
        {"time": start + timedelta(minutes=30), "open": 99, "high": 100.2, "low": 98.8, "close": 99.5},
        {"time": start + timedelta(minutes=45), "open": 99.5, "high": 102, "low": 99.4, "close": 101.5},
    ]
    trade = {"entry_time": start.isoformat(), "exit_time": (start + timedelta(minutes=15)).isoformat(),
             "side": "BUY", "fill_open": "100", "stop": "99", "target": "101",
             "exit": "99", "exit_reason": "STOP", "pnl": "-1"}
    row = analyse_trade(trade, candles, 2)
    assert row["mfe_r"] == 1.0
    assert row["mae_r"] == 1.5
    assert row["target_reached_after_stop"] is True
    assert row["classification"] == "STOP_THEN_TARGET_AFTER_EXIT"
