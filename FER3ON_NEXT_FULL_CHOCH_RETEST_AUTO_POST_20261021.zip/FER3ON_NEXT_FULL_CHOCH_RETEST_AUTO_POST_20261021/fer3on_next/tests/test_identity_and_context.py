from datetime import datetime, timedelta, timezone
from fer3on_next.backtest import run
from fer3on_next.domain import BotConfig, Candle
from fer3on_next.identity import BUILD_ID, SCHEMA_VERSION


def _candles(n=180):
    base=datetime(2026,1,1,tzinfo=timezone.utc); price=100.0; rows=[]
    for i in range(n):
        drift=0.14 if (i//14)%2==0 else -0.11
        o=price; c=price+drift; rows.append(Candle(base+timedelta(minutes=15*i),o,max(o,c)+0.10,min(o,c)-0.10,c,100+i)); price=c
    return rows


def test_backtest_identity_and_context_are_present():
    result=run(_candles(),BotConfig(lookback=30,impulse_window=12),1000)
    assert result['build_id']==BUILD_ID
    assert result['schema_version']==SCHEMA_VERSION
    assert result['run_id'].startswith('backtest-')
    assert result['data_source']=='historical_ohlcv'
    assert result['opportunities']
    row=result['opportunities'][0]
    assert row['build_id']==BUILD_ID
    assert row['run_id']==result['run_id']
    assert row['market_context']['symbol']=='XAUUSD'
    assert 'current_candle' in row['market_context']


def test_scenario_graph_is_recorded_for_decision_opportunities():
    result=run(_candles(),BotConfig(lookback=30,impulse_window=12),1000)
    rows=[r for r in result['opportunities'] if r.get('scenarios')]
    assert rows
    scenario=rows[0]['scenarios']
    assert scenario['selected'] in {'NO_TRADE','CONTINUATION','REVERSAL','RANGE'}
    assert scenario['rejected']
    assert 0 <= scenario['contradiction_score'] <= 100
    assert sum(x['probability'] for x in scenario['candidates']) > 0
