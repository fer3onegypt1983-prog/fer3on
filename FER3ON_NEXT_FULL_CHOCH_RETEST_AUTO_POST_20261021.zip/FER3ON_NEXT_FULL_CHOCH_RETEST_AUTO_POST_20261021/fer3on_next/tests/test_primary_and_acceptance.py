from datetime import datetime, timedelta, timezone
from fer3on_next.domain import Candle, Side
from fer3on_next.primary_signals import time_series_momentum, donchian_breakout, primary_signal
from fer3on_next.position_sizing import build_position_plan
from fer3on_next.acceptance import evaluate_walk_forward


def candles(values):
    base=datetime(2026,1,1,tzinfo=timezone.utc)
    return [Candle(base+timedelta(minutes=15*i),v,v+0.2,v-0.2,v,100) for i,v in enumerate(values)]


def test_tsm_and_donchian_are_deterministic():
    up=candles([100+i for i in range(30)])
    assert time_series_momentum(up,10).side is Side.BUY
    assert donchian_breakout(up,5,3).name=='DONCHIAN'
    assert primary_signal(up,'FVG',10,5,3).name=='FVG'
    assert primary_signal(up,'BOS',10,5,3).name=='BOS'
    assert primary_signal(up,'ORDER_BLOCK',10,5,3).name=='ORDER_BLOCK'


def test_position_sizing_scales_down_in_high_volatility():
    plan=build_position_plan(1000,.01,2,4,point_value=1,max_unit_size=10,volatility_target_distance=2)
    assert plan.volatility_scalar==.5
    assert plan.risk_cash==5
    assert plan.unit_size==2.5


def test_acceptance_rejects_insufficient_evidence():
    report=evaluate_walk_forward([{'trades':2,'net_pnl':1,'gross_profit':2,'gross_loss':1,'max_drawdown':.01}],[])
    assert report['accepted'] is False
    assert 'enough_folds' in report['rejection_reasons']
    assert 'enough_trades' in report['rejection_reasons']


def test_acceptance_accepts_only_when_all_gates_pass():
    folds=[{'trades':15,'net_pnl':10,'gross_profit':20,'gross_loss':10,'max_drawdown':.02},
           {'trades':15,'net_pnl':8,'gross_profit':18,'gross_loss':10,'max_drawdown':.03},
           {'trades':15,'net_pnl':5,'gross_profit':15,'gross_loss':10,'max_drawdown':.04}]
    trades=[{'pnl':1} for _ in range(45)]
    assert evaluate_walk_forward(folds,trades)['accepted'] is True
