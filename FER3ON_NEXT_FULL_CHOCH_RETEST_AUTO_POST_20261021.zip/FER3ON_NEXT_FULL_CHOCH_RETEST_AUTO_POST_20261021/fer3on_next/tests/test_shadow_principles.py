from fer3on_next.domain import Side
from fer3on_next.entry_quality import assess_entry_quality
from fer3on_next.shadow_analytics import summarize

def test_entry_quality_flags_mid_chase():
    q=assess_entry_quality([100,100.1,100.2,100.3,101.0,101.2],1.0,Side.BUY,.50)
    assert q.late and q.reason=='MID_CHASE'

def test_shadow_requires_evidence():
    report=summarize([{'quality_bucket':'HIGH','won':True}]*10)
    assert not report['evidence_ready']
