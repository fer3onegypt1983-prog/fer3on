from datetime import datetime, timedelta, timezone
from fer3on_next.backtest import run
from fer3on_next.domain import BotConfig, Candle

def test_backtest_runs_on_ohlc_sequence():
    base=datetime(2026,1,1,tzinfo=timezone.utc)
    candles=[]
    price=100.0
    for i in range(120):
        # Deterministic price path used only to test plumbing, not performance.
        drift=0.12 if (i//12)%2==0 else -0.12
        o=price; c=price+drift; h=max(o,c)+0.08; l=min(o,c)-0.08
        candles.append(Candle(base+timedelta(minutes=15*i),o,h,l,c,100))
        price=c
    result=run(candles,BotConfig(lookback=30,impulse_window=12),1000)
    assert result['ending_equity'] > 0
    assert isinstance(result['wait_reasons'],dict)
