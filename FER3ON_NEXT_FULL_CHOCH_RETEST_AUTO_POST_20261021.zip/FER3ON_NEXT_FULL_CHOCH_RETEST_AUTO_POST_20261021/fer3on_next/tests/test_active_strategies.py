from datetime import datetime, timedelta, timezone
from fer3on_next.domain import AccountState, BotConfig, Candle
from fer3on_next.strategy import decide_candidates


def test_active_strategy_candidates_are_explicitly_identified():
    base=datetime(2026,1,1,tzinfo=timezone.utc)
    candles=[]
    price=100.0
    for i in range(120):
        close=price + (0.15 if (i//8)%2==0 else -0.10)
        candles.append(Candle(base+timedelta(minutes=15*i),price,max(price,close)+0.1,min(price,close)-0.1,close,100))
        price=close
    cfg=BotConfig(active_strategies=('TSM','DONCHIAN'), max_concurrent=10)
    decisions=decide_candidates(candles,AccountState(1000,1000),cfg)
    assert {d.strategy_id for d in decisions} == {'TSM','DONCHIAN'}
    assert all(d.metadata.get('active_strategy') is True for d in decisions)
