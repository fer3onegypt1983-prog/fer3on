from datetime import datetime, timedelta, timezone

from fer3on_next.domain import AccountState, BotConfig, Candle, Side
from fer3on_next.experimental_strategies import (
    decide_impulse_midpoint_reversal,
    decide_impulse_retest,
)


def _base(count=40):
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    rows = []
    price = 100.0
    for i in range(count):
        close = price + (0.08 if i % 2 == 0 else -0.08)
        rows.append(Candle(start + timedelta(minutes=15 * i), price,
                           max(price, close) + 0.04, min(price, close) - 0.04, close, 100))
        price = close
    return rows


def _bullish_impulse(rows, index=37):
    prior = rows[index - 1]
    rows[index] = Candle(prior.time + timedelta(minutes=15), prior.close,
                         prior.close + 0.50, prior.close - 0.05, prior.close + 0.45, 200)


def test_impulse_retest_emits_continuation_only_after_closed_midpoint_reclaim():
    rows = _base()
    _bullish_impulse(rows)
    impulse = rows[-3]
    midpoint = (impulse.high + impulse.low) / 2
    rows[-2] = Candle(rows[-3].time + timedelta(minutes=15), impulse.close,
                      impulse.high + 0.02, midpoint - 0.05, midpoint - 0.02, 100)
    rows[-1] = Candle(rows[-2].time + timedelta(minutes=15), midpoint - 0.02,
                      midpoint + 0.35, midpoint - 0.03, midpoint + 0.28, 120)

    decision = decide_impulse_retest(rows, AccountState(1000, 1000), BotConfig())
    assert decision.action == "ENTER"
    assert decision.strategy_id == "IMPULSE_RETEST"
    assert decision.side is Side.BUY
    assert decision.stop < decision.entry < decision.target
    assert "MIDPOINT_RETEST_CONTINUATION" in decision.reason
    assert decision.metadata["impulse"]["midpoint"] == midpoint
    assert decision.metadata["position_sizing"]["unit_size"] > 0


def test_impulse_retest_does_not_enter_without_retest_confirmation():
    rows = _base()
    _bullish_impulse(rows)
    rows[-1] = Candle(rows[-2].time + timedelta(minutes=15), rows[-2].close,
                      rows[-2].close + 0.12, rows[-2].close - 0.02,
                      rows[-2].close + 0.08, 100)
    decision = decide_impulse_retest(rows, AccountState(1000, 1000), BotConfig())
    assert decision.action == "WAIT"
    assert decision.reason == "WAITING_FOR_MIDPOINT_RETEST_CONFIRMATION"


def test_impulse_midpoint_reversal_enters_counter_direction_toward_midpoint():
    rows = _base()
    _bullish_impulse(rows)
    impulse = rows[-3]
    trigger = impulse.high - 0.20 * (impulse.high - impulse.low)
    rows[-2] = Candle(rows[-3].time + timedelta(minutes=15), impulse.close,
                      impulse.high + 0.04, trigger + 0.08, trigger + 0.10, 100)
    entry = trigger - 0.02
    rows[-1] = Candle(rows[-2].time + timedelta(minutes=15), entry + 0.10,
                      rows[-2].high - 0.02, entry - 0.04, entry, 100)

    decision = decide_impulse_midpoint_reversal(rows, AccountState(1000, 1000), BotConfig())
    midpoint = (impulse.high + impulse.low) / 2
    assert decision.action == "ENTER"
    assert decision.strategy_id == "IMPULSE_MIDPOINT_REVERSAL"
    assert decision.side is Side.SELL
    assert decision.target == midpoint
    assert decision.target < decision.entry < decision.stop
    assert "TARGETS_CANDLE_MIDPOINT" in decision.reason


def test_midpoint_reversal_does_not_chase_after_midpoint_was_already_crossed():
    rows = _base()
    _bullish_impulse(rows)
    impulse = rows[-3]
    midpoint = (impulse.high + impulse.low) / 2
    rows[-2] = Candle(rows[-3].time + timedelta(minutes=15), impulse.close,
                      impulse.high, midpoint - 0.05, midpoint - 0.02, 100)
    rows[-1] = Candle(rows[-2].time + timedelta(minutes=15), midpoint - 0.02,
                      midpoint + 0.08, midpoint - 0.08, midpoint - 0.04, 100)
    decision = decide_impulse_midpoint_reversal(rows, AccountState(1000, 1000), BotConfig())
    assert decision.action == "WAIT"
    assert decision.reason == "WAITING_FOR_EARLY_COUNTER_IMPULSE_RETRACE"
