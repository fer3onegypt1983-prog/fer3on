from fer3on_next.domain import Side
from fer3on_next.execution import RiskError
from fer3on_next.mt5_broker import validate_quote_geometry


def test_buy_requires_target_above_current_quote():
    try:
        validate_quote_geometry(Side.BUY, 4172.14, 4169.16, 4169.69, 0.01)
    except RiskError as exc:
        assert "geometry" in str(exc)
    else:
        raise AssertionError("invalid BUY geometry was accepted")


def test_sell_requires_target_below_current_quote():
    try:
        validate_quote_geometry(Side.SELL, 4172.14, 4175.00, 4172.13, 0.01)
    except RiskError:
        raise AssertionError("valid SELL geometry was rejected")


def test_buy_target_must_respect_broker_minimum_distance():
    try:
        validate_quote_geometry(Side.BUY, 100.00, 99.00, 100.005, 0.01)
    except RiskError as exc:
        assert "minimum distance" in str(exc)
    else:
        raise AssertionError("target inside minimum distance was accepted")
