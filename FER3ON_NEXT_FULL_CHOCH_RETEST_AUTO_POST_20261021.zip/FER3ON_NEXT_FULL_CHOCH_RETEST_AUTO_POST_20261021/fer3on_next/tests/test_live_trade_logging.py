import json
from fer3on_next.domain import Decision, Side
from fer3on_next.live_trade_logging import LiveTradeLogger

class Result:
    order=123
    deal=456
    retcode=10009


def test_live_logger_links_decision_order_and_result(tmp_path):
    path=tmp_path/'live.jsonl'; logger=LiveTradeLogger(path,'run-1')
    decision=Decision('ENTER',side=Side.BUY,entry=100,stop=99,target=102,idempotency_key='key-1',strategy_id='FVG',metadata={'thesis_id':'th-1'})
    logger.decision(decision); logger.order_result(decision,Result())
    rows=[json.loads(line) for line in path.read_text().splitlines()]
    assert [r['event'] for r in rows] == ['DECISION','ORDER_RESULT']
    assert {r['correlation_id'] for r in rows} == {'key-1'}
    assert rows[0]['strategy_id']=='FVG'
    assert rows[1]['ticket']==123
