from types import SimpleNamespace

import pytest

from fer3on_next.domain import AccountState, BotConfig, Decision, Side
from fer3on_next.execution import RiskError
from fer3on_next.mt5_broker import COMMENT_TAG, MAGIC_BY_STRATEGY, MT5Broker


class FakeMT5:
    TRADE_ACTION_DEAL = 1
    ORDER_TYPE_BUY = 0
    ORDER_TYPE_SELL = 1
    ORDER_TIME_GTC = 0
    ORDER_FILLING_FOK = 0
    ORDER_FILLING_IOC = 1
    SYMBOL_FILLING_FOK = 1
    SYMBOL_FILLING_IOC = 2
    TRADE_RETCODE_CHECK_DONE = 0
    TRADE_RETCODE_DONE = 10009
    TRADE_RETCODE_DONE_PARTIAL = 10010

    def __init__(self, positions=None, margin_mode=2):
        self._positions = positions or []
        self.requests = []
        self._info = SimpleNamespace(
            digits=2, point=0.01, trade_stops_level=0, trade_tick_size=0.01,
            trade_tick_value_loss=1.0, trade_tick_value=1.0, volume_min=0.01,
            volume_max=10.0, volume_step=0.01, filling_mode=2, visible=True,
        )
        self._account = SimpleNamespace(margin_free=10000.0, equity=1000.0)

    def positions_get(self, symbol=None):
        return list(self._positions)

    def symbol_info_tick(self, symbol):
        return SimpleNamespace(ask=100.01, bid=100.00)

    def symbol_info(self, symbol):
        return self._info

    def account_info(self):
        return self._account

    def order_calc_margin(self, side, symbol, volume, price):
        return 100.0 * volume

    def order_check(self, request):
        return SimpleNamespace(retcode=0)

    def order_send(self, request):
        self.requests.append(dict(request))
        return SimpleNamespace(retcode=getattr(self, "send_retcode", 10009), order=12345, deal=12345)


def _broker(fake, margin_mode="HEDGING"):
    broker = MT5Broker.__new__(MT5Broker)
    broker.mt5 = fake
    broker.symbol = "XAUUSD"
    broker.deviation = 20
    broker.account_mode = "DEMO"
    broker.margin_mode = margin_mode
    return broker


def _decision(strategy="IMPULSE_RETEST"):
    return Decision(
        "ENTER", Side.BUY, 100.0, 99.9, 100.2,
        thesis="test", reason="test", risk_fraction=0.0025,
        idempotency_key=f"key-{strategy}", strategy_id=strategy,
        metadata={"position_sizing": {"unit_size": 0.5}},
    )


def test_mt5_volume_is_calculated_from_tick_value_and_does_not_raise_risk_to_minimum():
    broker = _broker(FakeMT5())
    decision = _decision()
    broker.send(decision, AccountState(1000.0, 1000.0), BotConfig(max_daily_loss=0.02))
    request = broker.mt5.requests[0]
    assert request["magic"] == MAGIC_BY_STRATEGY["IMPULSE_RETEST"]
    assert 0 < request["volume"] < 0.5  # passed metadata is never blindly trusted
    assert request["volume"] <= 0.02  # shared default max lot across all strategy profiles
    assert decision.metadata["execution_sizing"]["estimated_loss_at_stop"] <= 2.5 + 0.25


def test_mt5_refuses_a_minimum_lot_that_exceeds_strategy_risk_budget():
    fake = FakeMT5()
    fake._info.trade_tick_value_loss = 1000.0
    fake._info.trade_tick_value = 1000.0
    broker = _broker(fake)
    with pytest.raises(RiskError, match="minimum broker volume"):
        broker.send(_decision(), AccountState(1000.0, 1000.0), BotConfig(max_daily_loss=0.02))


def test_netting_account_refuses_to_overwrite_an_existing_strategy_position():
    position = SimpleNamespace(magic=MAGIC_BY_STRATEGY["TSM"])
    broker = _broker(FakeMT5([position]), margin_mode="NETTING")
    with pytest.raises(RiskError, match="NETTING account already has a position"):
        broker.send(_decision("IMPULSE_RETEST"), AccountState(1000.0, 1000.0), BotConfig(max_daily_loss=0.02))


def test_hedging_allows_independent_strategy_positions_including_opposite_side():
    fake = FakeMT5()
    broker = _broker(fake, margin_mode="HEDGING")
    account = AccountState(1000.0, 1000.0, open_trades=0)
    cfg = BotConfig(max_daily_loss=0.04, max_unit_size=0.10)
    long_decision = _decision("TSM")
    short_decision = Decision(
        "ENTER", Side.SELL, 100.0, 100.1, 99.8,
        thesis="test short", reason="test", risk_fraction=0.0025,
        idempotency_key="key-IMPULSE_MIDPOINT_REVERSAL",
        strategy_id="IMPULSE_MIDPOINT_REVERSAL", metadata={},
    )
    broker.send(long_decision, account, cfg)
    fake._positions = [SimpleNamespace(magic=MAGIC_BY_STRATEGY["TSM"],
        sl=99.9, volume=0.10, price_open=100.0)]
    account.open_trades = 1
    broker.send(short_decision, account, cfg)
    assert [request["magic"] for request in fake.requests] == [
        MAGIC_BY_STRATEGY["TSM"], MAGIC_BY_STRATEGY["IMPULSE_MIDPOINT_REVERSAL"]
    ]
    assert fake.requests[0]["volume"] <= cfg.max_unit_size
    assert fake.requests[1]["volume"] <= cfg.max_unit_size


def test_partial_fill_is_accepted_and_logged_as_a_broker_result():
    fake = FakeMT5()
    fake.send_retcode = FakeMT5.TRADE_RETCODE_DONE_PARTIAL
    broker = _broker(fake)
    result = broker.send(_decision(), AccountState(1000.0, 1000.0), BotConfig(max_daily_loss=0.02))
    assert result.retcode == FakeMT5.TRADE_RETCODE_DONE_PARTIAL
    assert len(fake.requests) == 1


def test_all_enabled_strategy_profiles_have_unique_mt5_identity():
    from settings import load_settings

    enabled = set(load_settings().enabled_strategies)
    assert enabled == set(MAGIC_BY_STRATEGY)
    assert enabled == set(COMMENT_TAG)
    assert len(MAGIC_BY_STRATEGY.values()) == len(set(MAGIC_BY_STRATEGY.values()))
