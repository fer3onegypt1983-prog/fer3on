from datetime import datetime, timedelta, timezone

from fer3on_next.domain import AccountState, BotConfig, Candle, Decision, Side
from fer3on_next.experimental_strategies import StrategyRuntimeState
from fer3on_next.p2_pullback_candidate import decide_p2_pullback_confirmation


def _candles(count=40, start=100.0):
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    rows = []
    price = start
    for i in range(count):
        close = price + (0.04 if i % 2 == 0 else -0.04)
        rows.append(Candle(t0 + timedelta(minutes=15 * i), price,
                           max(price, close) + 0.02, min(price, close) - 0.02, close, 100))
        price = close
    return rows


def _source(candles, side=Side.BUY):
    entry = candles[-1].close
    return Decision(
        action="ENTER", side=side, entry=entry,
        stop=entry - 0.20 if side is Side.BUY else entry + 0.20,
        target=entry + 1.0 if side is Side.BUY else entry - 1.0,
        reason="TSM_SOURCE_SIGNAL", idempotency_key="source-key-1", strategy_id="TSM",
    )


def _closed_bar(previous, o, h, l, c):
    return Candle(previous.time + timedelta(minutes=15), o, h, l, c, 150)


def test_p2_creates_plan_then_enters_only_after_later_closed_pullback_reclaim():
    rows = _candles()
    cfg = BotConfig(pullback_depth_atr=0.50, pullback_ttl_bars=6,
                    pullback_confirmation_body_atr=0.10, pullback_min_reward_risk=1.35)
    account = AccountState(1000, 1000)
    state = StrategyRuntimeState()

    planned = decide_p2_pullback_confirmation(rows, account, cfg, state, "p2-test", _source(rows))
    assert planned.action == "WAIT"
    assert planned.reason == "PULLBACK_PLAN_CREATED_WAITING_FOR_LATER_CLOSED_BAR"
    plan = state.pending_pullback
    assert plan is not None
    assert plan["source_strategy"] == "TSM"
    assert plan["planned_entry"] < plan["source_entry"]

    # Price dips through the planned pullback level and closes bullish back above it.
    level = plan["planned_entry"]
    confirm = _closed_bar(rows[-1], level - 0.04, level + 0.16, level - 0.08, level + 0.12)
    rows.append(confirm)
    entered = decide_p2_pullback_confirmation(rows, account, cfg, state, "p2-test", None)

    assert entered.action == "ENTER"
    assert entered.strategy_id == "P2_PULLBACK_CONFIRMATION"
    assert entered.side is Side.BUY
    assert entered.stop < entered.entry < entered.target
    assert entered.metadata["source_strategy"] == "TSM"
    assert entered.metadata["execution_model"] == "closed_bar_reclaim_then_market_order"
    assert entered.metadata["entry_order_type"] == "MARKET_AFTER_CLOSED_BAR_CONFIRMATION"
    assert entered.metadata["pullback_confirmation"]["touch_level"] == level
    assert entered.idempotency_key
    assert state.pending_pullback is None


def test_p2_expires_after_configured_number_of_closed_bars():
    rows = _candles()
    cfg = BotConfig(pullback_ttl_bars=2)
    state = StrategyRuntimeState()
    account = AccountState(1000, 1000)
    decide_p2_pullback_confirmation(rows, account, cfg, state, "p2-test", _source(rows))
    assert state.pending_pullback is not None

    for _ in range(3):
        prior = rows[-1]
        rows.append(_closed_bar(prior, prior.close, prior.close + 0.05, prior.close - 0.02, prior.close + 0.01))
        result = decide_p2_pullback_confirmation(rows, account, cfg, state, "p2-test", None)

    assert result.reason == "PULLBACK_PLAN_EXPIRED"
    assert state.pending_pullback is None


def test_p2_invalidates_plan_if_structural_stop_is_touched_before_confirmation():
    rows = _candles()
    cfg = BotConfig()
    state = StrategyRuntimeState()
    account = AccountState(1000, 1000)
    decide_p2_pullback_confirmation(rows, account, cfg, state, "p2-test", _source(rows))
    plan = state.pending_pullback
    assert plan is not None

    stop = plan["stop"]
    rows.append(_closed_bar(rows[-1], stop + 0.05, stop + 0.10, stop - 0.02, stop + 0.03))
    result = decide_p2_pullback_confirmation(rows, account, cfg, state, "p2-test", None)

    assert result.reason == "PULLBACK_PLAN_INVALIDATED_AT_STRUCTURAL_STOP"
    assert state.pending_pullback is None


def test_p2_does_not_reuse_source_signal_candle_as_confirmation():
    rows = _candles()
    # Even if the source candle itself has an attractive range, it can only create the plan.
    rows[-1] = Candle(rows[-1].time, 100.0, 101.0, 99.0, 100.8, 200)
    state = StrategyRuntimeState()
    result = decide_p2_pullback_confirmation(
        rows, AccountState(1000, 1000), BotConfig(), state, "p2-test", _source(rows)
    )
    assert result.action == "WAIT"
    assert result.reason == "PULLBACK_PLAN_CREATED_WAITING_FOR_LATER_CLOSED_BAR"
    assert state.pending_pullback is not None
    assert state.pending_pullback["bars_waited"] == 0
