from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
import pytest

from fer3on_next.trade_history import ClosedTradeStore, sync_mt5_history
from fer3on_next.runtime import run_mt5_history_sync_once, run_mt5_history_watch


class FakeMT5:
    DEAL_ENTRY_IN = 0
    DEAL_ENTRY_OUT = 1
    DEAL_ENTRY_INOUT = 2
    DEAL_ENTRY_OUT_BY = 3

    def __init__(self, deals):
        self.deals = deals
        self.queries = []

    def history_deals_get(self, start, end):
        self.queries.append((start, end))
        return list(self.deals)

    def last_error(self):
        return (0, "ok")

    def shutdown(self):
        self.was_shutdown = True


def deal(ticket, order, position_id, time_s, type_, entry, volume, price,
         profit=0.0, commission=0.0, swap=0.0, fee=0.0,
         magic=26092301, comment="FER3ON_TSM_DEMO", symbol="XAUUSD"):
    return SimpleNamespace(
        ticket=ticket, order=order, position_id=position_id,
        time=int(time_s), time_msc=int(time_s * 1000), type=type_, entry=entry,
        volume=volume, price=price, profit=profit, commission=commission,
        swap=swap, fee=fee, magic=magic, comment=comment, symbol=symbol,
    )


def test_import_groups_closed_position_and_nets_all_costs(tmp_path: Path):
    store = ClosedTradeStore(tmp_path / "history.sqlite3")
    account = "DemoServer:123"
    records = [
        deal(100, 90, 77, 1000, 0, 0, 0.02, 2000.0, commission=-0.20),
        deal(101, 91, 77, 1100, 1, 1, 0.01, 2005.0, profit=2.5, commission=-0.10, swap=-0.01,
             magic=0, comment="tp part"),
        deal(102, 92, 77, 1200, 1, 1, 0.01, 2007.0, profit=3.5, commission=-0.10, fee=-0.02,
             magic=0, comment="tp final"),
    ]
    imported, _ = store.ingest(records, account, "XAUUSD", set(), 0, {1, 3})
    assert imported == 3
    rows = store.closed_trades(account)
    assert len(rows) == 1
    row = rows[0]
    assert row["strategy_id"] == "TSM"
    assert row["side"] == "BUY"
    assert row["entry_volume"] == 0.02
    assert row["exit_volume"] == 0.02
    assert row["gross_profit"] == 6.0
    assert row["commission"] == -0.4
    assert row["swap"] == -0.01
    assert row["fee"] == -0.02
    assert abs(row["net_profit"] - 5.57) < 1e-9
    assert row["outcome"] == "WIN"
    assert row["entry_order_tickets"] == '["90"]'
    assert row["exit_order_tickets"] == '["91", "92"]'
    summary = store.summary(account)
    tsm = next(row for row in summary if row["strategy_id"] == "TSM")
    empty_tree = next(row for row in summary if row["strategy_id"] == "LEVEL_MAP_SCENARIO_TREE")
    assert len(summary) == 9
    assert tsm["wins"] == 1
    assert tsm["win_rate_pct"] == 100.0
    assert empty_tree["closed_trades"] == 0
    store.close()


def test_ingestion_is_idempotent_and_does_not_close_live_positions(tmp_path: Path):
    store = ClosedTradeStore(tmp_path / "history.sqlite3")
    account = "DemoServer:123"
    records = [
        deal(200, 190, 88, 2000, 0, 0, 0.01, 2000.0),
        deal(201, 191, 88, 2100, 1, 1, 0.01, 1990.0, profit=-10.0,
             magic=0, comment="sl"),
    ]
    store.ingest(records, account, "XAUUSD", {"88"}, 0, {1, 3})
    assert store.closed_trades(account) == []

    # Once MT5 no longer reports the position as open, it becomes a closed record.
    store.ingest(records, account, "XAUUSD", set(), 0, {1, 3})
    store.ingest(records, account, "XAUUSD", set(), 0, {1, 3})
    rows = store.closed_trades(account)
    assert len(rows) == 1
    assert rows[0]["outcome"] == "LOSS"
    assert rows[0]["strategy_id"] == "TSM"
    store.close()


def test_sync_uses_initial_lookback_then_overlapping_incremental_window(tmp_path: Path):
    account = "DemoServer:123"
    now = datetime.now(timezone.utc).timestamp()
    mt5 = FakeMT5([
        deal(300, 290, 99, now - 20, 0, 0, 0.01, 2000.0),
        deal(301, 291, 99, now - 10, 1, 1, 0.01, 2002.0, profit=2.0,
             magic=0, comment="closed"),
    ])
    broker = SimpleNamespace(account_id=account, mt5=mt5, positions=lambda: [])
    store = ClosedTradeStore(tmp_path / "history.sqlite3")

    first = sync_mt5_history(broker, store, "XAUUSD", initial_lookback_days=7)
    assert first["deals_returned_by_mt5"] == 2
    assert first["closed_trade_counts_by_strategy"][0]["wins"] == 1
    assert len(store.closed_trades(account)) == 1

    second = sync_mt5_history(broker, store, "XAUUSD", initial_lookback_days=7, overlap_minutes=120)
    assert len(store.closed_trades(account)) == 1
    assert second["query_from_utc"] <= second["query_to_utc"]
    assert store.last_sync(account) is not None
    store.export_csv(account, tmp_path / "closed.csv")
    store.export_summary_csv(account, tmp_path / "summary.csv")
    assert (tmp_path / "closed.csv").is_file()
    assert (tmp_path / "summary.csv").is_file()
    store.close()


def test_reconciliation_matches_successful_orders_to_closed_positions(tmp_path: Path):
    account = "DemoServer:123"
    store = ClosedTradeStore(tmp_path / "history.sqlite3")
    records = [
        deal(400, 390, 111, 3000, 0, 0, 0.01, 2000.0),
        deal(401, 391, 111, 3100, 1, 1, 0.01, 2002.0, profit=2.0,
             magic=0, comment="closed"),
    ]
    store.ingest(records, account, "XAUUSD", set(), 0, {1, 3})
    ledger = tmp_path / "mt5_ledger.jsonl"
    import json
    ledger.write_text("\n".join([
        json.dumps({"event": "ORDER_RESULT", "account_id": account, "event_time": "t1",
                    "retcode": 10009, "ticket": 390, "correlation_id": "c1", "strategy_id": "TSM"}),
        json.dumps({"event": "ORDER_RESULT", "account_id": account, "event_time": "t2",
                    "retcode": 10009, "ticket": 999, "correlation_id": "c2", "strategy_id": "BOS"}),
    ]) + "\n", encoding="utf-8")
    path = store.export_order_reconciliation(account, ledger, tmp_path / "reconciliation.csv")
    content = path.read_text(encoding="utf-8-sig")
    assert "CLOSED" in content
    assert "NOT_YET_MATCHED_TO_CLOSED_TRADE" in content
    assert "390" in content and "999" in content
    store.close()


def test_history_only_runtime_reads_and_shuts_down_without_trade_methods(tmp_path: Path, monkeypatch):
    now = datetime.now(timezone.utc).timestamp()
    mt5 = FakeMT5([
        deal(500, 490, 222, now - 20, 0, 0, 0.01, 2000.0),
        deal(501, 491, 222, now - 10, 1, 1, 0.01, 2001.0, profit=1.0,
             magic=0, comment="close"),
    ])

    class ReadOnlyBroker:
        account_id = "DemoServer:456"
        account_mode = "DEMO"
        margin_mode = "HEDGING"
        symbol = "XAUUSD"
        def __init__(self, symbol, mode):
            assert mode == "DEMO"
            self.mt5 = mt5
        def positions(self):
            return []

    monkeypatch.setattr("fer3on_next.runtime.MT5Broker", ReadOnlyBroker)
    result = run_mt5_history_sync_once("XAUUSD", "DEMO", tmp_path / "hist.sqlite3", 30)
    assert result["deals_returned_by_mt5"] == 2
    assert result["closed_trade_counts_by_strategy"][0]["closed_trades"] == 1
    assert Path(result["closed_trades_csv"]).is_file()
    assert Path(result["summary_csv"]).is_file()
    assert Path(result["order_reconciliation_csv"]).is_file()
    assert mt5.was_shutdown is True


def test_history_only_refuses_non_demo_mode_before_mt5_initialization(tmp_path: Path, monkeypatch):
    def fail_broker(*args, **kwargs):
        raise AssertionError("non-demo mode must be rejected before initializing MT5")
    monkeypatch.setattr("fer3on_next.runtime.MT5Broker", fail_broker)
    with pytest.raises(ValueError, match="restricted to a verified DEMO"):
        run_mt5_history_sync_once("XAUUSD", "LIVE", tmp_path / "history.sqlite3", 30)


def test_history_watch_polls_and_stops_without_trade_loop(tmp_path: Path, monkeypatch, capsys):
    now = datetime.now(timezone.utc).timestamp()
    mt5 = FakeMT5([
        deal(600, 590, 333, now - 20, 0, 0, 0.01, 2000.0),
        deal(601, 591, 333, now - 10, 1, 1, 0.01, 2003.0, profit=3.0,
             magic=0, comment="close"),
    ])

    class ReadOnlyBroker:
        account_id = "DemoServer:789"
        account_mode = "DEMO"
        margin_mode = "HEDGING"
        symbol = "XAUUSD"
        def __init__(self, symbol, mode):
            assert mode == "DEMO"
            self.mt5 = mt5
        def positions(self):
            return []

    def stop_after_one_poll(_):
        raise KeyboardInterrupt

    monkeypatch.setattr("fer3on_next.runtime.MT5Broker", ReadOnlyBroker)
    monkeypatch.setattr("fer3on_next.runtime.time.sleep", stop_after_one_poll)
    result = run_mt5_history_watch("XAUUSD", "DEMO", tmp_path / "watch.sqlite3", 30, 60,
                                   tmp_path / "missing_ledger.jsonl")
    output = capsys.readouterr().out
    assert "[HISTORY-ONLY]" in output
    assert "3.0" in output
    assert Path(result["closed_trades_csv"]).is_file()
    assert Path(result["summary_csv"]).is_file()
    assert Path(result["order_reconciliation_csv"]).is_file()
    assert mt5.was_shutdown is True
