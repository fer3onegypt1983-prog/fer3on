from datetime import datetime, timedelta, timezone
from fer3on_next.domain import Candle, Side
from fer3on_next.market import atr
from fer3on_next.structure import analyze_structure, Label
from fer3on_next.trend import infer_trend
from fer3on_next.levels import build_zones
from fer3on_next.structural_sl_tp import structural_exit

def candles_from_points(points):
    base=datetime(2026,1,1,tzinfo=timezone.utc)
    out=[]
    for i,p in enumerate(points):
        out.append(Candle(base+timedelta(minutes=i),p+0.1,p+0.5,p-0.5,p,100))
    return out

def test_hh_hl_structure_and_uptrend():
    cs=candles_from_points([100,105,102,108,104,110,106,112,108,114])
    s=analyze_structure(cs,1,1)
    labels=[p.label for p in s.points if p.label]
    assert Label.HH in labels and Label.HL in labels
    assert infer_trend(s).direction=='UP'

def test_structural_stop_uses_protected_hl_not_last_bar():
    cs=candles_from_points([100,105,102,108,104,110,106,112,108,114])
    s=analyze_structure(cs,1,1); a=atr(cs,5); zones=build_zones(s,a)
    out=structural_exit(Side.BUY,112,a,s,zones)
    assert out['anchor_label']=='HL'
    assert out['anchor_index']==8
    assert out['stop'] < 108
