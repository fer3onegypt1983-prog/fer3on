from datetime import datetime, timedelta, timezone

from fer3on_next.domain import AccountState, BotConfig, Candle
from fer3on_next.experimental_strategies import StrategyRuntimeState
from fer3on_next.runtime import run_mt5_once


class FakeBroker:
    account_mode = "DEMO"
    margin_mode = "HEDGING"
    account_id = "demo:1"

    def __init__(self, candles):
        self._candles = candles
        self.management_calls = 0
        self.sent = []

    def candles(self, timeframe, count):
        return self._candles[-count:]

    def account_state(self):
        return AccountState(1000, 1000)

    def paused_strategies(self, cfg):
        return {}

    def positions_by_strategy(self):
        return {}

    def manage_positions(self, price, cfg, logger):
        self.management_calls += 1
        return []

    def send(self, decision, account, cfg, logger=None):
        self.sent.append(decision)
        return object()


class FakeLogger:
    def __init__(self):
        self.logged = []

    def decision(self, decision):
        self.logged.append(decision)

    def order_rejected(self, decision, error):
        raise AssertionError(error)

    def order_result(self, decision, result):
        pass

    def duplicate_skipped(self, decision, fingerprint):
        pass


def test_runtime_handles_same_closed_candle_once_across_polls():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    bars = []
    price = 100.0
    for i in range(180):
        close = price + (0.12 if (i // 8) % 2 == 0 else -0.11)
        bars.append(Candle(start + timedelta(minutes=15*i), price,
                           max(price, close)+0.1, min(price, close)-0.1, close, 100))
        price = close
    cfg = BotConfig(active_strategies=("TSM",))
    broker = FakeBroker(bars)
    logger = FakeLogger()
    states = {"TSM": StrategyRuntimeState()}
    fingerprints = set()
    profiles = {"TSM": (cfg, "next-baseline-0.1")}

    run_mt5_once(cfg, broker, profiles, states, logger, fingerprints)
    first_log_count = len(logger.logged)
    first_management_count = broker.management_calls
    run_mt5_once(cfg, broker, profiles, states, logger, fingerprints)

    assert first_log_count == 1
    assert len(logger.logged) == first_log_count
    assert first_management_count == 1
    assert broker.management_calls == first_management_count
    assert not broker.sent
