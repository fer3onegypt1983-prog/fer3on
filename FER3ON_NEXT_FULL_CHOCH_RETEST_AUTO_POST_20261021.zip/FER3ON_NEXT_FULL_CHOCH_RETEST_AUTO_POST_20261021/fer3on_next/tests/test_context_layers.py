from datetime import datetime,timedelta,timezone
from fer3on_next.domain import Candle
from fer3on_next.calendar_levels import build_reference_levels
from fer3on_next.volume_profile import build_volume_profile
from fer3on_next.mtf import aggregate,timeframe_views

def test_context_layers_return_values():
    base=datetime(2026,1,1,tzinfo=timezone.utc); cs=[]; price=2000
    for i in range(160):
        o=price; c=price+(0.4 if i%7<4 else -0.3); cs.append(Candle(base+timedelta(minutes=15*i),o,max(o,c)+.2,min(o,c)-.2,c,100+i)); price=c
    levels=build_reference_levels(cs)
    assert levels
    profile=build_volume_profile(cs[-80:])
    assert profile.poc>0 and profile.value_area_low<=profile.poc<=profile.value_area_high
    assert len(aggregate(cs,4))==40
    views=timeframe_views(cs)
    assert set(views)=={'H1','H4'}
