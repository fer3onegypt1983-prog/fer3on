from fer3on_next.analytics import analyze_opportunities

def test_not_filled_is_not_counted_as_loss():
    report=analyze_opportunities([
        {'status':'NOT_FILLED','reason':'SPREAD_TOO_WIDE','pnl':None},
        {'status':'LOSS','reason':'ENTRY_EVENT','pnl':-2,'metadata':{'entry_quality':{'reason':'TIMING_ACCEPTED'}}},
        {'status':'WIN','reason':'ENTRY_EVENT','pnl':3,'metadata':{'entry_quality':{'reason':'TIMING_ACCEPTED'}}},
    ])
    assert report['by_reason']['SPREAD_TOO_WIDE']['losses']==0
    assert report['by_reason']['ENTRY_EVENT']['losses']==1
    assert report['by_entry_quality']['TIMING_ACCEPTED']['resolved']==2
