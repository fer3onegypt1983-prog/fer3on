from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest

from fer3on_next.domain import AccountState, BotConfig, Candle, Decision, Side
from fer3on_next.stage6_replay import ReplayPosition, intrabar_exit, load_semicolon_ohlcv, run_replay
from fer3on_next.strategy import decide_candidates


def _position(side=Side.BUY, entry=100.0, stop=95.0, target=110.0):
    decision = Decision("ENTER", side=side, entry=entry, stop=stop, target=target)
    return ReplayPosition(
        strategy_id="TSM", decision=decision,
        entry_time=datetime(2024, 1, 2, 10, tzinfo=timezone.utc),
        entry=entry, stop=stop, target=target,
        risk_distance=abs(entry - stop), risk_fraction=0.01, entry_equity=1000.0,
        signal_time=datetime(2024, 1, 2, 9, 45, tzinfo=timezone.utc),
    )


def test_loader_keeps_source_wall_clock_without_timezone_conversion(tmp_path):
    path = tmp_path / "m15.csv"
    path.write_text(
        "Date;Open;High;Low;Close;Volume\n"
        "2024.01.02 10:15;100;102;99;101;250\n",
        encoding="utf-8",
    )
    candles, digest = load_semicolon_ohlcv(path)
    assert candles[0].time == datetime(2024, 1, 2, 10, 15, tzinfo=timezone.utc)
    assert len(digest) == 64
    assert candles[0].volume == 250


def test_loader_rejects_non_ascending_time(tmp_path):
    path = tmp_path / "bad.csv"
    path.write_text(
        "Date;Open;High;Low;Close;Volume\n"
        "2024.01.02 10:15;100;102;99;101;250\n"
        "2024.01.02 10:15;101;103;100;102;250\n",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="Non-ascending"):
        load_semicolon_ohlcv(path)


def test_both_stop_and_target_hit_assumes_stop_first():
    position = _position()
    candle = type("Bar", (), {"open": 100.0, "high": 111.0, "low": 94.0})()
    assert intrabar_exit(position, candle) == (95.0, "AMBIGUOUS_STOP_FIRST", True)


def test_gap_through_stop_fills_at_open_not_stop():
    position = _position()
    candle = type("Bar", (), {"open": 93.0, "high": 96.0, "low": 92.0})()
    assert intrabar_exit(position, candle) == (93.0, "STOP_GAP", False)


def test_sell_ambiguous_bar_also_assumes_stop_first():
    position = _position(side=Side.SELL, entry=100.0, stop=105.0, target=90.0)
    candle = type("Bar", (), {"open": 100.0, "high": 106.0, "low": 89.0})()
    assert intrabar_exit(position, candle) == (105.0, "AMBIGUOUS_STOP_FIRST", True)


def test_decision_engine_returns_wait_for_strategy_with_open_position():
    bar = Candle(datetime(2024, 1, 2, 10, tzinfo=timezone.utc), 100, 101, 99, 100, 10)
    cfg = BotConfig(active_strategies=("TSM",))
    decisions = decide_candidates(
        [bar], AccountState(1000, 1000), cfg,
        open_positions_by_strategy={"TSM": 1},
    )
    assert len(decisions) == 1
    assert decisions[0].action == "WAIT"
    assert decisions[0].reason == "STRATEGY_POSITION_ALREADY_OPEN"


def test_replay_uses_only_prior_closed_bars_and_next_open_fill(monkeypatch):
    bars = [
        Candle(datetime(2024, 1, 2, 10, 0, tzinfo=timezone.utc) + timedelta(minutes=15 * i), 100, 102, 98, 100, 10)
        for i in range(85)
    ]
    bars[82] = Candle(bars[82].time, 100.5, 102, 100, 101, 10)
    observed = []

    def fake_decide(history, account, cfg, **kwargs):
        observed.append(history[-1].time)
        return [Decision(
            "ENTER", side=Side.BUY, entry=100.0, stop=95.0, target=110.0,
            risk_fraction=0.01, idempotency_key="causal-test", strategy_id="TSM",
        )]

    monkeypatch.setattr("fer3on_next.stage6_replay.decide_candidates", fake_decide)
    profile = SimpleNamespace(
        bot_config=BotConfig(lookback=80, active_strategies=("TSM",), max_concurrent=1),
        version="test-1", config_sha256="test-hash",
    )
    result = run_replay(bars, {"TSM": profile}, selected=("TSM",), history_bars=80)
    trade = result["strategies"]["TSM"]["trades_ledger"][0]
    assert observed[0] == bars[81].time
    assert trade["signal_time"] == bars[81].time.isoformat()
    assert trade["entry_time"] == bars[82].time.isoformat()
    assert trade["fill_open"] == 100.5
