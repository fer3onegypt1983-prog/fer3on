from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone

import pytest

from fer3on_next.domain import AccountState, BotConfig, Candle, Side
from fer3on_next.experimental_strategies import StrategyRuntimeState, decide_scenario_tree
from fer3on_next.scenario_tree import (
    LevelZone,
    OutcomeObservation,
    ProbabilityEstimate,
    ScenarioBranch,
    ScenarioTree,
    ScenarioTreeConfig,
    advance_scenario_tree,
    build_scenario_tree,
    estimate_probability,
)

UTC = timezone.utc


def wave_candles(count: int = 170) -> list[Candle]:
    base = datetime(2026, 1, 1, tzinfo=UTC)
    pattern = [100, 102, 104, 102, 100, 98, 96, 98, 100, 102, 104, 102, 100, 98, 96, 98]
    points = [pattern[i % len(pattern)] for i in range(count)]
    result = []
    for i, close in enumerate(points):
        op = points[i - 1] if i else close
        result.append(Candle(base + timedelta(minutes=15 * i), op, max(op, close) + 0.2,
                             min(op, close) - 0.2, close, 100))
    return result


def test_build_freezes_map_and_creates_both_branches_before_touch():
    config = ScenarioTreeConfig(merge_distance_atr=0.05, reference_half_width_atr=0.01)
    candles = wave_candles()
    tree = build_scenario_tree(candles, "XAUUSD", config)
    repeat = build_scenario_tree(candles, "XAUUSD", config)

    assert tree.strategy_id == "LEVEL_MAP_SCENARIO_TREE"
    assert tree.as_of == candles[-1].time
    assert tree.map_snapshot_id == repeat.map_snapshot_id
    assert tree.data_sha256 and tree.map_snapshot_id
    assert tree.levels
    assert len(tree.branches) == 2 * len(tree.levels)
    for level in tree.levels:
        branches = [branch for branch in tree.branches if branch.level_id == level.level_id]
        assert {branch.branch_kind for branch in branches} == {"BOUNCE", "BREAK_RETEST"}
        assert all(branch.state == "PLANNED" for branch in branches)
        assert all(branch.probability.status == "INSUFFICIENT_DATA" for branch in branches)
        assert all(branch.probability.is_execution_gate is False for branch in branches)

    revised = list(candles)
    revised[10] = replace(revised[10], volume=revised[10].volume + 1)
    different_data = build_scenario_tree(revised, "XAUUSD", config)
    assert different_data.data_sha256 != tree.data_sha256
    assert different_data.map_snapshot_id != tree.map_snapshot_id


def test_branches_without_a_next_level_use_explicit_rr_fallback_target():
    tree = build_scenario_tree(wave_candles(), "XAUUSD", ScenarioTreeConfig(
        merge_distance_atr=0.05, reference_half_width_atr=0.01,
        fallback_target_rr=1.50, min_reward_risk=1.25,
    ))
    fallbacks = [branch for branch in tree.branches if branch.target_level_id is None]
    assert fallbacks
    assert all(branch.target_policy == "RR_FALLBACK_NO_NEXT_LEVEL" for branch in fallbacks)
    assert all(branch.target_price is not None for branch in fallbacks)
    assert all(branch.eligible_after_trigger for branch in fallbacks)
    assert all(branch.planned_reward_risk >= 1.25 for branch in fallbacks)


def test_map_does_not_include_levels_in_the_middle_or_wrong_side():
    tree = build_scenario_tree(wave_candles(), "XAUUSD", ScenarioTreeConfig(
        merge_distance_atr=0.05, reference_half_width_atr=0.01
    ))
    for level in tree.levels:
        if level.kind == "SUPPORT":
            assert level.high < tree.current_price
        else:
            assert level.low > tree.current_price


def test_probability_uses_rolling_window_filters_future_and_deduplicates():
    config = ScenarioTreeConfig(minimum_probability_samples=30)
    as_of = datetime(2026, 4, 1, tzinfo=UTC)
    rows = [
        OutcomeObservation(
            observation_id=f"sample-{i}",
            resolved_at=as_of - timedelta(days=i),
            branch_kind="BOUNCE",
            level_kind="SUPPORT",
            target_before_stop=(i % 3 != 0),
            source_group="CALENDAR",
        )
        for i in range(30)
    ]
    rows += [rows[0], OutcomeObservation("future", as_of + timedelta(seconds=1), "BOUNCE", "SUPPORT", True, "CALENDAR")]
    estimate = estimate_probability(rows, "BOUNCE", "SUPPORT", "CALENDAR", as_of, config)
    assert estimate.status == "ESTIMATED"
    assert estimate.sample_count == 30
    assert estimate.lower_95 <= estimate.estimate <= estimate.upper_95
    assert estimate.is_execution_gate is False

    other_source = estimate_probability(rows, "BOUNCE", "SUPPORT", "CONFIRMED_SWING", as_of, config)
    assert other_source.status == "INSUFFICIENT_DATA"
    assert other_source.sample_count == 0


def _probability(as_of: datetime) -> ProbabilityEstimate:
    return ProbabilityEstimate(
        "INSUFFICIENT_DATA", None, None, None, 0, 0,
        as_of - timedelta(days=90), as_of, "unit-test", "CONFIRMED_SWING", False
    )


def _manual_tree(eligible: bool = True) -> tuple[ScenarioTree, ScenarioBranch]:
    as_of = datetime(2026, 1, 5, 12, 0, tzinfo=UTC)
    support = LevelZone("support", "SUPPORT", 99.0, 100.0, ("CONFIRMED_SWING:test",), 0.7, as_of)
    lower = LevelZone("lower-support", "SUPPORT", 89.0, 90.0, ("CONFIRMED_SWING:lower",), 0.6, as_of)
    resistance = LevelZone("resistance", "RESISTANCE", 110.0, 111.0, ("CONFIRMED_SWING:high",), 0.6, as_of)
    config = ScenarioTreeConfig(break_buffer_atr=0.05, break_min_body_atr=0.50,
                                stop_buffer_atr=0.15, max_retest_bars=3)
    branch = ScenarioBranch(
        branch_id="support-break-sell", level_id="support", level_kind="SUPPORT",
        branch_kind="BREAK_RETEST", side=Side.SELL,
        trigger="closed break then retest", confirmation="closed bar retest",
        order_policy="WAIT_FOR_CLOSED_BREAK_THEN_RETEST; NEVER_CHASE",
        entry_low=99.0, entry_high=100.0, stop_price=100.15,
        target_level_id="lower-support" if eligible else None,
        target_price=90.0 if eligible else None,
        planned_reward_risk=9.0 / 1.15 if eligible else None,
        eligible_after_trigger=eligible,
        block_reason=None if eligible else "NO_NEXT_TARGET_LEVEL",
        invalidation="close back above zone", expiry_bars=3,
        calibration_group="CONFIRMED_SWING", probability=_probability(as_of),
    )
    tree = ScenarioTree(
        strategy_id="LEVEL_MAP_SCENARIO_TREE", strategy_version="test", symbol="XAUUSD",
        as_of=as_of, current_price=104.0, atr_value=1.0,
        levels=(support, lower, resistance), branches=(branch,), config=config,
        config_sha256="test-config", map_snapshot_id="test-map",
        current_context="LEVEL_APPROACHING", context_reason="APPROACHING_SUPPORT",
        last_closed_time=as_of,
    )
    return tree, branch


def test_wick_below_support_does_not_confirm_break_or_send_chase():
    tree, branch = _manual_tree()
    wick = Candle(tree.as_of + timedelta(minutes=15), 99.8, 100.0, 98.4, 99.4, 100)
    advanced = advance_scenario_tree(tree, wick)
    result = advanced.branches[0]
    assert result.branch_id == branch.branch_id
    assert result.state == "PLANNED"
    assert "NEVER_CHASE" in result.order_policy


def test_closed_break_waits_then_confirms_only_after_later_retest():
    tree, _ = _manual_tree()
    break_bar = Candle(tree.as_of + timedelta(minutes=15), 99.5, 99.8, 98.3, 98.5, 100)
    after_break = advance_scenario_tree(tree, break_bar)
    assert after_break.branches[0].state == "WAIT_RETEST"
    assert after_break.branches[0].state_reason == "CLOSED_BREAK_CONFIRMED_WAIT_FOR_RETEST"

    retest = Candle(break_bar.time + timedelta(minutes=15), 99.4, 99.6, 98.9, 98.8, 100)
    after_retest = advance_scenario_tree(after_break, retest)
    assert after_retest.branches[0].state == "CONFIRMED"
    assert after_retest.branches[0].state_reason == "CLOSED_RETEST_REJECTED_FROM_BELOW"


def test_no_target_turns_a_confirmed_pattern_into_no_trade():
    tree, _ = _manual_tree(eligible=False)
    break_bar = Candle(tree.as_of + timedelta(minutes=15), 99.5, 99.8, 98.3, 98.5, 100)
    after_break = advance_scenario_tree(tree, break_bar)
    retest = Candle(break_bar.time + timedelta(minutes=15), 99.4, 99.6, 98.9, 98.8, 100)
    after_retest = advance_scenario_tree(after_break, retest)
    assert after_retest.branches[0].state == "NO_TRADE"
    assert after_retest.branches[0].state_reason == "NO_NEXT_TARGET_LEVEL"


def test_non_monotonic_and_naive_times_are_rejected():
    candles = wave_candles()
    with pytest.raises(ValueError, match="strictly increasing"):
        build_scenario_tree(candles + [candles[-1]], "XAUUSD")
    bad = list(candles)
    bad[-1] = replace(bad[-1], time=bad[-1].time.replace(tzinfo=None))
    with pytest.raises(ValueError, match="timezone-aware"):
        build_scenario_tree(bad, "XAUUSD")


def test_planner_seeds_bounce_wait_from_prior_touch_but_never_enters_on_that_touch():
    candles = wave_candles()
    initial = build_scenario_tree(candles, "XAUUSD", ScenarioTreeConfig(
        merge_distance_atr=0.05, reference_half_width_atr=0.01
    ))
    level = next(item for item in initial.levels if any(source.startswith("CALENDAR:PREVIOUS_DAY_") for source in item.sources))
    last = replace(candles[-1], open=level.midpoint, close=level.midpoint,
                   high=level.high, low=level.low)
    candles[-1] = last
    tree = build_scenario_tree(candles, "XAUUSD", ScenarioTreeConfig(
        merge_distance_atr=0.05, reference_half_width_atr=0.01
    ))
    assert tree.current_context == "LEVEL_TOUCHED_WAITING_FOR_REJECTION"
    touched_levels = {level.level_id for level in tree.levels if level.low <= tree.current_price <= level.high}
    assert touched_levels
    for branch in tree.branches:
        if branch.level_id not in touched_levels:
            continue
        if branch.branch_kind == "BOUNCE":
            assert branch.state == "TOUCHED"
            assert branch.state_reason == "PRIOR_CLOSED_BAR_TOUCHED_WAITING_FOR_REJECTION"
        else:
            assert branch.state == "NO_TRADE"


def test_second_closed_candle_can_confirm_a_preplanned_bounce_after_touch():
    tree, _ = _manual_tree()
    support = tree.levels[0]
    bounce = ScenarioBranch(
        branch_id="support-bounce-buy", level_id="support", level_kind="SUPPORT",
        branch_kind="BOUNCE", side=Side.BUY,
        trigger="touch then bullish close above zone", confirmation="closed bullish displacement",
        order_policy="WAIT_FOR_CLOSED_BAR_CONFIRMATION_THEN_LIMIT_OR_RETEST",
        entry_low=99.0, entry_high=100.0, stop_price=98.85,
        target_level_id="resistance", target_price=110.0,
        planned_reward_risk=10.0 / 1.15, eligible_after_trigger=True,
        block_reason=None, invalidation="close below zone", expiry_bars=64,
        calibration_group="CONFIRMED_SWING", probability=_probability(tree.as_of),
    )
    tree = replace(tree, branches=(bounce,))
    touched = Candle(tree.as_of + timedelta(minutes=15), 99.8, 100.0, 99.2, 99.7, 100)
    after_touch = advance_scenario_tree(tree, touched)
    assert after_touch.branches[0].state == "TOUCHED"

    confirm = Candle(touched.time + timedelta(minutes=15), 99.8, 101.0, 100.2, 100.9, 100)
    after_confirm = advance_scenario_tree(after_touch, confirm)
    assert after_confirm.branches[0].state == "CONFIRMED"
    assert after_confirm.branches[0].state_reason == "CLOSED_BAR_BOUNCE_CONFIRMED"


def test_scenario_strategy_emits_trade_only_after_frozen_break_then_later_retest():
    tree, _ = _manual_tree()
    history = []
    start = tree.as_of - timedelta(minutes=15 * 15)
    for i in range(15):
        t = start + timedelta(minutes=15 * i)
        history.append(Candle(t, 104.0, 104.2, 103.8, 104.0, 100))
    break_bar = Candle(tree.as_of + timedelta(minutes=15), 99.5, 99.8, 98.3, 98.5, 100)
    retest = Candle(break_bar.time + timedelta(minutes=15), 99.4, 99.6, 98.9, 98.8, 100)
    candles = history + [break_bar, retest]
    cfg = BotConfig(
        lookback=14, atr_period=14,
        scenario_break_min_body_atr=0.5,
        scenario_min_reward_risk=1.35,
    )
    state = StrategyRuntimeState(scenario_tree=tree)
    decision = decide_scenario_tree(candles, AccountState(1000, 1000), cfg, state)

    assert decision.action == "ENTER"
    assert decision.strategy_id == "LEVEL_MAP_SCENARIO_TREE"
    assert decision.side is Side.SELL
    assert decision.target < decision.entry < decision.stop
    branch = decision.metadata["scenario_tree"]["branches"]
    assert any(item["state"] == "CONFIRMED" and item["branch_kind"] == "BREAK_RETEST" for item in branch)
    assert decision.metadata["scenario_tree"]["map_snapshot_id"] == tree.map_snapshot_id
