from datetime import datetime,timedelta,timezone
from fer3on_next.domain import Candle
from fer3on_next.data_quality import validate_candles
from fer3on_next.execution_quality import evaluate_execution_quality

def test_data_quality_rejects_bad_ohlc():
    t=datetime(2026,1,1,tzinfo=timezone.utc)
    result=validate_candles([Candle(t,100,99,98,98.5,1)])
    assert not result.valid and 'INVALID_OHLC' in result.reasons

def test_execution_quality_rejects_wide_spread():
    result=evaluate_execution_quality(1,2,1,0.3)
    assert not result['approved'] and result['reason']=='SPREAD_TOO_WIDE'
