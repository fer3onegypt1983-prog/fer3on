from __future__ import annotations

import builtins
import json
from pathlib import Path

import pytest

from fer3on_next.domain import BotConfig
from main import main
from settings import SettingsError, load_settings

ROOT = Path(__file__).resolve().parents[1]


def test_all_nine_strategies_have_separate_enabled_profiles():
    settings = load_settings()
    assert settings.default_mode == "inspect"
    assert settings.enabled_strategies == (
        "TSM", "DONCHIAN", "FVG_MODERATE", "BOS", "ORDER_BLOCK_MODERATE",
        "LEVEL_MAP_SCENARIO_TREE", "IMPULSE_RETEST", "IMPULSE_MIDPOINT_REVERSAL",
        "P2_PULLBACK_CONFIRMATION",
    )
    for strategy_id, profile in settings.strategies.items():
        assert profile.bot_config.primary_strategy == strategy_id
        assert profile.bot_config.active_strategies == (strategy_id,)
        assert profile.bot_config.max_unit_size == 0.02
        if strategy_id == "TSM":
            assert profile.version == "tsm-choch-retest-0.2.0"
        elif strategy_id == "BOS":
            assert profile.version == "next-baseline-0.1"
        elif strategy_id == "DONCHIAN":
            assert profile.version == "donchian-breakout-retest-0.2.0"
        else:
            assert profile.version != "next-baseline-0.1"
        assert profile.config_sha256

    assert settings.strategies["FVG_MODERATE"].bot_config.fvg_max_age == 36
    assert settings.strategies["FVG_MODERATE"].bot_config.fvg_min_gap_atr == 0.07
    assert settings.strategies["FVG_MODERATE"].bot_config.fvg_min_displacement_atr == 0.50
    assert settings.strategies["ORDER_BLOCK_MODERATE"].bot_config.ob_max_age == 36
    assert settings.strategies["ORDER_BLOCK_MODERATE"].bot_config.ob_min_displacement_atr == 0.45
    assert settings.strategies["ORDER_BLOCK_MODERATE"].bot_config.ob_max_width_atr == 2.00


def test_remaining_baseline_profiles_preserve_next_values():
    settings = load_settings()
    defaults = BotConfig()
    assert settings.strategies["TSM"].bot_config.momentum_lookback == defaults.momentum_lookback
    donchian = settings.strategies["DONCHIAN"].bot_config
    assert (donchian.donchian_entry_window, donchian.donchian_exit_window) == (
        defaults.donchian_entry_window, defaults.donchian_exit_window
    )
    assert "FVG" not in settings.strategies
    assert "ORDER_BLOCK" not in settings.strategies
    assert not (ROOT / "config" / "strategies" / "fvg.toml").exists()
    assert not (ROOT / "config" / "strategies" / "order_block.toml").exists()


def test_unknown_global_setting_fails_closed(tmp_path):
    source = (ROOT / "config" / "settings.toml").read_text(encoding="utf-8")
    bad_path = tmp_path / "bad-settings.toml"
    source = source.replace('timeframe = "M15"', 'timeframe = "M15"\nunknown_switch = true')
    bad_path.write_text(source, encoding="utf-8")
    with pytest.raises(SettingsError, match="Unknown"):
        load_settings(bad_path)


def test_removed_original_profiles_are_not_loadable(capsys):
    assert main(["--mode", "inspect", "--strategies", "FVG,ORDER_BLOCK"]) == 2
    assert "Unknown strategy id(s): FVG, ORDER_BLOCK" in capsys.readouterr().err


def test_inspect_is_read_only_and_prints_config_digest(capsys):
    assert main(["--mode", "inspect", "--strategies", "TSM,FVG_MODERATE"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert [item["id"] for item in payload["selected_strategies"]] == ["TSM", "FVG_MODERATE"]
    assert payload["config_sha256"]
    assert payload["safety"] == {
        "mt5_imported": False,
        "mt5_adapter_available": True,
        "orders_sent_during_inspect": False,
        "live_requires_explicit_ack": True,
    }


def test_streaming_paper_mode_still_fails_closed(capsys):
    assert main(["--mode", "paper"]) == 3
    assert "streaming PAPER mode is not implemented" in capsys.readouterr().err


def test_mt5_never_starts_from_a_configuration_default_without_explicit_cli_mode(tmp_path, capsys):
    source = (ROOT / "config" / "settings.toml").read_text(encoding="utf-8")
    source = source.replace('default_mode = "inspect"', 'default_mode = "demo"')
    path = tmp_path / "settings.toml"
    path.write_text(source, encoding="utf-8")
    assert main(["--config", str(path)]) == 2
    assert "requires an explicit --mode" in capsys.readouterr().err


def test_explicit_mt5_mode_passes_all_enabled_profiles(monkeypatch, capsys):
    observed = {}

    def fake_run(strategy_configs, mode, interval_seconds, once):
        observed.update({"strategies": tuple(strategy_configs), "mode": mode,
                         "interval": interval_seconds, "once": once})
        return {"account_mode": "DEMO", "strategies": tuple(strategy_configs)}

    monkeypatch.setattr("main.run_mt5_loop", fake_run)
    assert main(["--mode", "mt5", "--once"]) == 0
    capsys.readouterr()
    assert observed["mode"] == "AUTO"
    assert observed["once"] is True
    assert observed["strategies"] == load_settings().enabled_strategies


@pytest.mark.parametrize("mode,expected", [("demo", "DEMO"), ("live", "LIVE")])
def test_explicit_account_modes_are_forwarded_only_after_user_selection(mode, expected, monkeypatch, capsys):
    observed = {}

    def fake_run(strategy_configs, mode, interval_seconds, once):
        observed["mode"] = mode
        return {"account_mode": mode, "strategies": tuple(strategy_configs)}

    monkeypatch.setattr("main.run_mt5_loop", fake_run)
    assert main(["--mode", mode, "--strategies", "TSM,LEVEL_MAP_SCENARIO_TREE", "--once"]) == 0
    capsys.readouterr()
    assert observed["mode"] == expected


def test_main_runs_each_selected_strategy_as_separate_offline_backtest(tmp_path, capsys):
    config_source = (ROOT / "config" / "settings.toml").read_text(encoding="utf-8")
    config_source = config_source.replace('reports_dir = "reports/runs"', f'reports_dir = "{tmp_path.as_posix()}"')
    config_path = tmp_path / "settings.toml"
    config_path.write_text(config_source, encoding="utf-8")

    csv_path = tmp_path / "bars.csv"
    rows = ["time,open,high,low,close,volume"]
    price = 100.0
    for i in range(125):
        next_price = price + (0.15 if (i // 8) % 2 == 0 else -0.10)
        rows.append(f"2026-01-{(i // 96) + 1:02d}T{(i % 96) // 4:02d}:{((i % 4) * 15):02d}:00+00:00,{price},{max(price, next_price) + 0.1},{min(price, next_price) - 0.1},{next_price},100")
        price = next_price
    csv_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

    code = main(["--config", str(config_path), "--mode", "backtest", "--strategies", "all", "--data", str(csv_path)])
    assert code == 0
    output = json.loads(capsys.readouterr().out)
    summary = output["summary"]
    expected = set(load_settings().enabled_strategies)
    assert set(summary["strategies"]) == expected
    assert summary["mode"] == "offline_backtest"
    assert summary["data_sha256"]
    for strategy in expected:
        assert (Path(output["report_path"]).parent / f"{strategy.lower()}_ledger.jsonl").is_file()
