from __future__ import annotations
import csv,json,sys
from collections import Counter,defaultdict
from pathlib import Path

def audit(path):
    rows=list(csv.DictReader(open(path,encoding='utf-8-sig')))
    by=defaultdict(lambda:{'n':0,'wins':0,'losses':0,'pnl':0.0})
    streak=0; max_streak=0; reentries=0; last=None
    for r in rows:
        strat=r.get('strategy','UNKNOWN'); p=float(r.get('profit') or 0); d=r.get('signal','')
        x=by[strat]; x['n']+=1; x['pnl']+=p; x['wins']+=p>0; x['losses']+=p<0
        if p<0: streak+=1; max_streak=max(max_streak,streak)
        elif p>0: streak=0
        key=(strat,d)
        if key==last: reentries+=1
        last=key
    return {'rows':len(rows),'by_strategy':by,'max_consecutive_losses':max_streak,'same_strategy_direction_reentries':reentries,'profit_sum':sum(float(r.get('profit') or 0) for r in rows),'result_counts':Counter(('WIN' if float(r.get('profit') or 0)>0 else 'LOSS' if float(r.get('profit') or 0)<0 else 'FLAT') for r in rows)}
if __name__=='__main__':
    out=audit(sys.argv[1]); print(json.dumps(out,indent=2,default=dict)); Path(sys.argv[2]).write_text(json.dumps(out,indent=2,default=dict))
