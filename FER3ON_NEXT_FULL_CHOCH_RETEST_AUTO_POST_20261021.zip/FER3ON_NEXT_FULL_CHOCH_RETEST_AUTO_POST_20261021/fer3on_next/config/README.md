# Configuration layout

- `settings.toml` contains application-wide defaults and offline backtest paths.
- `strategies/*.toml` contains the enable/version flag and only that strategy's recognized overrides.
- Unknown keys, duplicate strategy IDs, invalid types, and malformed TOML are rejected at startup.
- No passwords, tokens, or MT5 account credentials belong in these files.
- The current `main.py` supports `inspect` and offline `backtest` only. `paper`, `demo`, and `live` are rejected until their execution boundaries are implemented and tested.
