# XAUUSD historical data

The supplied XAUUSD data is stored under:

- `data/xauusd_kaggle/extracted/` — original semicolon-delimited files.
- `data/xauusd_kaggle/normalized/` — FER3ON Next normalized files.
- `reports/xauusd_data_quality.json` — validation report.

The data spans 2004-06-11 through 2026-01-30 for intraday files. It is used for backtesting, walk-forward validation, and calibration; it does not retrain an ML model automatically.
