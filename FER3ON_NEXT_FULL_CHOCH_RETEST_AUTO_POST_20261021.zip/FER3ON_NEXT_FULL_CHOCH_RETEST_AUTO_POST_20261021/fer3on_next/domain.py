from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"

class MarketState(str, Enum):
    EXPANSION_UP = "EXPANSION_UP"
    EXPANSION_DOWN = "EXPANSION_DOWN"
    PULLBACK_UP = "PULLBACK_UP"
    PULLBACK_DOWN = "PULLBACK_DOWN"
    RANGE = "RANGE"
    COMPRESSION = "COMPRESSION"
    EXHAUSTION_UP = "EXHAUSTION_UP"
    EXHAUSTION_DOWN = "EXHAUSTION_DOWN"
    UNKNOWN = "UNKNOWN"

@dataclass(frozen=True)
class Candle:
    time: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

@dataclass(frozen=True)
class Decision:
    action: str
    side: Optional[Side] = None
    entry: Optional[float] = None
    stop: Optional[float] = None
    target: Optional[float] = None
    state: MarketState = MarketState.UNKNOWN
    location: str = "UNKNOWN"
    reaction: str = "NONE"
    thesis: str = ""
    invalidation: str = ""
    reason: str = ""
    risk_fraction: float = 0.0
    idempotency_key: str = ""
    metadata: dict = field(default_factory=dict)
    build_id: str = "FER3ON-NEXT-0.1.0"
    run_id: str = ""
    data_source: str = "unknown"
    strategy_id: str = ""

@dataclass
class Trade:
    entry_time: datetime
    exit_time: Optional[datetime]
    side: Side
    entry: float
    stop: float
    target: float
    exit: Optional[float]
    risk_amount: float
    pnl: Optional[float]
    reason: str
    decision_key: str
    metadata: dict = field(default_factory=dict)
    build_id: str = "FER3ON-NEXT-0.1.0"
    run_id: str = ""
    data_source: str = "unknown"
    strategy_id: str = ""

@dataclass(frozen=True)
class BotConfig:
    symbol: str = "XAUUSD"
    timeframe: str = "M15"
    lookback: int = 80
    atr_period: int = 14
    impulse_window: int = 20
    min_atr: float = 0.01
    min_reaction_body_atr: float = 0.20
    min_displacement_atr: float = 0.80
    max_entry_extension: float = 0.78
    min_target_rr: float = 1.35
    target_rr: float = 1.80
    risk_per_trade: float = 0.0025
    max_daily_loss: float = 0.01
    max_concurrent: int = 10
    cooldown_bars: int = 3
    spread_limit: float = 0.60
    allow_short: bool = True
    session_start_utc: int = 7
    session_end_utc: int = 20
    require_market_event: bool = True
    enable_entry_quality_guard: bool = True
    enable_repeat_thesis_guard: bool = True
    primary_strategy: str = "TSM"
    momentum_lookback: int = 48
    donchian_entry_window: int = 20
    donchian_exit_window: int = 10
    donchian_buffer_atr: float = 0.05
    donchian_relaxed_context: bool = True
    fvg_min_gap_atr: float = 0.10
    fvg_max_age: int = 20
    fvg_min_displacement_atr: float = 0.80
    ob_max_age: int = 20
    ob_min_displacement_atr: float = 0.80
    ob_max_width_atr: float = 1.50
    ob_structure_left: int = 2
    ob_structure_right: int = 2
    ob_4h_max_age: int = 30
    ob_4h_min_displacement_atr: float = 0.45
    ob_4h_max_width_atr: float = 2.25
    ob_4h_structure_left: int = 1
    ob_4h_structure_right: int = 1
    enable_volatility_sizing: bool = True
    volatility_target_atr: float = 0.0
    point_value: float = 1.0
    # Temporary demo-account cap: keep each new position <= 0.10 lot
    # while validating execution and strategy behavior on a $1,000 account.
    max_unit_size: float = 0.02
    active_strategies: tuple[str, ...] = ("TSM", "DONCHIAN", "FVG", "BOS", "ORDER_BLOCK")
    enable_break_even: bool = True
    break_even_trigger_r: float = 1.0
    break_even_buffer_points: float = 2.0
    enable_partial_profit: bool = True
    partial_profit_trigger_r: float = 1.20
    partial_profit_fraction: float = 0.50
    enable_strategy_loss_pause: bool = True
    strategy_loss_pause_fraction: float = 0.10
    strategy_loss_pause_hours: int = 12

@dataclass
class AccountState:
    equity: float
    day_start_equity: float
    open_trades: int = 0
    bars_since_last_entry: int = 10_000
    consecutive_losses: int = 0
    loss_pause: bool = False
    last_loss_thesis: str = ""
    last_loss_decision_key: str = ""

    @property
    def daily_loss_fraction(self) -> float:
        if self.day_start_equity <= 0:
            return 1.0
        return max(0.0, (self.day_start_equity - self.equity) / self.day_start_equity)
