from __future__ import annotations
import json
import sys
from collections import Counter
from fer3on_next.backtest import load_csv
from fer3on_next.domain import AccountState, BotConfig
from fer3on_next.primary_signals import primary_signal
from fer3on_next.strategy import decide


def diagnose(path: str) -> dict:
    candles=load_csv(path)
    cfg=BotConfig(primary_strategy='DONCHIAN', active_strategies=('DONCHIAN',))
    signal_reasons=Counter(); decision_reasons=Counter(); entries=0; signal_candidates=0
    for i in range(cfg.lookback, len(candles)):
        history=candles[:i]
        signal=primary_signal(history,'DONCHIAN',cfg.momentum_lookback,cfg.donchian_entry_window,cfg.donchian_exit_window,cfg.atr_period,cfg.donchian_buffer_atr)
        signal_reasons[signal.reason]+=1
        if signal.side is not None: signal_candidates+=1
        decision=decide(history,AccountState(1000,1000),cfg)
        decision_reasons[decision.reason]+=1
        if decision.action=='ENTER': entries+=1
    return {'candles':len(candles),'signal_candidates':signal_candidates,'entries':entries,'signal_reasons':signal_reasons.most_common(),'decision_reasons':decision_reasons.most_common()}

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: tools_diagnose_donchian.py INPUT_CSV')
    print(json.dumps(diagnose(sys.argv[1]),indent=2))
