from __future__ import annotations
import argparse, json
from dataclasses import asdict
from .backtest import load_csv, run
from .domain import BotConfig

def main():
    p=argparse.ArgumentParser(description='FER3ON Next research/backtest engine')
    p.add_argument('csv', help='OHLCV CSV with time,open,high,low,close[,volume]')
    p.add_argument('--equity', type=float, default=1000)
    p.add_argument('--risk', type=float, default=0.0025)
    p.add_argument('--target-rr', type=float, default=1.8)
    args=p.parse_args()
    cfg=BotConfig(risk_per_trade=args.risk,target_rr=args.target_rr)
    result=run(load_csv(args.csv),cfg,args.equity)
    printable={k:v for k,v in result.items() if k!='trades'}
    print(json.dumps(printable, indent=2, default=str))
    for t in result['trades']:
        print(json.dumps(asdict(t), default=str))

if __name__=='__main__': main()
