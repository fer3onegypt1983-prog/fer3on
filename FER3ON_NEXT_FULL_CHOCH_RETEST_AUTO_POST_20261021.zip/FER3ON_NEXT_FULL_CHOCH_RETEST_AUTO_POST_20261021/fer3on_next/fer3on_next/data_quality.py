from __future__ import annotations
from dataclasses import dataclass
from datetime import timedelta
from .domain import Candle

@dataclass(frozen=True)
class DataQuality:
    valid: bool
    rows: int
    gaps: int
    invalid_ohlc: int
    duplicate_times: int
    reasons: tuple[str,...]

def validate_candles(candles: list[Candle], max_gap: timedelta|None=None) -> DataQuality:
    if not candles: return DataQuality(False,0,0,0,0,('EMPTY',))
    max_gap=max_gap or timedelta(hours=2)
    gaps=bad=dupes=0; reasons=[]
    for i,c in enumerate(candles):
        if not (c.low<=min(c.open,c.close)<=max(c.open,c.close)<=c.high and c.low>0): bad+=1
        if i:
            delta=c.time-candles[i-1].time
            if delta<=timedelta(0): dupes+=1
            elif delta>max_gap: gaps+=1
    if bad: reasons.append('INVALID_OHLC')
    if dupes: reasons.append('NON_MONOTONIC_TIME')
    if gaps: reasons.append('LARGE_GAPS')
    return DataQuality(not (bad or dupes),len(candles),gaps,bad,dupes,tuple(reasons))
