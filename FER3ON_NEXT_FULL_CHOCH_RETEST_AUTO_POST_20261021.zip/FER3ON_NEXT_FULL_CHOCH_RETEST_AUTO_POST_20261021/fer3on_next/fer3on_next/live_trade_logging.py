from __future__ import annotations
import json
from dataclasses import asdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from uuid import uuid4
from .domain import Decision, Trade
from .identity import BUILD_ID, SCHEMA_VERSION

class LiveTradeLogger:
    """Append-only live/demo ledger. Every decision/order/fill/close has a correlation id."""
    def __init__(self, path: str | Path, run_id: str, data_source: str = 'mt5_demo',
                 account_id: str | None = None, symbol: str | None = None):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.run_id=run_id; self.data_source=data_source
        self.account_id=account_id; self.symbol=symbol

    def _write(self, event: str, correlation_id: str, payload: dict) -> str:
        event_id=str(uuid4())
        envelope={'event_id':event_id,'event':event,'correlation_id':correlation_id,
                  'schema_version':SCHEMA_VERSION,'build_id':BUILD_ID,'run_id':self.run_id,
                  'data_source':self.data_source,'account_id':self.account_id,'symbol':self.symbol,
                  'event_time':datetime.now(timezone.utc).isoformat(),**payload}
        with self.path.open('a',encoding='utf-8') as f:
            f.write(json.dumps(envelope,default=str,sort_keys=True)+'\n')
        return event_id

    def decision(self, decision: Decision) -> str:
        correlation=decision.idempotency_key or sha256(str(decision.metadata).encode()).hexdigest()[:20]
        return self._write('DECISION',correlation,{'strategy_id':decision.strategy_id or decision.metadata.get('strategy_id'),
            'action':decision.action,'side':decision.side.value if decision.side else None,'entry':decision.entry,
            'stop':decision.stop,'target':decision.target,'reason':decision.reason,'thesis':decision.thesis,
            'invalidation':decision.invalidation,'risk_fraction':decision.risk_fraction,'metadata':decision.metadata})

    def order_submitted(self, decision: Decision, request: dict) -> str:
        return self._write('ORDER_SUBMITTED',decision.idempotency_key,{'strategy_id':decision.strategy_id,
            'side':decision.side.value if decision.side else None,'request':request})

    def order_result(self, decision: Decision, result: object) -> str:
        ticket=getattr(result,'order',None) or getattr(result,'deal',None) or getattr(result,'ticket',None)
        return self._write('ORDER_RESULT',decision.idempotency_key,{'strategy_id':decision.strategy_id,
            'ticket':ticket,'retcode':getattr(result,'retcode',None),
            'filled_volume':getattr(result,'volume',None),'fill_price':getattr(result,'price',None),
            'comment':getattr(result,'comment',None),'result':str(result)})

    def order_rejected(self, decision: Decision, error: Exception) -> str:
        return self._write('ORDER_REJECTED',decision.idempotency_key,{'strategy_id':decision.strategy_id,
            'side':decision.side.value if decision.side else None,'reason':str(error),
            'error_type':type(error).__name__})

    def duplicate_skipped(self, decision: Decision, fingerprint: str) -> str:
        return self._write('ORDER_DUPLICATE_SKIPPED',decision.idempotency_key or fingerprint,
            {'strategy_id':decision.strategy_id,'side':decision.side.value if decision.side else None,
             'reason':'DUPLICATE_ACTIVE_THESIS','fingerprint':fingerprint})

    def stop_moved_to_be(self, position: object, old_sl: float, new_sl: float, trigger_r: float) -> str:
        ticket=str(getattr(position,'ticket',''))
        return self._write('STOP_MOVED_TO_BE',ticket,{'ticket':ticket,'old_stop':old_sl,
            'new_stop':new_sl,'trigger_r':trigger_r,'reason':'CLOSED_CANDLE_REACHED_TRIGGER_R'})

    def stop_modification_rejected(self, position: object, request: dict, result: object) -> str:
        ticket=str(getattr(position,'ticket',''))
        return self._write('STOP_MODIFICATION_REJECTED',ticket,{'ticket':ticket,'request':request,
            'retcode':getattr(result,'retcode',None),'result':str(result)})

    def partial_profit_taken(self, position: object, volume: float, trigger_r: float) -> str:
        ticket=str(getattr(position,'ticket',''))
        return self._write('PARTIAL_PROFIT_TAKEN',ticket,{'ticket':ticket,'volume':volume,'trigger_r':trigger_r,
            'reason':'CLOSED_CANDLE_REACHED_PARTIAL_TRIGGER_R'})

    def closed_trade(self, trade: Trade) -> str:
        return self._write('TRADE_CLOSED',trade.decision_key,{'strategy_id':trade.strategy_id,
            'ticket':trade.metadata.get('ticket'),'side':trade.side.value,'entry':trade.entry,'exit':trade.exit,
            'stop':trade.stop,'target':trade.target,'pnl':trade.pnl,'reason':trade.reason,
            'outcome':trade.metadata.get('outcome'),'metadata':trade.metadata})
