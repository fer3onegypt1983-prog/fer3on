from __future__ import annotations

"""Independent, active research variant derived from legacy P2 pullback planning.

This is deliberately a *confirmed market-entry* variant, not a claim that the
legacy pending LIMIT resolver is a broker fill. It plans from a closed TSM
signal, waits for a later pullback touch plus a directional closed-candle
reclaim, then emits a market decision. No MT5 APIs are used here.
"""

from hashlib import sha256
from typing import Any

from .domain import AccountState, BotConfig, Candle, Decision, MarketState, Side
from .market import atr
from .position_sizing import build_position_plan
from .experimental_strategies import StrategyRuntimeState

STRATEGY_ID = "P2_PULLBACK_CONFIRMATION"


def _wait(reason: str, metadata: dict[str, Any] | None = None) -> Decision:
    meta = dict(metadata or {})
    meta.update({"strategy_id": STRATEGY_ID, "active_strategy": True})
    return Decision("WAIT", reason=reason, thesis=reason, metadata=meta, strategy_id=STRATEGY_ID)


def decide_p2_pullback_confirmation(
    candles: list[Candle],
    account: AccountState,
    cfg: BotConfig,
    state: StrategyRuntimeState,
    version: str,
    source_decision: Decision | None,
    source_version: str = "next-baseline-0.1",
) -> Decision:
    """Plan only from a completed TSM signal; trigger only on later closed bars."""
    if len(candles) < cfg.atr_period + 5:
        return _wait("INSUFFICIENT_DATA")
    if account.open_trades > 0:
        return _wait("STRATEGY_POSITION_ALREADY_OPEN")
    if account.bars_since_last_entry < cfg.cooldown_bars:
        return _wait("COOLDOWN")
    if account.daily_loss_fraction >= cfg.max_daily_loss:
        return _wait("DAILY_LOSS_LIMIT")

    candle = candles[-1]
    current_atr = atr(candles, cfg.atr_period)
    if current_atr <= 0:
        state.pending_pullback = None
        return _wait("ATR_UNAVAILABLE")

    plan = state.pending_pullback
    if plan is None:
        if source_decision is None or source_decision.action != "ENTER" or source_decision.side is None:
            return _wait("SOURCE_TSM_NO_SIGNAL", {"source_strategy": "TSM"})
        if source_decision.entry is None or source_decision.stop is None or source_decision.target is None:
            return _wait("SOURCE_SIGNAL_MISSING_LEVELS", {"source_strategy": "TSM"})
        depth = float(cfg.pullback_depth_atr)
        if depth <= 0 or cfg.pullback_ttl_bars < 1:
            return _wait("INVALID_PULLBACK_CONFIGURATION")
        direction = 1.0 if source_decision.side is Side.BUY else -1.0
        planned_entry = float(source_decision.entry) - direction * depth * current_atr
        stop = float(source_decision.stop)
        if (source_decision.side is Side.BUY and stop >= planned_entry) or (
            source_decision.side is Side.SELL and stop <= planned_entry
        ):
            return _wait("PULLBACK_LEVEL_CROSSES_STRUCTURAL_STOP")
        plan = {
            "side": source_decision.side.value,
            "planned_entry": planned_entry,
            "stop": stop,
            "source_entry": float(source_decision.entry),
            "source_target": float(source_decision.target),
            "source_signal_key": source_decision.idempotency_key,
            "source_signal_time": candles[-1].time.isoformat(),
            "source_strategy": "TSM",
            "source_strategy_version": source_version,
            "source_reason": source_decision.reason,
            "source_thesis": source_decision.thesis,
            "atr_at_plan": current_atr,
            "bars_waited": 0,
        }
        state.pending_pullback = plan
        return _wait("PULLBACK_PLAN_CREATED_WAITING_FOR_LATER_CLOSED_BAR", {"pullback_plan": dict(plan)})

    side = Side(plan["side"])
    plan["bars_waited"] = int(plan.get("bars_waited", 0)) + 1
    waited = plan["bars_waited"]
    limit = float(plan["planned_entry"])
    stop = float(plan["stop"])
    source_target = float(plan["source_target"])
    common = {
        "pullback_plan": dict(plan),
        "bars_waited": waited,
        "ttl_bars": cfg.pullback_ttl_bars,
        "pullback_level": limit,
        "source_strategy": "TSM",
        "source_strategy_version": plan.get("source_strategy_version", source_version),
        "execution_model": "closed_bar_reclaim_then_market_order",
    }

    if (side is Side.BUY and candle.low <= stop) or (side is Side.SELL and candle.high >= stop):
        state.pending_pullback = None
        return _wait("PULLBACK_PLAN_INVALIDATED_AT_STRUCTURAL_STOP", common)
    if (side is Side.BUY and candle.high >= source_target) or (side is Side.SELL and candle.low <= source_target):
        state.pending_pullback = None
        return _wait("SOURCE_TARGET_REACHED_BEFORE_PULLBACK_NO_CHASE", common)
    if waited > int(cfg.pullback_ttl_bars):
        state.pending_pullback = None
        return _wait("PULLBACK_PLAN_EXPIRED", common)

    body = abs(candle.close - candle.open)
    minimum_body = max(0.0, float(cfg.pullback_confirmation_body_atr)) * current_atr
    touched = candle.low <= limit if side is Side.BUY else candle.high >= limit
    reclaimed = candle.close > limit if side is Side.BUY else candle.close < limit
    directional = candle.close > candle.open if side is Side.BUY else candle.close < candle.open
    confirmed = touched and reclaimed and directional and body >= minimum_body
    if not confirmed:
        common["confirmation"] = {
            "touched": touched,
            "closed_back_beyond_level": reclaimed,
            "directional_close": directional,
            "body_atr": body / current_atr,
            "minimum_body_atr": cfg.pullback_confirmation_body_atr,
        }
        return _wait("WAITING_FOR_PULLBACK_TOUCH_AND_CLOSED_CONFIRMATION", common)

    entry = float(candle.close)
    risk_distance = abs(entry - stop)
    if risk_distance <= 0 or risk_distance > current_atr * float(cfg.pullback_max_risk_atr):
        state.pending_pullback = None
        return _wait("CONFIRMED_ENTRY_RISK_DISTANCE_INVALID", {
            **common, "risk_distance": risk_distance,
            "max_risk_atr": cfg.pullback_max_risk_atr,
            "risk_distance_atr": risk_distance / current_atr,
        })
    if side is Side.BUY and not stop < entry:
        state.pending_pullback = None
        return _wait("CONFIRMATION_CLOSE_BELOW_STOP", common)
    if side is Side.SELL and not entry < stop:
        state.pending_pullback = None
        return _wait("CONFIRMATION_CLOSE_ABOVE_STOP", common)

    reward_risk = float(cfg.target_rr)
    if reward_risk < float(cfg.pullback_min_reward_risk):
        state.pending_pullback = None
        return _wait("PULLBACK_REWARD_RISK_BELOW_MINIMUM", {**common, "reward_risk": reward_risk})
    target = entry + risk_distance * reward_risk if side is Side.BUY else entry - risk_distance * reward_risk
    try:
        sizing = build_position_plan(
            account.equity,
            cfg.risk_per_trade,
            risk_distance,
            current_atr,
            cfg.point_value,
            cfg.max_unit_size,
            cfg.volatility_target_atr if cfg.enable_volatility_sizing and cfg.volatility_target_atr > 0 else None,
        )
    except ValueError as exc:
        state.pending_pullback = None
        return _wait(f"POSITION_SIZE_INVALID:{exc}", common)

    metadata = {
        **common,
        "strategy_id": STRATEGY_ID,
        "active_strategy": True,
        "strategy_version": version,
        "entry_reasons": [
            "TSM source signal",
            "legacy P2 pullback depth reached on a later closed candle",
            "directional candle closed back beyond pullback level",
        ],
        "pullback_confirmation": {
            "touch_level": limit,
            "confirmation_time": candle.time.isoformat(),
            "confirmation_close": entry,
            "body_atr": body / current_atr,
        },
        "risk_distance": risk_distance,
        "rr": reward_risk,
        "position_sizing": {
            "risk_cash": sizing.risk_cash,
            "risk_fraction": sizing.risk_fraction,
            "unit_size": sizing.unit_size,
            "volatility_scalar": sizing.volatility_scalar,
            "reason": sizing.reason,
            "point_value": cfg.point_value,
        },
        "signal_candle": {
            "time": candle.time.isoformat(), "open": candle.open, "high": candle.high,
            "low": candle.low, "close": candle.close, "volume": candle.volume,
        },
        "entry_order_type": "MARKET_AFTER_CLOSED_BAR_CONFIRMATION",
    }
    key = sha256(
        f"{STRATEGY_ID}|{version}|{plan['source_signal_key']}|{candle.time.isoformat()}|{side.value}|{entry:.10f}".encode()
    ).hexdigest()[:24]
    state.pending_pullback = None
    return Decision(
        action="ENTER", side=side, entry=entry, stop=stop, target=target,
        state=MarketState.UNKNOWN, location="P2_PULLBACK_CONFIRMATION",
        reaction="PULLBACK_TOUCH_RECLAIM", thesis=f"{STRATEGY_ID}: TSM signal followed by confirmed pullback",
        invalidation=f"Structural stop at {stop:.5f}", reason="P2_PULLBACK_TOUCH_RECLAIM_CONFIRMED",
        risk_fraction=sizing.risk_fraction, idempotency_key=key, metadata=metadata,
        strategy_id=STRATEGY_ID,
    )
