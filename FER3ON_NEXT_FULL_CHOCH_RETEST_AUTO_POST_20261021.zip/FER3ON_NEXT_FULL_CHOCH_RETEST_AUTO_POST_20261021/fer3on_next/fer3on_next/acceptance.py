from __future__ import annotations
from dataclasses import dataclass, replace

@dataclass(frozen=True)
class AcceptancePolicy:
    min_test_folds: int = 3
    min_trades: int = 30
    min_profitable_fold_fraction: float = 0.50
    min_profit_factor: float = 1.05
    max_drawdown_fraction: float = 0.10
    max_loss_streak: int = 8
    require_positive_net_pnl: bool = True
    stage: str = "FINAL"

    @classmethod
    def exploration(cls) -> "AcceptancePolicy":
        # Collect evidence faster; this is not permission to promote or trade live.
        return cls(min_test_folds=2, min_trades=10, min_profitable_fold_fraction=0.25,
                   min_profit_factor=0.80, max_drawdown_fraction=0.20, max_loss_streak=12,
                   require_positive_net_pnl=False, stage="EXPLORATION")

    @classmethod
    def final(cls) -> "AcceptancePolicy":
        return cls(stage="FINAL")


def _max_loss_streak(trades: list[dict]) -> int:
    current = best = 0
    for trade in trades:
        pnl = trade.get("pnl")
        if pnl is not None and pnl < 0:
            current += 1; best = max(best, current)
        elif pnl is not None:
            current = 0
    return best


def _checks(folds: list[dict], trades: list[dict], policy: AcceptancePolicy) -> dict:
    trade_count=sum(int(f.get("trades",0)) for f in folds)
    net=sum(float(f.get("net_pnl",0.0) or 0.0) for f in folds)
    gp=sum(float(f.get("gross_profit",0.0) or 0.0) for f in folds)
    gl=sum(float(f.get("gross_loss",0.0) or 0.0) for f in folds)
    pf=gp/gl if gl>0 else None
    profitable=sum(1 for f in folds if float(f.get("net_pnl",0.0) or 0.0)>0)
    fold_fraction=profitable/len(folds) if folds else 0.0
    max_dd=max((float(f.get("max_drawdown",0.0) or 0.0) for f in folds),default=0.0)
    loss_streak=_max_loss_streak(trades)
    checks={
        "enough_folds":len(folds)>=policy.min_test_folds,
        "enough_trades":trade_count>=policy.min_trades,
        "profitable_fold_fraction":fold_fraction>=policy.min_profitable_fold_fraction,
        "profit_factor":pf is not None and pf>=policy.min_profit_factor,
        "drawdown":max_dd<=policy.max_drawdown_fraction,
        "loss_streak":loss_streak<=policy.max_loss_streak,
        "positive_net_pnl":(net>0) if policy.require_positive_net_pnl else True,
    }
    return checks


def evaluate_walk_forward(folds: list[dict], trades: list[dict] | None = None,
                          policy: AcceptancePolicy = AcceptancePolicy()) -> dict:
    trades=trades or []
    exploration=AcceptancePolicy.exploration()
    final_checks=_checks(folds,trades,policy)
    exploration_checks=_checks(folds,trades,exploration)
    trade_count=sum(int(f.get("trades",0)) for f in folds)
    net=sum(float(f.get("net_pnl",0.0) or 0.0) for f in folds)
    gp=sum(float(f.get("gross_profit",0.0) or 0.0) for f in folds)
    gl=sum(float(f.get("gross_loss",0.0) or 0.0) for f in folds)
    pf=gp/gl if gl>0 else None
    profitable=sum(1 for f in folds if float(f.get("net_pnl",0.0) or 0.0)>0)
    fold_fraction=profitable/len(folds) if folds else 0.0
    max_dd=max((float(f.get("max_drawdown",0.0) or 0.0) for f in folds),default=0.0)
    loss_streak=_max_loss_streak(trades)
    return {
        "accepted": all(final_checks.values()),
        "production_eligible": all(final_checks.values()),
        "exploration_pass": all(exploration_checks.values()),
        "stage": policy.stage,
        "checks": final_checks,
        "exploration_checks": exploration_checks,
        "policy": policy.__dict__,
        "exploration_policy": exploration.__dict__,
        "folds":len(folds), "trades":trade_count, "net_pnl":net,
        "profit_factor":pf, "profitable_fold_fraction":fold_fraction,
        "max_drawdown":max_dd, "max_loss_streak":loss_streak,
        "rejection_reasons":[name for name,passed in final_checks.items() if not passed],
        "exploration_rejection_reasons":[name for name,passed in exploration_checks.items() if not passed],
    }
