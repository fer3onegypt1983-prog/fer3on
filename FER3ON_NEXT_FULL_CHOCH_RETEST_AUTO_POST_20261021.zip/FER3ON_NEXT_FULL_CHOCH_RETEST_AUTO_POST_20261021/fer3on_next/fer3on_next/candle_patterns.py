from __future__ import annotations
from dataclasses import dataclass
from statistics import mean
from .domain import Candle

@dataclass(frozen=True)
class CandleForecast:
    direction: str
    confidence: float
    pattern: str
    continuation: float
    reversal: float
    reason: str

def inspect_candles(candles: list[Candle], atr_value: float) -> CandleForecast:
    if len(candles)<3 or atr_value<=0: return CandleForecast('UNKNOWN',0,'INSUFFICIENT',0,0,'not enough candles')
    a,b,c=candles[-3:]; body=abs(c.close-c.open); rng=max(c.high-c.low,1e-9)
    upper=c.high-max(c.open,c.close); lower=min(c.open,c.close)-c.low
    if c.close>c.open and b.close<b.open and c.open<=b.close and c.close>=b.open:
        return CandleForecast('BUY',min(1,body/atr_value), 'BULLISH_ENGULFING',.72,.78,'bullish body absorbed prior candle')
    if c.close<c.open and b.close>b.open and c.open>=b.close and c.close<=b.open:
        return CandleForecast('SELL',min(1,body/atr_value), 'BEARISH_ENGULFING',.72,.78,'bearish body absorbed prior candle')
    if c.close>c.open and lower/rng>=.45:
        return CandleForecast('BUY',min(1,.5+lower/rng*.5),'BULLISH_REJECTION',.55,.78,'lower wick rejection')
    if c.close<c.open and upper/rng>=.45:
        return CandleForecast('SELL',min(1,.5+upper/rng*.5),'BEARISH_REJECTION',.55,.78,'upper wick rejection')
    if body>=atr_value*.8:
        d='BUY' if c.close>c.open else 'SELL' if c.close<c.open else 'UNKNOWN'
        return CandleForecast(d,min(1,body/atr_value),'DISPLACEMENT',.82,.35,'large displacement body')
    if c.high<=b.high and c.low>=b.low:
        return CandleForecast('UNKNOWN',.35,'INSIDE_BAR',.35,.35,'compression requires breakout')
    return CandleForecast('BUY' if c.close>c.open else 'SELL' if c.close<c.open else 'UNKNOWN',min(1,body/atr_value), 'NEUTRAL',.45,.25,'no dominant pattern')
