from __future__ import annotations
import json
from dataclasses import asdict
from pathlib import Path
from .domain import Decision, Trade
from .identity import BUILD_ID, SCHEMA_VERSION

class Journal:
    def __init__(self, path: str | Path, build_id: str = BUILD_ID, run_id: str = "", data_source: str = "unknown"):
        self.path=Path(path); self.path.parent.mkdir(parents=True, exist_ok=True)
        self.build_id=build_id; self.run_id=run_id; self.data_source=data_source
    def _append(self, event: dict):
        envelope={'schema_version':SCHEMA_VERSION,'build_id':self.build_id,'run_id':self.run_id,'data_source':self.data_source,**event}
        with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps(envelope, default=str, sort_keys=True)+'\n')
    def decision(self, decision: Decision): self._append({'event':'DECISION', **asdict(decision)})
    def opportunity(self, record: dict): self._append({'event':'OPPORTUNITY', **record})
    def trade(self, trade: Trade): self._append({'event':'TRADE', **asdict(trade)})
