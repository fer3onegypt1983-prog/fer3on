from __future__ import annotations

def evaluate_execution_quality(sl_distance: float, tp_distance: float, atr_value: float, spread: float=0.0) -> dict:
    if atr_value<=0 or sl_distance<=0 or tp_distance<=0:
        return {'grade':'REJECT','approved':False,'risk_multiplier':0.0,'reason':'INVALID_GEOMETRY'}
    rr=tp_distance/sl_distance; spread_ratio=spread/atr_value; sl_ratio=sl_distance/atr_value
    if rr<1.35: return {'grade':'REJECT','approved':False,'risk_multiplier':0.0,'reason':'RR_TOO_LOW','rr':rr,'spread_ratio':spread_ratio,'sl_atr':sl_ratio}
    if spread_ratio>0.20: return {'grade':'REJECT','approved':False,'risk_multiplier':0.0,'reason':'SPREAD_TOO_WIDE','rr':rr,'spread_ratio':spread_ratio,'sl_atr':sl_ratio}
    if sl_ratio>3.0: return {'grade':'REJECT','approved':False,'risk_multiplier':0.0,'reason':'SL_TOO_WIDE','rr':rr,'spread_ratio':spread_ratio,'sl_atr':sl_ratio}
    if rr>=2.5 and spread_ratio<=.05 and .8<=sl_ratio<=1.8: grade,mult='A+',1.0
    elif rr>=2.0 and spread_ratio<=.10: grade,mult='A',.85
    elif rr>=1.5: grade,mult='B',.65
    else: grade,mult='C',.40
    return {'grade':grade,'approved':True,'risk_multiplier':mult,'reason':'QUALITY_ACCEPTED','rr':rr,'spread_ratio':spread_ratio,'sl_atr':sl_ratio}
