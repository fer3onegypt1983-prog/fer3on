from __future__ import annotations
from dataclasses import dataclass
from .structure import Label, PivotKind, StructureSnapshot

@dataclass(frozen=True)
class TrendSnapshot:
    direction: str
    phase: str
    confidence: float
    reason: str

def infer_trend(structure: StructureSnapshot, min_points: int=4) -> TrendSnapshot:
    pts=list(structure.points)[-min_points:]
    labels=[p.label for p in pts if p.label is not None]
    ups=sum(x in {Label.HH,Label.HL} for x in labels)
    downs=sum(x in {Label.LH,Label.LL} for x in labels)
    if structure.bias=='UP' and ups>=2 and ups>downs:
        phase='PULLBACK' if labels and labels[-1] is Label.HL else 'EXPANSION'
        return TrendSnapshot('UP',phase,min(1.0,(ups+1)/(len(labels)+1)),f'HH/HL dominance {ups}:{downs}')
    if structure.bias=='DOWN' and downs>=2 and downs>ups:
        phase='PULLBACK' if labels and labels[-1] is Label.LH else 'EXPANSION'
        return TrendSnapshot('DOWN',phase,min(1.0,(downs+1)/(len(labels)+1)),f'LH/LL dominance {downs}:{ups}')
    if len(labels)<2: return TrendSnapshot('UNKNOWN','INSUFFICIENT',0.0,'not enough confirmed labels')
    return TrendSnapshot('RANGE','TRANSITION',max(0.2,1-abs(ups-downs)/len(labels)),f'mixed structure {ups}:{downs}')
