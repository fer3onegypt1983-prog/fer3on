from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class PositionPlan:
    risk_cash: float
    risk_fraction: float
    unit_size: float
    stop_distance: float
    volatility_scalar: float
    reason: str


def build_position_plan(equity: float, risk_fraction: float, stop_distance: float, atr_value: float,
                        point_value: float = 1.0, max_unit_size: float = 1.0,
                        volatility_target_distance: float | None = None) -> PositionPlan:
    if equity <= 0 or risk_fraction <= 0 or stop_distance <= 0 or point_value <= 0:
        raise ValueError("invalid position sizing inputs")
    scalar = 1.0
    if volatility_target_distance and volatility_target_distance > 0 and atr_value > 0:
        scalar = min(1.0, volatility_target_distance / atr_value)
    effective_fraction = risk_fraction * scalar
    risk_cash = equity * effective_fraction
    unit_size = min(max_unit_size, risk_cash / (stop_distance * point_value))
    return PositionPlan(risk_cash, effective_fraction, unit_size, stop_distance, scalar,
                        "RISK_PER_TRADE_SCALED_BY_ATR" if scalar < 1.0 else "RISK_PER_TRADE_BASELINE")
