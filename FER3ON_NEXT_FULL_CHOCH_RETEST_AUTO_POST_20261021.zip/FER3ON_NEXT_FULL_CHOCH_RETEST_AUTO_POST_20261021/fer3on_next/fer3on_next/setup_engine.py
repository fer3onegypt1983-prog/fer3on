from __future__ import annotations
from dataclasses import dataclass
from .domain import Candle, Side
from .candle_patterns import inspect_candles
from .market_events import detect_events, select_event
from .structure import StructureSnapshot

@dataclass(frozen=True)
class SetupForecast:
    side: Side|None
    action: str
    event: str
    pattern: str
    continuation: float
    reversal: float
    level: float|None
    reason: str

def evaluate_setup(candles: list[Candle], structure: StructureSnapshot, atr_value: float) -> SetupForecast:
    pattern=inspect_candles(candles,atr_value); events=detect_events(candles,structure,atr_value)
    candidates=[]
    for side in (Side.BUY,Side.SELL):
        e=select_event(events,side.value)
        if e: candidates.append((e,side))
    if candidates:
        e,side=max(candidates,key=lambda x:x[0].continuation_score+(0.12 if x[0].retest else 0))
        if pattern.direction==side.value:
            cont=min(1,(e.continuation_score+pattern.continuation)/2+.10); rev=pattern.reversal*.5
            return SetupForecast(side,'ENTER_READY',e.name,pattern.pattern,cont,rev,e.level,f'{e.reason}; candle pattern agrees')
        return SetupForecast(side,'WAIT_RETEST',e.name,pattern.pattern,e.continuation_score*.75,pattern.reversal,e.level,'event exists but candle pressure disagrees')
    if pattern.pattern in {'BULLISH_REJECTION','BEARISH_REJECTION','BULLISH_ENGULFING','BEARISH_ENGULFING'}:
        side=Side.BUY if pattern.direction=='BUY' else Side.SELL
        return SetupForecast(side,'WAIT_EVENT', 'NONE',pattern.pattern,pattern.continuation*.65,pattern.reversal,None,'reaction without BOS/CHOCH/FVG confirmation')
    return SetupForecast(None,'NO_SETUP','NONE',pattern.pattern,pattern.continuation,pattern.reversal,None,'no confirmed event')
