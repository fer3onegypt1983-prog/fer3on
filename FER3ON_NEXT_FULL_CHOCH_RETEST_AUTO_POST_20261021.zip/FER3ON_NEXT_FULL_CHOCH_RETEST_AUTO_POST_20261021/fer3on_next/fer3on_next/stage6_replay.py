from __future__ import annotations

"""Exploratory, causal OHLC replay for Stage 6.

This module is deliberately separate from the bootstrap backtester. It does not
claim broker-cost or lot-level PnL: the input has no bid/ask, spread, commission,
swap, or verified timezone. Naive source timestamps are assigned UTC *only as a
mechanical anchor* because Scenario Tree currently requires aware datetimes;
this is not a claim that the vendor clock is UTC. Time-of-day session references
are disabled for this replay.
"""

import csv
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any, Callable

from .domain import AccountState, Candle, Decision, Side
from .experimental_strategies import StrategyRuntimeState
from .strategy import decide_candidates


STRATEGY_IDS = (
    "TSM", "DONCHIAN", "FVG_MODERATE", "BOS", "ORDER_BLOCK_MODERATE",
    "LEVEL_MAP_SCENARIO_TREE", "IMPULSE_RETEST", "IMPULSE_MIDPOINT_REVERSAL",
    "P2_PULLBACK_CONFIRMATION",
)
DEFAULT_HISTORY_BARS = 512


@dataclass
class ReplayPosition:
    strategy_id: str
    decision: Decision
    entry_time: datetime
    entry: float
    stop: float
    target: float
    risk_distance: float
    risk_fraction: float
    entry_equity: float
    signal_time: datetime


def load_semicolon_ohlcv(path: str | Path) -> tuple[list[Candle], str]:
    """Load Kaggle-style YYYY.MM.DD HH:MM bars; preserve source clock values."""
    source = Path(path)
    digest = sha256(source.read_bytes()).hexdigest()
    candles: list[Candle] = []
    with source.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        required = {"Date", "Open", "High", "Low", "Close", "Volume"}
        if not reader.fieldnames or not required.issubset(reader.fieldnames):
            raise ValueError(f"CSV must contain semicolon columns {sorted(required)}")
        for row_no, row in enumerate(reader, start=2):
            raw = (row.get("Date") or "").strip()
            try:
                day_text, clock_text = raw.split()
                year, month, day = (int(part) for part in day_text.split("."))
                hour, minute = (int(part) for part in clock_text.split(":"))
                # Keep the source wall-clock unchanged; no UTC conversion is made.
                source_time = datetime(year, month, day, hour, minute, tzinfo=timezone.utc)
                candle = Candle(
                    source_time,
                    float(row["Open"]), float(row["High"]),
                    float(row["Low"]), float(row["Close"]), float(row["Volume"]),
                )
            except Exception as exc:
                raise ValueError(f"Invalid OHLCV row {row_no}: {exc}") from exc
            if not (candle.low <= min(candle.open, candle.close) <= max(candle.open, candle.close) <= candle.high):
                raise ValueError(f"Invalid OHLC geometry at CSV row {row_no}")
            if candle.volume < 0:
                raise ValueError(f"Negative volume at CSV row {row_no}")
            if candles and candle.time <= candles[-1].time:
                raise ValueError(f"Non-ascending/duplicate source timestamp at CSV row {row_no}")
            candles.append(candle)
    if not candles:
        raise ValueError("CSV has no OHLCV rows")
    return candles, digest


def intrabar_exit(position: ReplayPosition, candle: Candle) -> tuple[float, str, bool] | None:
    """Return exit price/reason/ambiguity; gaps fill at the open, ties assume stop first."""
    buy = position.decision.side is Side.BUY
    if buy:
        if candle.open <= position.stop:
            return candle.open, "STOP_GAP", False
        if candle.open >= position.target:
            return candle.open, "TARGET_GAP", False
        hit_stop = candle.low <= position.stop
        hit_target = candle.high >= position.target
    else:
        if candle.open >= position.stop:
            return candle.open, "STOP_GAP", False
        if candle.open <= position.target:
            return candle.open, "TARGET_GAP", False
        hit_stop = candle.high >= position.stop
        hit_target = candle.low <= position.target
    if hit_stop and hit_target:
        return position.stop, "AMBIGUOUS_STOP_FIRST", True
    if hit_stop:
        return position.stop, "STOP", False
    if hit_target:
        return position.target, "TARGET", False
    return None


def _trade_metrics(trades: list[dict[str, Any]]) -> dict[str, Any]:
    rs = [float(item["r_multiple"]) for item in trades]
    wins = [value for value in rs if value > 0]
    losses = [value for value in rs if value < 0]
    gross_loss = abs(sum(losses))
    equity, peak, max_dd = 1.0, 1.0, 0.0
    max_loss_streak = streak = 0
    for trade in trades:
        if "normalized_pnl" in trade:
            equity += float(trade["normalized_pnl"])
        else:
            equity *= 1.0 + float(trade["risk_fraction"]) * float(trade["r_multiple"])
        peak = max(peak, equity)
        max_dd = max(max_dd, (peak - equity) / peak if peak else 0.0)
        if trade["r_multiple"] < 0:
            streak += 1
            max_loss_streak = max(max_loss_streak, streak)
        elif trade["r_multiple"] > 0:
            streak = 0
    by_fold: dict[str, list[dict[str, Any]]] = {}
    for trade in trades:
        year = int(trade["entry_time"][:4])
        fold = "2004-2010" if year <= 2010 else "2011-2016" if year <= 2016 else "2017-2021" if year <= 2021 else "2022-2026"
        by_fold.setdefault(fold, []).append(trade)
    fold_metrics = {}
    for fold, rows in by_fold.items():
        fold_rs = [float(row["r_multiple"]) for row in rows]
        wins_fold = sum(x for x in fold_rs if x > 0)
        losses_fold = abs(sum(x for x in fold_rs if x < 0))
        fold_metrics[fold] = {
            "trades": len(rows),
            "total_r": round(sum(fold_rs), 4),
            "expectancy_r": round(sum(fold_rs) / len(fold_rs), 5),
            "profit_factor_r": round(wins_fold / losses_fold, 4) if losses_fold else None,
        }
    return {
        "trades": len(rs),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": round(len(wins) / len(rs), 5) if rs else None,
        "total_r_gross": round(sum(rs), 4),
        "expectancy_r_gross": round(sum(rs) / len(rs), 5) if rs else None,
        "profit_factor_r_gross": round(sum(wins) / gross_loss, 4) if gross_loss else None,
        "max_drawdown_normalized": round(max_dd, 5),
        "max_consecutive_losses": max_loss_streak,
        "ambiguous_stop_first_count": sum(row["exit_reason"] == "AMBIGUOUS_STOP_FIRST" for row in trades),
        "folds": fold_metrics,
    }


def run_replay(
    candles: list[Candle],
    profiles: dict[str, Any],
    selected: tuple[str, ...] | list[str] | None = None,
    starting_equity: float = 1.0,
    history_bars: int = DEFAULT_HISTORY_BARS,
    progress_callback: Callable[[int, int, int], None] | None = None,
) -> dict[str, Any]:
    """Run isolated strategy diagnostics or a shared-equity portfolio replay."""
    names = tuple(name.upper() for name in (selected or STRATEGY_IDS))
    unknown = sorted(set(names) - set(profiles))
    if unknown:
        raise ValueError(f"Missing strategy profiles: {unknown}")
    if history_bars < 80:
        raise ValueError("history_bars must be at least 80 for stable warm-up")
    if starting_equity <= 0:
        raise ValueError("starting_equity must be positive")

    configs = {
        name: replace(
            profiles[name].bot_config,
            active_strategies=(name,),
            max_concurrent=max(profiles[name].bot_config.max_concurrent, len(names)),
            use_session_reference_levels=False,
        )
        for name in names
    }
    decision_profiles = {
        name: (
            replace(profile.bot_config, active_strategies=(name,), use_session_reference_levels=False),
            profile.version,
        )
        for name, profile in profiles.items()
    }
    states = {name: StrategyRuntimeState() for name in names}
    positions: dict[str, ReplayPosition] = {}
    ledgers: dict[str, list[dict[str, Any]]] = {name: [] for name in names}
    rejects = {name: 0 for name in names}
    accounts = {
        name: AccountState(starting_equity, starting_equity)
        for name in names
    }
    shared_equity = float(starting_equity)
    source_day = candles[0].time.date()
    shared_day_start = shared_equity
    first_index = max(history_bars, max(config.lookback for config in configs.values()) + 2)

    for index in range(first_index, len(candles)):
        current = candles[index]
        # Source-date rollover is used only for the exploratory daily risk guard.
        if current.time.date() != source_day:
            source_day = current.time.date()
            shared_day_start = shared_equity
            for account in accounts.values():
                account.day_start_equity = shared_day_start
        history = candles[max(0, index - history_bars):index]
        # Signals use only bars closed before the fill candle. Each strategy has
        # its own account state and one-position slot; equity/daily risk are shared.
        for name in names:
            account = accounts[name]
            account.equity = shared_equity
            account.day_start_equity = shared_day_start
            account.open_trades = 1 if name in positions else 0
            config = configs[name]
            if len(positions) >= min(config.max_concurrent, 10) and name not in positions:
                continue
            decisions = decide_candidates(
                history, account, config,
                strategy_states={name: states[name]},
                strategy_configs=decision_profiles,
            )
            decision = decisions[0] if decisions else None
            if decision is None or decision.action != "ENTER" or name in positions:
                continue
            entry = current.open
            side = decision.side
            valid = (
                side is Side.BUY and decision.stop is not None and decision.target is not None
                and decision.stop < entry < decision.target
            ) or (
                side is Side.SELL and decision.stop is not None and decision.target is not None
                and decision.target < entry < decision.stop
            )
            if not valid or not decision.risk_fraction or decision.risk_fraction <= 0:
                rejects[name] += 1
                continue
            positions[name] = ReplayPosition(
                name, decision, current.time, entry, float(decision.stop), float(decision.target),
                abs(entry - float(decision.stop)), float(decision.risk_fraction), shared_equity,
                history[-1].time,
            )
            account.open_trades = 1

        # Resolve each active position against this candle. New entries are also
        # exposed to same-candle stop/target hits after filling at the open.
        for name, position in list(positions.items()):
            hit = intrabar_exit(position, current)
            if hit is None:
                continue
            exit_price, exit_reason, ambiguous = hit
            direction = 1.0 if position.decision.side is Side.BUY else -1.0
            r_multiple = direction * (exit_price - position.entry) / position.risk_distance
            ledger = {
                "strategy_id": name,
                "signal_time": position.signal_time.isoformat(),
                "entry_time": position.entry_time.isoformat(),
                "exit_time": current.time.isoformat(),
                "side": position.decision.side.value,
                "signal_close_entry": position.decision.entry,
                "fill_open": position.entry,
                "stop": position.stop,
                "target": position.target,
                "exit": exit_price,
                "exit_reason": exit_reason,
                "r_multiple": r_multiple,
                "risk_fraction": position.risk_fraction,
                "entry_equity": position.entry_equity,
                "normalized_pnl": position.entry_equity * position.risk_fraction * r_multiple,
                "thesis": position.decision.thesis,
                "decision_reason": position.decision.reason,
                "decision_key": position.decision.idempotency_key,
                "ambiguous_ohlc_ordering": ambiguous,
            }
            ledgers[name].append(ledger)
            shared_equity += position.entry_equity * position.risk_fraction * r_multiple
            account = accounts[name]
            account.equity = shared_equity
            account.open_trades = 0
            if r_multiple < 0:
                account.consecutive_losses += 1
                account.last_loss_thesis = str(position.decision.metadata.get("thesis_id") or "")
                account.last_loss_decision_key = position.decision.idempotency_key
                if account.consecutive_losses >= 3:
                    account.loss_pause = True
            elif r_multiple > 0:
                account.consecutive_losses = 0
                account.loss_pause = False
                account.last_loss_thesis = ""
                account.last_loss_decision_key = ""
            del positions[name]

        if progress_callback and (
            index + 1 == first_index or (index + 1) % 1_000 == 0 or index + 1 == len(candles)
        ):
            progress_callback(index + 1, len(candles), sum(len(rows) for rows in ledgers.values()))

    # Mark remaining positions to the last close; this is an end-of-sample exit,
    # not a broker close quote and has no spread/slippage adjustment.
    final = candles[-1]
    for name, position in list(positions.items()):
        direction = 1.0 if position.decision.side is Side.BUY else -1.0
        r_multiple = direction * (final.close - position.entry) / position.risk_distance
        ledgers[name].append({
            "strategy_id": name,
            "signal_time": position.signal_time.isoformat(),
            "entry_time": position.entry_time.isoformat(),
            "exit_time": final.time.isoformat(),
            "side": position.decision.side.value,
            "signal_close_entry": position.decision.entry,
            "fill_open": position.entry,
            "stop": position.stop,
            "target": position.target,
            "exit": final.close,
            "exit_reason": "END_OF_SAMPLE_MARK_TO_CLOSE",
            "r_multiple": r_multiple,
            "risk_fraction": position.risk_fraction,
            "entry_equity": position.entry_equity,
            "normalized_pnl": position.entry_equity * position.risk_fraction * r_multiple,
            "thesis": position.decision.thesis,
            "decision_reason": position.decision.reason,
            "decision_key": position.decision.idempotency_key,
            "ambiguous_ohlc_ordering": False,
        })
        shared_equity += position.entry_equity * position.risk_fraction * r_multiple

    results = {
        name: {
            **_trade_metrics(ledgers[name]),
            "entry_rejections": rejects[name],
            "strategy_version": profiles[name].version,
            "trades_ledger": ledgers[name],
        }
        for name in names
    }
    portfolio_trades = sorted(
        [trade for rows in ledgers.values() for trade in rows],
        key=lambda row: (row["exit_time"], row["entry_time"], row["strategy_id"]),
    )
    portfolio = _trade_metrics(portfolio_trades)
    portfolio["entry_rejections"] = sum(rejects.values())
    return {
        "engine": "fer3on_stage6_causal_ohlc_replay_v1",
        "symbol": "XAUUSD",
        "timeframe": "M15",
        "timezone_policy": "source wall-clock preserved; UTC tzinfo is an internal mechanical anchor only; actual timezone unverified",
        "session_reference_policy": "disabled for this exploratory replay",
        "daily_risk_day_boundary": "source-clock calendar date; not verified against broker day",
        "execution_policy": {
            "signal_information_cutoff": "closed bars strictly before fill candle",
            "entry": "next candle open (mid-price OHLC proxy; no spread/bid-ask)",
            "ambiguous_same_candle_stop_and_target": "stop first",
            "gap_through_stop_or_target": "fill at candle open",
            "end_of_sample_positions": "marked to final close",
            "transaction_costs": "not modeled: spread/commission/swap/slippage unavailable",
            "monetary_pnl": "not reported; normalized R only because broker contract/tick value is unknown",
        },
        "history_bars": history_bars,
        "first_evaluated_index": first_index,
        "rows": len(candles),
        "first_source_time": candles[0].time.isoformat(),
        "last_source_time": candles[-1].time.isoformat(),
        "strategies": results,
        "portfolio": portfolio,
        "portfolio_ending_normalized_equity": round(shared_equity, 8),
    }
