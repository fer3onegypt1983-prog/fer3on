from __future__ import annotations
from hashlib import sha256
from dataclasses import replace
from .domain import AccountState, BotConfig, Candle, Decision, Side
from .experimental_strategies import StrategyRuntimeState, decide_experimental
from .p2_pullback_candidate import decide_p2_pullback_confirmation
from .market import atr, classify_state, location, reaction
from .structure import analyze_structure
from .trend import infer_trend
from .levels import build_zones, level_context
from .structural_sl_tp import structural_exit
from .calendar_levels import build_reference_levels, nearest_reference
from .volume_profile import build_volume_profile
from .liquidity import find_equal_pools, detect_sweep
from .mtf import timeframe_views
from .setup_engine import evaluate_setup
from .trade_management import build_profit_plan
from .execution_quality import evaluate_execution_quality
from .entry_quality import assess_entry_quality
from .primary_signals import primary_signal
from .position_sizing import build_position_plan


def _key(c: Candle, side: Side, entry: float) -> str:
    return sha256(f'{c.time.isoformat()}|{side.value}|{entry:.5f}'.encode()).hexdigest()[:20]


def _wait(state, loc, react, reason, meta=None):
    return Decision('WAIT', state=state, location=loc, reaction=react, reason=reason, metadata=meta or {})


def _scenario_context(setup, trend, structure, mtf) -> dict:
    continuation=float(setup.continuation or 0.0)
    reversal=float(setup.reversal or 0.0)
    range_probability=max(0.0, 1.0-max(continuation, reversal))
    candidates=[
        {'name':'CONTINUATION','probability':round(continuation,4)},
        {'name':'REVERSAL','probability':round(reversal,4)},
        {'name':'RANGE','probability':round(range_probability,4)},
    ]
    candidates.sort(key=lambda x:x['probability'], reverse=True)
    selected=candidates[0]['name'] if setup.action=='ENTER_READY' else 'NO_TRADE'
    rejected=[x for x in candidates if x['name'] != selected]
    votes=[]
    for value in (trend.direction, structure.bias, getattr(mtf.get('H1'),'direction','RANGE'), getattr(mtf.get('H4'),'direction','RANGE')):
        direction=str(value).upper()
        if direction in {'UP','DOWN'}: votes.append(direction)
    conflicts=sum(1 for i in range(len(votes)) for j in range(i+1,len(votes)) if votes[i] != votes[j])
    pairs=max(1, len(votes)*(len(votes)-1)//2)
    contradiction_score=round(100.0*conflicts/pairs,2)
    return {
        'selected':selected,
        'rejected':rejected,
        'candidates':candidates,
        'contradiction_score':contradiction_score,
        'direction_votes':votes,
    }


def decide(candles: list[Candle], account: AccountState, cfg: BotConfig, spread: float=0.0,
          enforce_position_limit: bool=True) -> Decision:
    if len(candles)<max(cfg.lookback,cfg.atr_period+5): return Decision('WAIT',reason='INSUFFICIENT_DATA')
    if enforce_position_limit and account.open_trades>=cfg.max_concurrent: return Decision('WAIT',reason='POSITION_LIMIT')
    if account.bars_since_last_entry<cfg.cooldown_bars: return Decision('WAIT',reason='COOLDOWN')
    daily_limit = min(account.day_start_equity * cfg.max_daily_loss, cfg.max_daily_loss_cash)
    if account.daily_loss_cash >= daily_limit: return Decision('BLOCK',reason='DAILY_LOSS_LIMIT')
    if spread>cfg.spread_limit: return Decision('WAIT',reason='SPREAD_TOO_WIDE')
    a=atr(candles,cfg.atr_period)
    if a<cfg.min_atr: return Decision('WAIT',reason='ATR_TOO_LOW')
    state=classify_state(candles,a); loc,pos=location(candles,cfg.impulse_window); react,sign=reaction(candles,a)
    structure=analyze_structure(candles,2,2); trend=infer_trend(structure); zones=build_zones(structure,a)
    setup=evaluate_setup(candles,structure,a)
    refs=build_reference_levels(candles)
    if not cfg.use_session_reference_levels:
        refs=[level for level in refs if level.name.startswith(("PREVIOUS_DAY_", "PREVIOUS_WEEK_"))]
    profile=build_volume_profile(candles[-cfg.lookback:],24); pools=find_equal_pools(structure,a); sweep=detect_sweep(candles,pools,a)
    mtf=timeframe_views(candles); context=level_context(zones,candles[-1].close)
    is_4h = cfg.timeframe.upper() in {'H4','4H'}
    ob_age = cfg.ob_4h_max_age if is_4h else cfg.ob_max_age
    ob_disp = cfg.ob_4h_min_displacement_atr if is_4h else cfg.ob_min_displacement_atr
    ob_width = cfg.ob_4h_max_width_atr if is_4h else cfg.ob_max_width_atr
    ob_left = cfg.ob_4h_structure_left if is_4h else cfg.ob_structure_left
    ob_right = cfg.ob_4h_structure_right if is_4h else cfg.ob_structure_right
    primary=primary_signal(candles,cfg.primary_strategy,cfg.momentum_lookback,cfg.donchian_entry_window,cfg.donchian_exit_window,
                           cfg.atr_period,cfg.donchian_buffer_atr,cfg.donchian_require_retest,
                           cfg.donchian_retest_max_bars,cfg.donchian_retest_tolerance_atr,
                           cfg.donchian_min_breakout_body_atr,cfg.donchian_max_breakout_body_atr,
                           cfg.fvg_min_gap_atr,cfg.fvg_max_age,
                           cfg.fvg_min_displacement_atr,ob_age,ob_disp,ob_width,ob_left,ob_right,
                           cfg.tsm_require_choch_retest, cfg.tsm_choch_max_age_bars,
                           cfg.tsm_choch_retest_tolerance_atr, cfg.tsm_choch_confirmation_body_atr,
                           cfg.tsm_choch_min_score)
    primary_active=cfg.primary_strategy.upper() in {'TSM','DONCHIAN','FVG_MODERATE','BOS','ORDER_BLOCK_MODERATE'}
    breakout_relaxed = cfg.primary_strategy.upper() == 'DONCHIAN' and cfg.donchian_relaxed_context
    if sign==0 and sweep.direction in {'BUY','SELL'}:
        sign=1 if sweep.direction=='BUY' else -1; react=sweep.event
    scenarios=_scenario_context(setup,trend,structure,mtf)
    meta={'atr':a,'location_percent':pos,'trend':trend.direction,'trend_phase':trend.phase,'trend_confidence':trend.confidence,
          'structure_bias':structure.bias,'structure_quality':structure.quality,
          'swing_points':[(p.index,p.label.value if p.label else None,round(p.price,5)) for p in structure.points[-8:]],
          'support':context['support'].midpoint if context['support'] else None,'resistance':context['resistance'].midpoint if context['resistance'] else None,
          'reference_levels':[(x.name,round(x.price,5),x.kind) for x in refs],
          'volume_profile':{'poc':profile.poc,'val':profile.value_area_low,'vah':profile.value_area_high,'hvn':profile.hvn,'lvn':profile.lvn},
          'liquidity':{'pools':[(p.kind,p.price,p.count) for p in pools],'event':sweep.event,'pool_price':sweep.pool_price},
          'mtf':{k:{'direction':v.direction,'phase':v.phase,'confidence':v.confidence} for k,v in mtf.items()},
          'forecast':{'action':setup.action,'event':setup.event,'pattern':setup.pattern,'continuation':setup.continuation,'reversal':setup.reversal,'level':setup.level,'reason':setup.reason},
          'primary_signal':{'name':primary.name,'side':primary.side.value if primary.side else None,'value':primary.value,'reason':primary.reason,'metadata':primary.metadata},
          'scenarios':scenarios}
    if primary_active and primary.side is None: return _wait(state,loc,react,'PRIMARY_SIGNAL_FLAT',meta)
    if cfg.require_market_event and not primary_active and setup.action!='ENTER_READY': return _wait(state,loc,react,'NO_CONFIRMED_MARKET_EVENT',meta)
    if primary_active:
        sign=1 if primary.side is Side.BUY else -1
        react=primary.name
    if cfg.primary_strategy.upper() == 'DONCHIAN' and primary.side is not None:
        # Breakout retests are not allowed at the opposite extreme of the range.
        if primary.side is Side.BUY and loc in {'HIGH_EXTREME', 'HIGH_HALF'}:
            return _wait(state,loc,react,'DONCHIAN_BUY_AT_HIGH_EXTREME',meta)
        if primary.side is Side.SELL and loc in {'LOW_EXTREME', 'LOW_HALF'}:
            return _wait(state,loc,react,'DONCHIAN_SELL_AT_LOW_EXTREME',meta)
    elif setup.side is not None:
        sign=1 if setup.side is Side.BUY else -1
        react=setup.event if setup.event!='NONE' else react
    if sign==0: return _wait(state,loc,react,'NO_REACTION',meta)
    if account.loss_pause and setup.event not in {'BOS','CHOCH'}: return _wait(state,loc,react,'LOSS_PAUSE_WAITING_FRESH_STRUCTURE',meta)
    if account.loss_pause and setup.event in {'BOS','CHOCH'}: meta['loss_pause_released_by']=setup.event
    if not primary_active and loc not in {'LOW_EXTREME','LOW_HALF','HIGH_EXTREME','HIGH_HALF'}: return _wait(state,loc,react,'NO_VALID_LOCATION',meta)
    side=Side.BUY if sign>0 else Side.SELL
    thesis_id=sha256(f'{cfg.primary_strategy}|{side.value}|{trend.direction}|{structure.bias}|{setup.event}|{loc}|{react}'.encode()).hexdigest()[:16]
    meta['thesis_id']=thesis_id
    meta['entry_reasons']=[f'primary={primary.name}:{primary.reason}',f'side={side.value}',f'trend={trend.direction}',f'structure={structure.bias}',f'event={setup.event}',f'reaction={react}',f'location={loc}',f'state={state.value}',f'sweep={sweep.event}']
    if cfg.enable_repeat_thesis_guard and account.last_loss_thesis and account.last_loss_thesis==thesis_id: return _wait(state,loc,react,'REPEAT_THESIS_AFTER_LOSS',meta)
    timing=assess_entry_quality([c.close for c in candles],a,side,pos)
    meta['entry_quality']={'velocity':timing.velocity,'velocity_class':timing.velocity_class,'late':timing.late,'score':timing.score,'reason':timing.reason}
    if cfg.enable_entry_quality_guard and timing.late and not primary_active: return _wait(state,loc,react,'LATE_ENTRY_AFTER_DISPLACEMENT',meta)
    if not primary_active and side is Side.BUY and loc not in {'LOW_EXTREME','LOW_HALF'}: return _wait(state,loc,react,'BUY_TOO_EXTENDED',meta)
    if not primary_active and side is Side.SELL and loc not in {'HIGH_EXTREME','HIGH_HALF'}: return _wait(state,loc,react,'SELL_TOO_EXTENDED',meta)
    if side is Side.SELL and not cfg.allow_short: return _wait(state,loc,react,'SHORT_DISABLED',meta)
    if breakout_relaxed:
        meta['context_gates_bypassed']=['H4_TREND_CONFLICT','H1_TREND_CONFLICT','TREND_CONFLICT','OPPOSING_LEVEL_TOO_CLOSE','REFERENCE_LEVEL_TOO_CLOSE']
    else:
        conflict_thresholds = {'H4': cfg.h4_conflict_min_confidence, 'H1': cfg.h1_conflict_min_confidence}
        for name in ('H4','H1'):
            view=mtf[name]
            if view.confidence>=conflict_thresholds[name] and ((side is Side.BUY and view.direction=='DOWN') or (side is Side.SELL and view.direction=='UP')):
                # At an extreme, require stronger higher-timeframe disagreement rather than blocking early.
                extreme = loc in {'LOW_EXTREME','HIGH_EXTREME'}
                required = min(0.95, conflict_thresholds[name] + (0.05 if extreme else 0.0))
                if view.confidence >= required: return _wait(state,loc,react,f'{name}_TREND_CONFLICT',meta)
        if side is Side.BUY and trend.direction=='DOWN': return _wait(state,loc,react,'TREND_CONFLICT_BUY',meta)
        if side is Side.SELL and trend.direction=='UP': return _wait(state,loc,react,'TREND_CONFLICT_SELL',meta)
    if not structure.points: return _wait(state,loc,react,'NO_CONFIRMED_STRUCTURE',meta)
    entry=candles[-1].close
    try: exits=structural_exit(side,entry,a,structure,zones,cfg.target_rr)
    except ValueError: return _wait(state,loc,react,'NO_STRUCTURAL_INVALIDATION',meta)
    if cfg.primary_strategy.upper() == 'DONCHIAN' and primary.metadata.get('breakout_level') is not None:
        level=float(primary.metadata['breakout_level'])
        buffer=a*0.10
        if side is Side.BUY:
            exits['stop']=min(exits['stop'], level-buffer)
        else:
            exits['stop']=max(exits['stop'], level+buffer)
        exits['risk_distance']=abs(entry-exits['stop'])
        exits['invalidation']='DONCHIAN_BREAKOUT_LEVEL_AND_STRUCTURAL_SWING'
    stop,target=exits['stop'],exits['target']; risk_distance=exits['risk_distance']
    if risk_distance<=0 or risk_distance>a*2.2: return _wait(state,loc,react,'STRUCTURAL_RISK_TOO_LARGE',meta)
    quality=evaluate_execution_quality(risk_distance,abs(target-entry),a,spread)
    meta['execution_quality']=quality
    if not quality['approved']: return _wait(state,loc,react,'EXECUTION_QUALITY_REJECT',meta)
    sizing=build_position_plan(account.equity,cfg.risk_per_trade,risk_distance,a,cfg.point_value,cfg.max_unit_size,
                               cfg.volatility_target_atr if cfg.enable_volatility_sizing and cfg.volatility_target_atr>0 else None)
    meta['position_sizing']={'risk_cash':sizing.risk_cash,'risk_fraction':sizing.risk_fraction,'unit_size':sizing.unit_size,
                             'volatility_scalar':sizing.volatility_scalar,'reason':sizing.reason,'point_value':cfg.point_value}
    opposing=context['resistance'] if side is Side.BUY else context['support']; ref=nearest_reference(refs,entry,side.value)
    if opposing and not breakout_relaxed:
        room=(opposing.low-entry) if side is Side.BUY else (entry-opposing.high)
        if room>0 and room/risk_distance<cfg.context_level_min_rr: return _wait(state,loc,react,'OPPOSING_LEVEL_TOO_CLOSE',meta)
    if ref and not breakout_relaxed:
        ref_room=(ref.price-entry) if side is Side.BUY else (entry-ref.price)
        if ref_room>0 and ref_room/risk_distance<cfg.context_level_min_rr: return _wait(state,loc,react,'REFERENCE_LEVEL_TOO_CLOSE',meta)
    meta.update({'risk_distance':risk_distance,'rr':abs(target-entry)/risk_distance,'sl_anchor_index':exits['anchor_index'],'sl_anchor_label':exits['anchor_label'],'invalidation_source':exits['invalidation']})
    plan=build_profit_plan(side,entry,stop,target)
    meta['profit_plan']={'tp1':plan.tp1,'tp2':plan.tp2,'final_target':plan.final_target,'breakeven_trigger':plan.breakeven_trigger,'partial_fraction':plan.partial_fraction}
    thesis=f'{cfg.primary_strategy} {primary.reason}; {trend.direction} structure with {state.value} at {loc}; {react}'; meta['thesis']=thesis
    return Decision('ENTER',side,entry,stop,target,state,loc,react,thesis,exits['invalidation'],'PRIMARY_SIGNAL_STRUCTURAL_ENTRY',sizing.risk_fraction*quality['risk_multiplier'],_key(candles[-1],side,entry),meta, strategy_id=cfg.primary_strategy.upper())


def decide_candidates(
    candles: list[Candle], account: AccountState, cfg: BotConfig, spread: float=0.0,
    strategy_states: dict[str, StrategyRuntimeState] | None=None,
    strategy_configs: dict[str, tuple[BotConfig, str]] | None=None,
    open_positions_by_strategy: dict[str, int] | None=None,
) -> list[Decision]:
    """Run each configured entry strategy independently; outputs remain attributable."""
    out=[]
    states = strategy_states if strategy_states is not None else {}
    for name in cfg.active_strategies:
        name=name.upper().strip()
        if name not in {'TSM','DONCHIAN','FVG_MODERATE','BOS','ORDER_BLOCK_MODERATE',
                        'LEVEL_MAP_SCENARIO_TREE','IMPULSE_RETEST','IMPULSE_MIDPOINT_REVERSAL',
                        'P2_PULLBACK_CONFIRMATION'}:
            continue
        profile = (strategy_configs or {}).get(name)
        candidate_cfg = profile[0] if profile else replace(cfg, primary_strategy=name, active_strategies=(name,))
        version = profile[1] if profile else None
        runtime_state = states.setdefault(name, StrategyRuntimeState())
        if (runtime_state.last_processed_candle_time == candles[-1].time
                and runtime_state.cached_decision is not None):
            out.append(runtime_state.cached_decision)
            continue
        if open_positions_by_strategy is not None:
            strategy_open = int(open_positions_by_strategy.get(name, 0))
            candidate_account = replace(
                account,
                open_trades=strategy_open,
                bars_since_last_entry=runtime_state.bars_since_last_entry if runtime_state else 10_000,
                consecutive_losses=0,
                loss_pause=False,
                last_loss_thesis="",
                last_loss_decision_key="",
            )
        elif runtime_state is not None:
            candidate_account = replace(account, bars_since_last_entry=runtime_state.bars_since_last_entry)
        else:
            candidate_account = account
        strategy_open = int(open_positions_by_strategy.get(name, 0)) if open_positions_by_strategy is not None else candidate_account.open_trades
        if strategy_open > 0:
            decision = Decision("WAIT", reason="STRATEGY_POSITION_ALREADY_OPEN",
                                metadata={"strategy_id": name}, strategy_id=name)
        elif name in {'LEVEL_MAP_SCENARIO_TREE','IMPULSE_RETEST','IMPULSE_MIDPOINT_REVERSAL'}:
            decision = decide_experimental(name,candles,candidate_account,candidate_cfg,runtime_state,version)
        elif name == 'P2_PULLBACK_CONFIRMATION':
            source_profile = (strategy_configs or {}).get('TSM')
            source_cfg = source_profile[0] if source_profile else replace(candidate_cfg, primary_strategy='TSM', active_strategies=('TSM',))
            source_version = source_profile[1] if source_profile else 'next-baseline-0.1'
            source_decision = decide(candles,candidate_account,source_cfg,spread,enforce_position_limit=False)
            decision = decide_p2_pullback_confirmation(
                candles,candidate_account,candidate_cfg,runtime_state,version,
                source_decision,source_version,
            )
        else:
            decision=decide(candles,candidate_account,candidate_cfg,spread,enforce_position_limit=False)
        runtime_state.bars_since_last_entry = 0 if decision.action == 'ENTER' else runtime_state.bars_since_last_entry + 1
        runtime_state.last_processed_candle_time = candles[-1].time
        metadata=decision.metadata.copy(); metadata['strategy_id']=name; metadata['active_strategy']=True
        if version:
            metadata['strategy_version']=version
        decision=replace(decision, metadata=metadata, strategy_id=name)
        runtime_state.cached_decision = decision
        out.append(decision)
    return out
