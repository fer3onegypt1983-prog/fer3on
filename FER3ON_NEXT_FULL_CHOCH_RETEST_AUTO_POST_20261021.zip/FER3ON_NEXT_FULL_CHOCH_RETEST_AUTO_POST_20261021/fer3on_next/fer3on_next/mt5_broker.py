from __future__ import annotations

"""Account-aware MT5 adapter for FER3ON Next.

Importing this module does not connect. A connection is created only by an
explicit CLI mode. Real-account order submission requires a second explicit
acknowledgement; demo orders are supported without changing strategy code.
"""

from datetime import datetime, time, timedelta, timezone
import json
import os
from pathlib import Path

from .domain import AccountState, BotConfig, Decision, Side
from .execution import RiskError, validate_risk
from .mt5_demo import MT5DemoBroker


class AccountModeError(RuntimeError):
    pass


MAGIC_BY_STRATEGY = {
    "TSM": 26092301,
    "DONCHIAN": 26092302,
    "FVG_MODERATE": 26092310,
    "BOS": 26092304,
    "ORDER_BLOCK_MODERATE": 26092311,
    "LEVEL_MAP_SCENARIO_TREE": 26092306,
    "IMPULSE_RETEST": 26092307,
    "IMPULSE_MIDPOINT_REVERSAL": 26092308,
    "P2_PULLBACK_CONFIRMATION": 26092309,
}
COMMENT_TAG = {
    "TSM": "TSM", "DONCHIAN": "DON", "FVG_MODERATE": "FVG", "BOS": "BOS",
    "ORDER_BLOCK_MODERATE": "OB", "LEVEL_MAP_SCENARIO_TREE": "LMS",
    "IMPULSE_RETEST": "IMPR", "IMPULSE_MIDPOINT_REVERSAL": "IMPM",
    "P2_PULLBACK_CONFIRMATION": "P2PB",
}


def validate_quote_geometry(side: Side, price: float, stop: float, target: float,
                            minimum_distance: float) -> None:
    """Fail closed when normalized SL/TP are invalid for the live quote."""
    distance = max(float(minimum_distance), 0.0)
    if side is Side.BUY:
        if not stop < price < target:
            raise RiskError("BUY price/stop/target geometry invalid at current quote")
        if price - stop < distance or target - price < distance:
            raise RiskError("BUY stop or target is inside broker minimum distance")
    elif side is Side.SELL:
        if not target < price < stop:
            raise RiskError("SELL price/stop/target geometry invalid at current quote")
        if stop - price < distance or price - target < distance:
            raise RiskError("SELL stop or target is inside broker minimum distance")
    else:
        raise RiskError("decision side is required for executable geometry")


class MT5Broker(MT5DemoBroker):
    """MT5 adapter for demo or real accounts with account-mode and risk guards."""

    def __init__(self, symbol: str, mode: str = "AUTO", deviation: int = 20):
        self.requested_mode = mode.upper()
        self.account_mode = "UNKNOWN"
        self.margin_mode = "UNKNOWN"
        self.account_id = "UNKNOWN"
        self._day_baseline_path = Path(os.getenv(
            "FER3ON_DAILY_BASELINE_FILE", "reports/account_day_baseline.json"
        ))
        super().__init__(symbol, deviation)

    def _connect_and_verify_demo(self):  # Base class calls this during construction.
        if self.requested_mode not in {"AUTO", "DEMO", "LIVE"}:
            raise AccountModeError("mode must be AUTO, DEMO, or LIVE")
        if not self.mt5.initialize():
            raise RuntimeError(f"MT5 initialize failed: {self.mt5.last_error()}")
        info = self.mt5.account_info()
        if info is None:
            raise AccountModeError("Cannot verify account identity/type; refusing to trade")
        demo = getattr(self.mt5, "ACCOUNT_TRADE_MODE_DEMO", 0)
        real = getattr(self.mt5, "ACCOUNT_TRADE_MODE_REAL", 2)
        contest = getattr(self.mt5, "ACCOUNT_TRADE_MODE_CONTEST", 1)
        actual = getattr(info, "trade_mode", None)
        detected = "DEMO" if actual == demo else "LIVE" if actual == real else "CONTEST" if actual == contest else "UNKNOWN"
        if detected not in {"DEMO", "LIVE"}:
            raise AccountModeError(f"Unsupported or unknown MT5 account mode: {actual}")
        if self.requested_mode in {"DEMO", "LIVE"} and self.requested_mode != detected:
            raise AccountModeError(f"Requested {self.requested_mode} mode but terminal account is {detected}")
        if detected == "LIVE":
            raise AccountModeError(
                "FER3ON Next is Demo-only in this build; real-account execution is disabled."
            )
        if detected == "LIVE":
            expected_login = os.getenv("FER3ON_LIVE_ACCOUNT_LOGIN", "").strip()
            expected_server = os.getenv("FER3ON_LIVE_ACCOUNT_SERVER", "").strip()
            actual_login = str(getattr(info, "login", ""))
            actual_server = str(getattr(info, "server", ""))
            if not expected_login or not expected_server:
                raise AccountModeError("Live mode also requires FER3ON_LIVE_ACCOUNT_LOGIN and FER3ON_LIVE_ACCOUNT_SERVER")
            if expected_login != actual_login or expected_server != actual_server:
                raise AccountModeError("Live account login/server do not match the explicitly selected account")
        self.account_mode = detected
        self.account_id = f"{getattr(info, 'server', '')}:{getattr(info, 'login', '')}"
        margin = getattr(info, "margin_mode", None)
        hedging = getattr(self.mt5, "ACCOUNT_MARGIN_MODE_RETAIL_HEDGING", 2)
        netting = getattr(self.mt5, "ACCOUNT_MARGIN_MODE_RETAIL_NETTING", 0)
        exchange = getattr(self.mt5, "ACCOUNT_MARGIN_MODE_EXCHANGE", 1)
        self.margin_mode = "HEDGING" if margin == hedging else "NETTING" if margin == netting else "EXCHANGE" if margin == exchange else f"UNKNOWN:{margin}"
        symbol_info = self.mt5.symbol_info(self.symbol)
        if symbol_info is None:
            if not self.mt5.symbol_select(self.symbol, True):
                raise RuntimeError(f"Cannot select symbol {self.symbol}: {self.mt5.last_error()}")
            symbol_info = self.mt5.symbol_info(self.symbol)
        if symbol_info is None or not getattr(symbol_info, "visible", True):
            raise RuntimeError(f"MT5 symbol unavailable: {self.symbol}")

    def _day_start_equity(self, current_equity: float) -> float:
        """Persist account/day equity baseline so a process restart doesn't reset the cap."""
        now = datetime.now(timezone.utc)
        key = f"{self.account_id}|{now.date().isoformat()}"
        path = self._day_baseline_path
        if not path.is_absolute():
            path = Path(__file__).resolve().parents[1] / path
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {}
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                data = {}
        if key not in data:
            data = {key: current_equity}
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
            tmp.replace(path)
        return float(data[key])

    def positions(self):
        found = self.mt5.positions_get(symbol=self.symbol)
        if found is None:
            raise RuntimeError(f"positions_get failed: {self.mt5.last_error()}")
        return list(found)

    def positions_by_strategy(self) -> dict[str, int]:
        result = {}
        by_magic = {value: name for name, value in MAGIC_BY_STRATEGY.items()}
        for position in self.positions():
            strategy = by_magic.get(int(getattr(position, "magic", 0) or 0))
            if strategy:
                result[strategy] = result.get(strategy, 0) + 1
        return result

    def paused_strategies(self, cfg: BotConfig):
        if not cfg.enable_strategy_loss_pause or not hasattr(self.mt5, "history_deals_get"):
            return {}
        now = datetime.now(timezone.utc)
        start = now - timedelta(hours=cfg.strategy_loss_pause_hours)
        deals = self.mt5.history_deals_get(start, now) or []
        by_magic = {value: name for name, value in MAGIC_BY_STRATEGY.items()}
        losses: dict[str, float] = {}
        for deal in deals:
            if getattr(deal, "entry", None) != getattr(self.mt5, "DEAL_ENTRY_OUT", 1):
                continue
            strategy = by_magic.get(int(getattr(deal, "magic", 0) or 0))
            if not strategy:
                continue
            pnl = (
                float(getattr(deal, "profit", 0.0) or 0.0)
                + float(getattr(deal, "swap", 0.0) or 0.0)
                + float(getattr(deal, "commission", 0.0) or 0.0)
            )
            losses[strategy] = losses.get(strategy, 0.0) + pnl
        info = self.mt5.account_info()
        equity = float(getattr(info, "equity", 0.0) or 0.0) if info else 0.0
        threshold = equity * cfg.strategy_loss_pause_fraction
        return {name: pnl for name, pnl in losses.items() if threshold > 0 and pnl <= -threshold}

    def account_state(self) -> AccountState:
        info = self.mt5.account_info()
        if info is None:
            raise RuntimeError("MT5 account_info unavailable")
        positions = self.positions()
        equity = float(info.equity)
        day_start = self._day_start_equity(equity)
        return AccountState(
            equity=equity,
            day_start_equity=day_start,
            open_trades=len(positions),
            bars_since_last_entry=10_000,
        )

    def send(self, decision: Decision, account: AccountState, cfg: BotConfig, logger=None):
        validate_risk(decision, account, cfg)
        strategy = (decision.strategy_id or decision.metadata.get("strategy_id", "")).upper()
        if strategy not in MAGIC_BY_STRATEGY:
            raise RiskError(f"Unknown strategy identity: {strategy}")
        existing = self.positions()
        existing_for_strategy = [p for p in existing if int(getattr(p, "magic", 0) or 0) == MAGIC_BY_STRATEGY[strategy]]
        if existing_for_strategy:
            raise RiskError("one-position-per-strategy limit")
        if len(existing) >= cfg.max_concurrent:
            raise RiskError("account-wide concurrent position limit")
        if self.margin_mode != "HEDGING" and existing:
            # Netting/exchange positions merge opposing strategies and share SL/TP;
            # do not corrupt strategy attribution or overwrite another strategy's exits.
            raise RiskError(f"{self.margin_mode} account already has a position on {self.symbol}; independent strategy exits cannot be preserved")

        tick = self.mt5.symbol_info_tick(self.symbol)
        info = self.mt5.symbol_info(self.symbol)
        if tick is None or info is None:
            raise RuntimeError("MT5 symbol tick/info unavailable")
        tick_size = float(getattr(info, "trade_tick_size", 0.0) or getattr(info, "point", 0.0) or 0.0)
        tick_value = float(
            getattr(info, "trade_tick_value_loss", 0.0)
            or getattr(info, "trade_tick_value", 0.0)
            or getattr(info, "trade_tick_value_profit", 0.0)
            or 0.0
        )
        if tick_size <= 0 or tick_value <= 0:
            raise RiskError("broker tick size/value unavailable; cannot compute executable price or risk")
        price = float(tick.ask if decision.side is Side.BUY else tick.bid)
        digits = int(getattr(info, "digits", 2) or 2)
        price = round(round(price / tick_size) * tick_size, digits)
        stop = round(round(float(decision.stop) / tick_size) * tick_size, digits)
        target = round(round(float(decision.target) / tick_size) * tick_size, digits)
        point = float(getattr(info, "point", 0.0) or 0.0)
        stops_level = float(getattr(info, "trade_stops_level", 0.0) or 0.0) * point
        distance = abs(price - stop)
        minimum_distance = max(stops_level, point)
        validate_quote_geometry(decision.side, price, stop, target, minimum_distance)

        risk_cash = float(account.equity) * float(decision.risk_fraction)
        loss_per_lot = distance / tick_size * tick_value
        bot_magics = set(MAGIC_BY_STRATEGY.values())
        open_bot_risk = 0.0
        for position in existing:
            if int(getattr(position, "magic", 0) or 0) not in bot_magics:
                continue
            existing_sl = float(getattr(position, "sl", 0.0) or 0.0)
            existing_volume = float(getattr(position, "volume", 0.0) or 0.0)
            existing_entry = float(getattr(position, "price_open", 0.0) or 0.0)
            if existing_sl <= 0 or existing_volume <= 0 or existing_entry <= 0:
                raise RiskError("cannot verify risk on an existing FER3ON position")
            open_bot_risk += abs(existing_entry - existing_sl) / tick_size * tick_value * existing_volume
        raw_volume = risk_cash / loss_per_lot
        minimum = float(getattr(info, "volume_min", 0.0) or 0.0)
        maximum = float(getattr(info, "volume_max", 0.0) or 0.0)
        step = float(getattr(info, "volume_step", 0.0) or 0.0)
        if min(minimum, maximum, step) <= 0 or maximum < minimum:
            raise RiskError("broker volume constraints are invalid")
        configured_cap = float(cfg.max_unit_size)
        if configured_cap <= 0:
            raise RiskError("configured max_unit_size must be positive")
        volume = min(maximum, configured_cap, (raw_volume // step) * step)
        if volume + 1e-12 < minimum:
            raise RiskError(f"minimum broker volume {minimum} exceeds configured risk budget; computed={raw_volume:.8f}")
        volume = round(volume, 8)

        account_info = self.mt5.account_info()
        if account_info is None:
            raise RuntimeError("MT5 account_info unavailable before margin check")
        free_margin = float(getattr(account_info, "margin_free", 0.0) or 0.0)
        calc_margin = getattr(self.mt5, "order_calc_margin", None)
        order_type = self.mt5.ORDER_TYPE_BUY if decision.side is Side.BUY else self.mt5.ORDER_TYPE_SELL
        if free_margin <= 0:
            raise RiskError("broker reports no free margin")
        if calc_margin:
            budget = free_margin * 0.80
            while volume >= minimum - 1e-12:
                required = calc_margin(order_type, self.symbol, volume, price)
                if required is None:
                    raise RiskError("broker could not calculate required margin")
                if float(required) <= budget:
                    break
                volume = round(volume - step, 8)
            if volume < minimum - 1e-12:
                raise RiskError("insufficient margin at risk-budget-compliant minimum volume")

        decision.metadata["execution_sizing"] = {
            "account_mode": self.account_mode,
            "margin_mode": self.margin_mode,
            "quote_price": price,
            "stop_distance": distance,
            "risk_budget_cash": risk_cash,
            "tick_size": tick_size,
            "tick_value_per_lot": tick_value,
            "loss_per_lot_at_stop": loss_per_lot,
            "volume": volume,
            "estimated_loss_at_stop": volume * loss_per_lot,
            "aggregate_open_bot_risk": open_bot_risk,
            "broker_min_volume": minimum,
            "broker_volume_step": step,
            "free_margin_before_order": free_margin,
        }

        symbol_fill = int(getattr(info, "filling_mode", 0) or 0)
        fill_candidates = []
        symbol_fok = int(getattr(self.mt5, "SYMBOL_FILLING_FOK", 1))
        symbol_ioc = int(getattr(self.mt5, "SYMBOL_FILLING_IOC", 2))
        if symbol_fill & symbol_ioc:
            fill_candidates.append(getattr(self.mt5, "ORDER_FILLING_IOC", 1))
        if symbol_fill & symbol_fok:
            fill_candidates.append(getattr(self.mt5, "ORDER_FILLING_FOK", 0))
        if not fill_candidates:
            raise RiskError("symbol does not expose a supported FOK/IOC filling mode")

        request = {
            "action": self.mt5.TRADE_ACTION_DEAL, "symbol": self.symbol,
            "volume": volume, "type": order_type, "price": price,
            "sl": stop, "tp": target, "deviation": self.deviation,
            "magic": MAGIC_BY_STRATEGY[strategy],
            "comment": f"FER3ON_{COMMENT_TAG[strategy]}_{self.account_mode}",
            "type_time": self.mt5.ORDER_TIME_GTC,
            "type_filling": fill_candidates[0],
        }
        check = None
        if hasattr(self.mt5, "order_check"):
            success_codes = {
                getattr(self.mt5, "TRADE_RETCODE_CHECK_DONE", 0),
                getattr(self.mt5, "TRADE_RETCODE_DONE", 10009),
            }
            for filling in fill_candidates:
                request["type_filling"] = filling
                check = self.mt5.order_check(request)
                if check is not None and getattr(check, "retcode", None) in success_codes:
                    break
            if check is None or getattr(check, "retcode", None) not in success_codes:
                raise RuntimeError(f"order_check rejected: {check}")
        if logger:
            logger.order_submitted(decision, request)
        result = self.mt5.order_send(request)
        successful_send_codes = {
            getattr(self.mt5, "TRADE_RETCODE_DONE", 10009),
            getattr(self.mt5, "TRADE_RETCODE_DONE_PARTIAL", 10010),
        }
        if result is None or getattr(result, "retcode", 0) not in successful_send_codes:
            raise RuntimeError(f"MT5 order rejected: {result}")
        return result
