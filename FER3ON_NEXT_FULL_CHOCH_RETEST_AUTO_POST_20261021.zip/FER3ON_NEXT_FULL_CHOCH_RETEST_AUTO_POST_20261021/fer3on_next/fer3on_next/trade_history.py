from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3
from typing import Any, Iterable

from .mt5_broker import COMMENT_TAG, MAGIC_BY_STRATEGY


SCHEMA = """
CREATE TABLE IF NOT EXISTS mt5_deals (
    account_id TEXT NOT NULL,
    ticket TEXT NOT NULL,
    order_ticket TEXT NOT NULL DEFAULT '',
    position_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    time_msc INTEGER NOT NULL,
    time_utc TEXT NOT NULL,
    deal_type INTEGER,
    entry_type INTEGER,
    magic INTEGER NOT NULL DEFAULT 0,
    strategy_id TEXT NOT NULL DEFAULT '',
    volume REAL NOT NULL DEFAULT 0,
    price REAL NOT NULL DEFAULT 0,
    profit REAL NOT NULL DEFAULT 0,
    commission REAL NOT NULL DEFAULT 0,
    swap REAL NOT NULL DEFAULT 0,
    fee REAL NOT NULL DEFAULT 0,
    comment TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (account_id, ticket)
);
CREATE INDEX IF NOT EXISTS idx_mt5_deals_position ON mt5_deals(account_id, position_id);
CREATE INDEX IF NOT EXISTS idx_mt5_deals_time ON mt5_deals(account_id, time_msc);
CREATE TABLE IF NOT EXISTS mt5_sync_state (
    account_id TEXT PRIMARY KEY,
    last_sync_utc TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS mt5_closed_trades (
    account_id TEXT NOT NULL,
    position_id TEXT NOT NULL,
    strategy_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    entry_order_tickets TEXT NOT NULL DEFAULT '[]',
    entry_deal_tickets TEXT NOT NULL DEFAULT '[]',
    exit_order_tickets TEXT NOT NULL DEFAULT '[]',
    entry_time_utc TEXT NOT NULL,
    close_time_utc TEXT NOT NULL,
    entry_volume REAL NOT NULL,
    entry_price REAL,
    exit_volume REAL NOT NULL,
    exit_price REAL,
    gross_profit REAL NOT NULL,
    commission REAL NOT NULL,
    swap REAL NOT NULL,
    fee REAL NOT NULL,
    net_profit REAL NOT NULL,
    outcome TEXT NOT NULL,
    deal_count INTEGER NOT NULL,
    updated_at_utc TEXT NOT NULL,
    PRIMARY KEY (account_id, position_id)
);
CREATE INDEX IF NOT EXISTS idx_mt5_closed_trades_strategy ON mt5_closed_trades(account_id, strategy_id, close_time_utc);
"""


def _value(obj: object, name: str, default: Any = None) -> Any:
    return getattr(obj, name, default)


def _strategy_from_comment(comment: str) -> str:
    if not comment.startswith("FER3ON_"):
        return ""
    tail = comment[len("FER3ON_"):].split("_")[0]
    for strategy, tag in COMMENT_TAG.items():
        if tail == tag:
            return strategy
    if tail in MAGIC_BY_STRATEGY:
        return tail
    return ""


def _utc_from_deal(deal: object) -> tuple[int, str]:
    time_msc = int(_value(deal, "time_msc", 0) or 0)
    if time_msc > 0:
        dt = datetime.fromtimestamp(time_msc / 1000.0, tz=timezone.utc)
    else:
        dt = datetime.fromtimestamp(int(_value(deal, "time", 0) or 0), tz=timezone.utc)
        time_msc = int(dt.timestamp() * 1000)
    return time_msc, dt.isoformat()


def _deal_record(deal: object, account_id: str) -> dict[str, Any]:
    time_msc, time_utc = _utc_from_deal(deal)
    magic = int(_value(deal, "magic", 0) or 0)
    comment = str(_value(deal, "comment", "") or "")
    strategy_id = next((s for s, value in MAGIC_BY_STRATEGY.items() if value == magic), "")
    if not strategy_id:
        strategy_id = _strategy_from_comment(comment)
    return {
        "account_id": account_id,
        "ticket": str(_value(deal, "ticket", "") or ""),
        "order_ticket": str(_value(deal, "order", "") or ""),
        "position_id": str(_value(deal, "position_id", "") or ""),
        "symbol": str(_value(deal, "symbol", "") or ""),
        "time_msc": time_msc,
        "time_utc": time_utc,
        "deal_type": _optional_int(_value(deal, "type")),
        "entry_type": _optional_int(_value(deal, "entry")),
        "magic": magic,
        "strategy_id": strategy_id,
        "volume": float(_value(deal, "volume", 0.0) or 0.0),
        "price": float(_value(deal, "price", 0.0) or 0.0),
        "profit": float(_value(deal, "profit", 0.0) or 0.0),
        "commission": float(_value(deal, "commission", 0.0) or 0.0),
        "swap": float(_value(deal, "swap", 0.0) or 0.0),
        "fee": float(_value(deal, "fee", 0.0) or 0.0),
        "comment": comment,
    }


def _optional_int(value: Any) -> int | None:
    return None if value is None else int(value)


class ClosedTradeStore:
    """Local durable SQLite store for MT5 deals and fully closed FER3ON positions."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(self.path, timeout=20.0)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA synchronous=FULL")
        self.connection.executescript(SCHEMA)
        self.connection.commit()

    def close(self) -> None:
        self.connection.close()

    def last_sync(self, account_id: str) -> datetime | None:
        row = self.connection.execute(
            "SELECT last_sync_utc FROM mt5_sync_state WHERE account_id=?", (account_id,)
        ).fetchone()
        return datetime.fromisoformat(row[0]) if row else None

    def known_position_ids(self, account_id: str) -> set[str]:
        rows = self.connection.execute(
            "SELECT DISTINCT position_id FROM mt5_deals WHERE account_id=?", (account_id,)
        )
        return {str(row[0]) for row in rows if row[0]}

    def ingest(self, records: Iterable[dict[str, Any]], account_id: str, symbol: str,
               open_position_ids: set[str], entry_in: int, exit_codes: set[int]) -> tuple[int, int]:
        records = [record if isinstance(record, dict) else _deal_record(record, account_id)
                   for record in records]
        # A first import may contain an exit deal whose broker comment is generic.
        # Resolve its position ID using any recognized FER3ON entry in the same batch.
        recognized_ids = self.known_position_ids(account_id)
        recognized_ids.update(
            r["position_id"] for r in records
            if r["position_id"] and (r["strategy_id"] or r["comment"].startswith("FER3ON_"))
        )
        selected = [
            r for r in records
            if r["symbol"] == symbol
            and r["position_id"]
            and (r["position_id"] in recognized_ids or r["strategy_id"] or r["comment"].startswith("FER3ON_"))
        ]
        sql = """INSERT INTO mt5_deals (
            account_id,ticket,order_ticket,position_id,symbol,time_msc,time_utc,deal_type,entry_type,
            magic,strategy_id,volume,price,profit,commission,swap,fee,comment
        ) VALUES (
            :account_id,:ticket,:order_ticket,:position_id,:symbol,:time_msc,:time_utc,:deal_type,:entry_type,
            :magic,:strategy_id,:volume,:price,:profit,:commission,:swap,:fee,:comment
        ) ON CONFLICT(account_id,ticket) DO UPDATE SET
            order_ticket=excluded.order_ticket,position_id=excluded.position_id,symbol=excluded.symbol,
            time_msc=excluded.time_msc,time_utc=excluded.time_utc,deal_type=excluded.deal_type,
            entry_type=excluded.entry_type,magic=excluded.magic,strategy_id=excluded.strategy_id,
            volume=excluded.volume,price=excluded.price,profit=excluded.profit,
            commission=excluded.commission,swap=excluded.swap,fee=excluded.fee,comment=excluded.comment"""
        before = self.connection.total_changes
        with self.connection:
            self.connection.executemany(sql, selected)
            self._refresh_closed(account_id, symbol, open_position_ids, entry_in, exit_codes)
        changed = self.connection.total_changes - before
        return len(selected), changed

    def _refresh_closed(self, account_id: str, symbol: str, open_ids: set[str],
                        entry_in: int, exit_codes: set[int]) -> None:
        rows = self.connection.execute(
            "SELECT * FROM mt5_deals WHERE account_id=? AND symbol=? ORDER BY time_msc,ticket",
            (account_id, symbol),
        ).fetchall()
        grouped: dict[str, list[sqlite3.Row]] = {}
        for row in rows:
            grouped.setdefault(str(row["position_id"]), []).append(row)
        now = datetime.now(timezone.utc).isoformat()
        for position_id, deals in grouped.items():
            if position_id in open_ids:
                continue
            entries = [d for d in deals if d["entry_type"] == entry_in]
            exits = [d for d in deals if d["entry_type"] in exit_codes]
            if not entries or not exits:
                continue
            strategies = {d["strategy_id"] for d in deals if d["strategy_id"]}
            if len(strategies) != 1:
                continue
            strategy_id = next(iter(strategies))
            entry_volume = sum(float(d["volume"] or 0) for d in entries)
            exit_volume = sum(float(d["volume"] or 0) for d in exits)
            entry_price = (sum(float(d["price"] or 0) * float(d["volume"] or 0) for d in entries) / entry_volume) if entry_volume else None
            exit_price = (sum(float(d["price"] or 0) * float(d["volume"] or 0) for d in exits) / exit_volume) if exit_volume else None
            first_entry = entries[0]
            deal_type = first_entry["deal_type"]
            side = "BUY" if deal_type == 0 else "SELL" if deal_type == 1 else "UNKNOWN"
            gross = sum(float(d["profit"] or 0) for d in deals)
            commission = sum(float(d["commission"] or 0) for d in deals)
            swap = sum(float(d["swap"] or 0) for d in deals)
            fee = sum(float(d["fee"] or 0) for d in deals)
            net = gross + commission + swap + fee
            outcome = "WIN" if net > 1e-8 else "LOSS" if net < -1e-8 else "BREAKEVEN"
            close_time = max(d["time_utc"] for d in exits)
            values = (
                account_id, position_id, strategy_id, symbol, side,
                json.dumps(sorted({d["order_ticket"] for d in entries if d["order_ticket"]})),
                json.dumps(sorted({d["ticket"] for d in entries if d["ticket"]})),
                json.dumps(sorted({d["order_ticket"] for d in exits if d["order_ticket"]})),
                min(d["time_utc"] for d in entries), close_time,
                entry_volume, entry_price, exit_volume, exit_price,
                gross, commission, swap, fee, net, outcome, len(deals), now,
            )
            self.connection.execute("""INSERT INTO mt5_closed_trades (
                account_id,position_id,strategy_id,symbol,side,entry_order_tickets,entry_deal_tickets,
                exit_order_tickets,entry_time_utc,close_time_utc,
                entry_volume,entry_price,exit_volume,exit_price,gross_profit,commission,swap,fee,
                net_profit,outcome,deal_count,updated_at_utc
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(account_id,position_id) DO UPDATE SET
                strategy_id=excluded.strategy_id,symbol=excluded.symbol,side=excluded.side,
                entry_order_tickets=excluded.entry_order_tickets,
                entry_deal_tickets=excluded.entry_deal_tickets,
                exit_order_tickets=excluded.exit_order_tickets,
                entry_time_utc=excluded.entry_time_utc,close_time_utc=excluded.close_time_utc,
                entry_volume=excluded.entry_volume,entry_price=excluded.entry_price,
                exit_volume=excluded.exit_volume,exit_price=excluded.exit_price,
                gross_profit=excluded.gross_profit,commission=excluded.commission,
                swap=excluded.swap,fee=excluded.fee,net_profit=excluded.net_profit,
                outcome=excluded.outcome,deal_count=excluded.deal_count,
                updated_at_utc=excluded.updated_at_utc""", values)

    def set_sync_time(self, account_id: str, when: datetime) -> None:
        value = when.astimezone(timezone.utc).isoformat()
        with self.connection:
            self.connection.execute("""INSERT INTO mt5_sync_state(account_id,last_sync_utc)
                VALUES(?,?) ON CONFLICT(account_id) DO UPDATE SET last_sync_utc=excluded.last_sync_utc""",
                (account_id, value))

    def closed_trades(self, account_id: str) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            "SELECT * FROM mt5_closed_trades WHERE account_id=? ORDER BY close_time_utc,position_id",
            (account_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def summary(self, account_id: str) -> list[dict[str, Any]]:
        rows = self.connection.execute("""SELECT strategy_id,
            COUNT(*) AS closed_trades,
            SUM(CASE WHEN outcome='WIN' THEN 1 ELSE 0 END) AS wins,
            SUM(CASE WHEN outcome='LOSS' THEN 1 ELSE 0 END) AS losses,
            SUM(CASE WHEN outcome='BREAKEVEN' THEN 1 ELSE 0 END) AS breakeven,
            SUM(CASE WHEN net_profit > 0 THEN net_profit ELSE 0 END) AS gross_wins,
            ABS(SUM(CASE WHEN net_profit < 0 THEN net_profit ELSE 0 END)) AS gross_losses,
            SUM(net_profit) AS net_profit
            FROM mt5_closed_trades WHERE account_id=? GROUP BY strategy_id ORDER BY strategy_id""",
            (account_id,),
        ).fetchall()
        observed = {str(row["strategy_id"]): dict(row) for row in rows}
        result = []
        for strategy_id in MAGIC_BY_STRATEGY:
            row = observed.get(strategy_id, {
                "strategy_id": strategy_id, "closed_trades": 0, "wins": 0,
                "losses": 0, "breakeven": 0, "gross_wins": 0.0,
                "gross_losses": 0.0, "net_profit": 0.0,
            })
            decisive = int(row["wins"] or 0) + int(row["losses"] or 0)
            row["win_rate_pct"] = (100.0 * int(row["wins"] or 0) / decisive) if decisive else None
            row["profit_factor"] = (
                float(row["gross_wins"]) / float(row["gross_losses"])
                if float(row["gross_losses"] or 0) > 0 else None
            )
            result.append(row)
        return result

    def export_csv(self, account_id: str, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        rows = self.closed_trades(account_id)
        columns = list(rows[0]) if rows else [
            "account_id", "position_id", "strategy_id", "symbol", "side", "entry_time_utc",
            "entry_order_tickets", "entry_deal_tickets", "exit_order_tickets",
            "close_time_utc", "entry_volume", "entry_price", "exit_volume", "exit_price",
            "gross_profit", "commission", "swap", "fee", "net_profit", "outcome", "deal_count",
            "updated_at_utc",
        ]
        with path.open("w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns)
            writer.writeheader()
            writer.writerows(rows)
        return path

    def export_summary_csv(self, account_id: str, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        rows = self.summary(account_id)
        columns = ["strategy_id", "closed_trades", "wins", "losses", "breakeven",
                   "win_rate_pct", "gross_wins", "gross_losses", "profit_factor", "net_profit"]
        with path.open("w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns)
            writer.writeheader()
            writer.writerows(rows)
        return path

    def export_order_reconciliation(self, account_id: str, ledger_path: str | Path,
                                   path: str | Path) -> Path:
        """Match successful bot order-result tickets to imported closed position IDs."""
        closed: dict[str, dict[str, Any]] = {}
        for trade in self.closed_trades(account_id):
            for ticket in json.loads(trade["entry_order_tickets"] or "[]"):
                closed[str(ticket)] = trade
            for ticket in json.loads(trade["entry_deal_tickets"] or "[]"):
                closed[str(ticket)] = trade
        successful: dict[str, dict[str, Any]] = {}
        ledger = Path(ledger_path)
        if ledger.exists():
            with ledger.open("r", encoding="utf-8") as stream:
                for line in stream:
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if (event.get("event") != "ORDER_RESULT" or
                            str(event.get("account_id") or account_id) != account_id or
                            event.get("retcode") != 10009):
                        continue
                    ticket = str(event.get("ticket") or "")
                    if ticket:
                        successful[ticket] = event
        rows = []
        for ticket, event in successful.items():
            trade = closed.get(ticket)
            rows.append({
                "account_id": account_id,
                "order_or_deal_ticket": ticket,
                "correlation_id": event.get("correlation_id", ""),
                "strategy_id": (trade or {}).get("strategy_id") or event.get("strategy_id", ""),
                "order_accepted_utc": event.get("event_time", ""),
                "position_id": (trade or {}).get("position_id", ""),
                "entry_time_utc": (trade or {}).get("entry_time_utc", ""),
                "close_time_utc": (trade or {}).get("close_time_utc", ""),
                "status": "CLOSED" if trade else "NOT_YET_MATCHED_TO_CLOSED_TRADE",
                "net_profit": (trade or {}).get("net_profit", ""),
                "outcome": (trade or {}).get("outcome", ""),
            })
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        columns = ["account_id", "order_or_deal_ticket", "correlation_id", "strategy_id",
                   "order_accepted_utc", "position_id", "entry_time_utc", "close_time_utc",
                   "status", "net_profit", "outcome"]
        with path.open("w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.DictWriter(stream, fieldnames=columns)
            writer.writeheader()
            writer.writerows(rows)
        return path


def sync_mt5_history(broker: object, store: ClosedTradeStore, symbol: str,
                     initial_lookback_days: int = 365, overlap_minutes: int = 120) -> dict[str, Any]:
    """Fetch recent MT5 deals idempotently; aggregates only fully closed bot positions."""
    if initial_lookback_days < 1 or overlap_minutes < 0:
        raise ValueError("history lookback must be positive and overlap non-negative")
    account_id = str(getattr(broker, "account_id", "") or "")
    if not account_id or account_id == "UNKNOWN":
        raise RuntimeError("verified MT5 account identity is required for history import")
    mt5 = getattr(broker, "mt5", None)
    getter = getattr(mt5, "history_deals_get", None)
    if getter is None:
        raise RuntimeError("MT5 history_deals_get is unavailable")
    now = datetime.now(timezone.utc)
    last_sync = store.last_sync(account_id)
    start = (last_sync - timedelta(minutes=overlap_minutes)) if last_sync else (now - timedelta(days=initial_lookback_days))
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    raw_deals = getter(start, now)
    if raw_deals is None:
        raise RuntimeError(f"MT5 history_deals_get failed: {mt5.last_error()}")
    records = [_deal_record(d, account_id) for d in raw_deals]
    positions = broker.positions()
    open_ids = set()
    for position in positions:
        identifier = _value(position, "identifier", None)
        ticket = _value(position, "ticket", None)
        if identifier not in (None, 0, "0"):
            open_ids.add(str(identifier))
        if ticket not in (None, 0, "0"):
            open_ids.add(str(ticket))
    entry_in = int(getattr(mt5, "DEAL_ENTRY_IN", 0))
    exit_codes = {
        int(getattr(mt5, "DEAL_ENTRY_OUT", 1)),
        int(getattr(mt5, "DEAL_ENTRY_OUT_BY", 3)),
        int(getattr(mt5, "DEAL_ENTRY_INOUT", 2)),
    }
    imported, changed = store.ingest(records, account_id, symbol, open_ids, entry_in, exit_codes)
    store.set_sync_time(account_id, now)
    closed = store.summary(account_id)
    return {
        "account_id": account_id,
        "symbol": symbol,
        "query_from_utc": start.isoformat(),
        "query_to_utc": now.isoformat(),
        "deals_returned_by_mt5": len(raw_deals),
        "bot_deals_upserted": imported,
        "database_rows_inserted_or_updated": changed,
        "closed_trade_counts_by_strategy": closed,
        "database": str(store.path),
    }
