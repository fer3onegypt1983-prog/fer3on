from __future__ import annotations

import os
import time
import json
import sys
import subprocess
from dataclasses import asdict
import hashlib
from hashlib import sha256
from pathlib import Path
from dataclasses import replace

from .domain import BotConfig
from .experimental_strategies import StrategyRuntimeState
from .identity import new_run_id
from .live_trade_logging import LiveTradeLogger
from .mt5_broker import MT5Broker
from .strategy import decide_candidates
from .trade_history import ClosedTradeStore, sync_mt5_history


def _post_analysis_candle_path(project_root: Path, timeframe: str) -> Path:
    names = {"M1": "1m", "M5": "5m", "M15": "15m", "M30": "30m",
             "H1": "1h", "H4": "4h", "D1": "1d"}
    override = os.getenv("FER3ON_POST_ANALYSIS_CANDLES", "").strip()
    if override:
        path = Path(override)
        return path if path.is_absolute() else project_root / path
    suffix = names.get(timeframe.upper(), timeframe.lower())
    return project_root / "data" / "xauusd_kaggle" / "normalized" / f"xauusd_{suffix}.csv"


def _start_post_analysis(project_root: Path, trades_csv: Path, timeframe: str,
                         last_digest: str | None):
    """Start read-only MFE/MAE analysis only when the closed-trade CSV changed."""
    if os.getenv("FER3ON_POST_ANALYSIS_ENABLED", "YES").upper() not in {"YES", "TRUE", "1"}:
        return last_digest, None
    if not trades_csv.is_file():
        return last_digest, None
    digest = sha256(trades_csv.read_bytes()).hexdigest()
    if digest == last_digest:
        return last_digest, None
    candles_csv = _post_analysis_candle_path(project_root, timeframe)
    tool = project_root / "tools" / "trade_post_analysis.py"
    if not candles_csv.is_file() or not tool.is_file():
        print(f"[FER3ON][POST_ANALYSIS][WARN] missing input: trades={trades_csv} candles={candles_csv}")
        return digest, None
    output_dir = project_root / "reports" / "post_analysis_live"
    output_dir.mkdir(parents=True, exist_ok=True)
    bars = os.getenv("FER3ON_POST_ANALYSIS_BARS", "20")
    log_path = output_dir / "post_analysis_live.log"
    log = log_path.open("a", encoding="utf-8")
    process = subprocess.Popen(
        [sys.executable, str(tool), "--trades", str(trades_csv), "--candles", str(candles_csv),
         "--out", str(output_dir / "latest"), "--post-exit-bars", bars],
        cwd=str(project_root), stdout=log, stderr=subprocess.STDOUT,
    )
    log.close()
    print(f"[FER3ON][POST_ANALYSIS] started pid={process.pid} output={output_dir}")
    return digest, process


def _active_fingerprint(decision) -> str:
    if decision.idempotency_key:
        return decision.idempotency_key
    raw = f"{decision.strategy_id}|{decision.side}|{decision.stop:.5f}|{decision.target:.5f}"
    return sha256(raw.encode()).hexdigest()[:20]


def run_mt5_once(
    cfg: BotConfig,
    broker: MT5Broker,
    strategy_configs: dict[str, tuple[BotConfig, str]],
    strategy_states: dict[str, StrategyRuntimeState] | None = None,
    logger: LiveTradeLogger | None = None,
    submitted_fingerprints: set[str] | None = None,
):
    """Evaluate each selected strategy once and submit each independent ENTER decision."""
    states = strategy_states if strategy_states is not None else {}
    for name in cfg.active_strategies:
        states.setdefault(name.upper(), StrategyRuntimeState())
    count = max(cfg.lookback + cfg.atr_period + 5, 160)
    candles = broker.candles(cfg.timeframe, count)
    if len(candles) < cfg.lookback:
        raise RuntimeError(f"Only {len(candles)} closed bars available; need at least {cfg.lookback}")
    spread = broker.current_spread() if hasattr(broker, "current_spread") else 0.0
    account = broker.account_state()
    paused = broker.paused_strategies(cfg)
    active = tuple(name for name in cfg.active_strategies if name.upper() not in paused)
    active_cfg = replace(cfg, active_strategies=active)
    decisions = decide_candidates(
        candles, account, active_cfg, spread=spread, strategy_states=states,
        strategy_configs=strategy_configs,
        open_positions_by_strategy=broker.positions_by_strategy(),
    )
    checked_decisions = []
    for decision in decisions:
        profile = strategy_configs.get(decision.strategy_id or "")
        decision_cfg = profile[0] if profile else cfg
        config_payload = asdict(decision_cfg)
        decision.metadata.update({
            "symbol": cfg.symbol,
            "timeframe": cfg.timeframe,
            "account_id": broker.account_id,
            "account_mode": broker.account_mode,
            "margin_mode": broker.margin_mode,
            "market_spread": spread,
            "spread_limit": decision_cfg.spread_limit,
            "strategy_config_sha256": hashlib.sha256(
                json.dumps(config_payload, sort_keys=True, default=str).encode()
            ).hexdigest(),
        })
        if decision.action == "ENTER" and spread > decision_cfg.spread_limit:
            blocked = {
                "side": decision.side.value if decision.side else None,
                "entry": decision.entry, "stop": decision.stop, "target": decision.target,
                "original_reason": decision.reason,
            }
            decision.metadata["spread_blocked_candidate"] = blocked
            decision = replace(
                decision, action="WAIT", side=None, entry=None, stop=None, target=None,
                reason="SPREAD_TOO_WIDE", thesis="Signal blocked by the measured MT5 spread",
                idempotency_key="",
            )
        checked_decisions.append(decision)
    decisions = checked_decisions
    candle_time = candles[-1].time
    fresh_decisions = []
    for decision in decisions:
        state = states[decision.strategy_id]
        if state.last_logged_candle_time == candle_time:
            continue
        state.last_logged_candle_time = candle_time
        fresh_decisions.append(decision)
    results = []
    if logger:
        for decision in fresh_decisions:
            logger.decision(decision)
    for decision in fresh_decisions:
        print(
            f"[FER3ON][{broker.account_mode}][{decision.strategy_id}] "
            f"action={decision.action} reason={decision.reason} side={decision.side} "
            f"entry={decision.entry} stop={decision.stop} target={decision.target} "
            f"spread={decision.metadata.get('market_spread')}"
        )
        if decision.action != "ENTER":
            continue
        fingerprint = _active_fingerprint(decision)
        if submitted_fingerprints is not None and fingerprint in submitted_fingerprints:
            if logger:
                logger.duplicate_skipped(decision, fingerprint)
            print(f"[FER3ON][{decision.strategy_id}] order=DUPLICATE_SKIPPED fingerprint={fingerprint}")
            continue
        try:
            result = broker.send(decision, account, strategy_configs[decision.strategy_id][0], logger=logger)
        except Exception as exc:
            if submitted_fingerprints is not None:
                submitted_fingerprints.add(fingerprint)
            if logger:
                logger.order_rejected(decision, exc)
            print(f"[FER3ON][{decision.strategy_id}] order=REJECTED error={type(exc).__name__}:{exc}")
            continue
        if logger:
            logger.order_result(decision, result)
        if submitted_fingerprints is not None:
            submitted_fingerprints.add(fingerprint)
        results.append((decision, result))
        account.open_trades += 1
    if fresh_decisions:
        broker.manage_positions(candles[-1].close, cfg, logger)
    return decisions, results


def run_mt5_loop(
    strategy_configs: dict[str, tuple[BotConfig, str]],
    mode: str = "AUTO",
    interval_seconds: int = 60,
    once: bool = False,
    journal_path: str | Path | None = None,
    history_db_path: str | Path | None = None,
    history_lookback_days: int = 30,
):
    if interval_seconds < 1:
        raise ValueError("interval_seconds must be at least 1")
    if history_lookback_days < 1:
        raise ValueError("history_lookback_days must be at least 1")
    if not strategy_configs:
        raise ValueError("At least one enabled strategy is required")
    names = tuple(strategy_configs)
    base_cfg = replace(strategy_configs[names[0]][0], active_strategies=names)
    broker = MT5Broker(base_cfg.symbol, mode=mode)
    run_id = new_run_id(broker.account_mode.lower())
    if journal_path is None:
        journal_path = os.getenv("FER3ON_MT5_JOURNAL", "reports/mt5_ledger.jsonl")
    path = Path(journal_path)
    if not path.is_absolute():
        path = Path(__file__).resolve().parents[1] / path
    logger = LiveTradeLogger(
        path, run_id=run_id, data_source=f"mt5_{broker.account_mode.lower()}",
        account_id=broker.account_id, symbol=base_cfg.symbol,
    )
    if history_db_path is None:
        history_db_path = path.parent / "mt5_closed_trades.sqlite3"
    history_path = Path(history_db_path)
    if not history_path.is_absolute():
        history_path = Path(__file__).resolve().parents[1] / history_path
    history_store = ClosedTradeStore(history_path)
    states = {name: StrategyRuntimeState() for name in names}
    fingerprints: set[str] = set()
    post_analysis_digest: str | None = None
    post_analysis_process = None
    if path.exists():
        try:
            for line in path.read_text(encoding="utf-8").splitlines():
                event = json.loads(line)
                if event.get("event") in {"ORDER_RESULT", "ORDER_SUBMITTED"}:
                    key = str(event.get("correlation_id") or "")
                    if key:
                        fingerprints.add(key)
        except (OSError, json.JSONDecodeError):
            raise RuntimeError(f"Existing MT5 ledger is unreadable; refusing possible duplicate orders: {path}")
    print(
        f"[FER3ON] account_mode={broker.account_mode} margin_mode={broker.margin_mode} "
        f"symbol={base_cfg.symbol} strategies={','.join(names)} ledger={path}"
    )
    try:
        while True:
            try:
                sync = sync_mt5_history(broker, history_store, base_cfg.symbol,
                                        initial_lookback_days=history_lookback_days)
                history_store.export_csv(broker.account_id, history_path.with_name("mt5_closed_trades.csv"))
                history_store.export_summary_csv(broker.account_id,
                                                 history_path.with_name("mt5_closed_trade_summary.csv"))
                history_store.export_order_reconciliation(
                    broker.account_id, path, history_path.with_name("mt5_order_reconciliation.csv"))
                if post_analysis_process is None or post_analysis_process.poll() is not None:
                    post_analysis_digest, post_analysis_process = _start_post_analysis(
                        Path(__file__).resolve().parents[1],
                        history_path.with_name("mt5_closed_trades.csv"), base_cfg.timeframe,
                        post_analysis_digest)
                print(f"[FER3ON][HISTORY] synced_deals={sync['bot_deals_upserted']} "
                      f"closed_summary={sync['closed_trade_counts_by_strategy']} database={history_path}")
            except Exception as exc:
                # History capture is observational; a temporary history API failure must not
                # silently change strategy decisions or create duplicate trade orders.
                print(f"[FER3ON][HISTORY][WARN] {type(exc).__name__}: {exc}")
            run_mt5_once(base_cfg, broker, strategy_configs, states, logger, fingerprints)
            if once:
                break
            time.sleep(interval_seconds)
    finally:
        history_store.close()
        shutdown = getattr(broker.mt5, "shutdown", None)
        if shutdown:
            shutdown()
    return {"account_mode": broker.account_mode, "margin_mode": broker.margin_mode,
            "strategies": names, "ledger": str(path), "run_id": run_id,
            "closed_trade_database": str(history_path),
            "closed_trades_csv": str(history_path.with_name("mt5_closed_trades.csv")),
            "summary_csv": str(history_path.with_name("mt5_closed_trade_summary.csv")),
            "order_reconciliation_csv": str(history_path.with_name("mt5_order_reconciliation.csv"))}


def run_mt5_history_sync_once(symbol: str = "XAUUSD", mode: str = "DEMO",
                              history_db_path: str | Path = "reports/mt5_closed_trades.sqlite3",
                              lookback_days: int = 30) -> dict:
    """Read-only history import. This path never evaluates a strategy or sends orders."""
    if mode.upper() != "DEMO":
        raise ValueError("history-only mode is restricted to a verified DEMO account")
    if lookback_days < 1:
        raise ValueError("lookback_days must be at least 1")
    broker = MT5Broker(symbol, mode=mode)
    path = Path(history_db_path)
    if not path.is_absolute():
        path = Path(__file__).resolve().parents[1] / path
    store = ClosedTradeStore(path)
    try:
        result = sync_mt5_history(broker, store, symbol, initial_lookback_days=lookback_days)
        store.export_csv(broker.account_id, path.with_name("mt5_closed_trades.csv"))
        store.export_summary_csv(broker.account_id, path.with_name("mt5_closed_trade_summary.csv"))
        store.export_order_reconciliation(
            broker.account_id, path.parent / "mt5_ledger.jsonl",
            path.with_name("mt5_order_reconciliation.csv"))
        result["closed_trades_csv"] = str(path.with_name("mt5_closed_trades.csv"))
        result["summary_csv"] = str(path.with_name("mt5_closed_trade_summary.csv"))
        result["order_reconciliation_csv"] = str(path.with_name("mt5_order_reconciliation.csv"))
        return result
    finally:
        store.close()
        shutdown = getattr(broker.mt5, "shutdown", None)
        if shutdown:
            shutdown()


def run_mt5_history_watch(symbol: str = "XAUUSD", mode: str = "DEMO",
                          history_db_path: str | Path = "reports/mt5_closed_trades.sqlite3",
                          lookback_days: int = 30, interval_seconds: int = 60,
                          ledger_path: str | Path = "reports/mt5_ledger.jsonl") -> dict:
    """Continuously poll MT5 history without running strategies or placing orders."""
    if mode.upper() != "DEMO":
        raise ValueError("history-only mode is restricted to a verified DEMO account")
    if lookback_days < 1 or interval_seconds < 1:
        raise ValueError("lookback_days and interval_seconds must be at least 1")
    broker = MT5Broker(symbol, mode="DEMO")
    path = Path(history_db_path)
    if not path.is_absolute():
        path = Path(__file__).resolve().parents[1] / path
    ledger = Path(ledger_path)
    if not ledger.is_absolute():
        ledger = Path(__file__).resolve().parents[1] / ledger
    store = ClosedTradeStore(path)
    try:
        while True:
            try:
                result = sync_mt5_history(broker, store, symbol, initial_lookback_days=lookback_days)
                store.export_csv(broker.account_id, path.with_name("mt5_closed_trades.csv"))
                store.export_summary_csv(broker.account_id, path.with_name("mt5_closed_trade_summary.csv"))
                store.export_order_reconciliation(
                    broker.account_id, ledger, path.with_name("mt5_order_reconciliation.csv"))
                print(f"[FER3ON][HISTORY-ONLY] synced_deals={result['bot_deals_upserted']} "
                      f"closed_summary={result['closed_trade_counts_by_strategy']} database={path}")
            except Exception as exc:
                print(f"[FER3ON][HISTORY-ONLY][WARN] {type(exc).__name__}: {exc}")
            time.sleep(interval_seconds)
    except KeyboardInterrupt:
        pass
    finally:
        store.close()
        shutdown = getattr(broker.mt5, "shutdown", None)
        if shutdown:
            shutdown()
    return {"account_mode": broker.account_mode,
            "closed_trade_database": str(path),
            "closed_trades_csv": str(path.with_name("mt5_closed_trades.csv")),
            "summary_csv": str(path.with_name("mt5_closed_trade_summary.csv")),
            "order_reconciliation_csv": str(path.with_name("mt5_order_reconciliation.csv"))}


# Backwards-compatible names for scripts that imported the previous Demo runner.
run_demo_once = run_mt5_once
run_demo_loop = run_mt5_loop
