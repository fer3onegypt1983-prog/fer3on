from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from .domain import Candle

class PivotKind(str, Enum):
    HIGH='HIGH'
    LOW='LOW'

class Label(str, Enum):
    HH='HH'; HL='HL'; LH='LH'; LL='LL'

@dataclass(frozen=True)
class SwingPoint:
    index: int
    time: object
    price: float
    kind: PivotKind
    label: Label | None
    strength: float
    confirmed: bool = True

@dataclass(frozen=True)
class StructureSnapshot:
    points: tuple[SwingPoint, ...]
    bias: str
    protected_high: SwingPoint | None
    protected_low: SwingPoint | None
    last_high: SwingPoint | None
    last_low: SwingPoint | None
    quality: float

def _pivot(candles: list[Candle], i: int, left: int, right: int, kind: PivotKind) -> bool:
    p=candles[i].high if kind is PivotKind.HIGH else candles[i].low
    before=candles[i-left:i]; after=candles[i+1:i+right+1]
    vals=[x.high if kind is PivotKind.HIGH else x.low for x in before+after]
    return bool(vals) and (p > max(vals) if kind is PivotKind.HIGH else p < min(vals))

def detect_swings(candles: list[Candle], left: int=2, right: int=2, min_separation: int=1) -> list[SwingPoint]:
    if len(candles) < left+right+3: return []
    raw=[]
    # Only indices with a completed right-side confirmation are returned.
    for i in range(left, len(candles)-right):
        if _pivot(candles,i,left,right,PivotKind.HIGH):
            raw.append(SwingPoint(i,candles[i].time,candles[i].high,PivotKind.HIGH,None,0.0))
        if _pivot(candles,i,left,right,PivotKind.LOW):
            raw.append(SwingPoint(i,candles[i].time,candles[i].low,PivotKind.LOW,None,0.0))
    raw.sort(key=lambda x:x.index)
    filtered=[]
    for point in raw:
        if filtered and point.index-filtered[-1].index < min_separation and point.kind is filtered[-1].kind:
            better=(point.price>filtered[-1].price) if point.kind is PivotKind.HIGH else (point.price<filtered[-1].price)
            if better: filtered[-1]=point
        else: filtered.append(point)
    return _label_points(filtered,candles)

def _label_points(points: list[SwingPoint], candles: list[Candle]) -> list[SwingPoint]:
    last={PivotKind.HIGH:None, PivotKind.LOW:None}; out=[]
    for p in points:
        prev=last[p.kind]
        label=None
        if prev is not None:
            if p.kind is PivotKind.HIGH: label=Label.HH if p.price>prev.price else Label.LH
            else: label=Label.HL if p.price>prev.price else Label.LL
        # Strength is normalized by the local candle range; it is diagnostic, not a gate alone.
        c=candles[p.index]; span=max(c.high-c.low,1e-9)
        strength=min(1.0, abs(p.price-c.close)/span + 0.25)
        out.append(SwingPoint(p.index,p.time,p.price,p.kind,label,strength,p.confirmed))
        last[p.kind]=out[-1]
    return out

def analyze_structure(candles: list[Candle], left: int=2, right: int=2) -> StructureSnapshot:
    points=detect_swings(candles,left,right)
    highs=[p for p in points if p.kind is PivotKind.HIGH]
    lows=[p for p in points if p.kind is PivotKind.LOW]
    hh=sum(p.label is Label.HH for p in highs); lh=sum(p.label is Label.LH for p in highs)
    hl=sum(p.label is Label.HL for p in lows); ll=sum(p.label is Label.LL for p in lows)
    if hh+hl >= 2 and hh+hl > lh+ll: bias='UP'
    elif lh+ll >= 2 and lh+ll > hh+hl: bias='DOWN'
    else: bias='RANGE'
    protected_low=next((p for p in reversed(lows) if p.label is Label.HL), None) or (lows[-1] if lows else None)
    protected_high=next((p for p in reversed(highs) if p.label is Label.LH), None) or (highs[-1] if highs else None)
    quality=min(1.0, (len(points)/8.0) * (1.0 if bias!='RANGE' else .7))
    return StructureSnapshot(tuple(points),bias,protected_high,protected_low,highs[-1] if highs else None,lows[-1] if lows else None,quality)
