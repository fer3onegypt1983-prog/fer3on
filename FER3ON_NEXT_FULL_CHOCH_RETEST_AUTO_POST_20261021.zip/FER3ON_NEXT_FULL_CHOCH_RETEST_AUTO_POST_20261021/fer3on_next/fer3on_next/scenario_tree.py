from __future__ import annotations

"""Planning-only scenario tree for independent Shadow/Paper evaluation.

This module creates a versioned map and conditional branches before price
reaches a level. It never connects to MT5, creates orders, or changes another
strategy's decisions. All numeric defaults are research hypotheses, not tuned
trading thresholds.
"""

from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import math
from typing import Iterable, Literal

from .calendar_levels import build_reference_levels
from .domain import Candle, Side
from .levels import build_zones
from .market import atr
from .structure import analyze_structure

LevelKind = Literal["SUPPORT", "RESISTANCE"]
BranchKind = Literal["BOUNCE", "BREAK_RETEST"]
BranchState = Literal[
    "PLANNED", "TOUCHED", "WAIT_RETEST", "CONFIRMED", "INVALIDATED", "EXPIRED", "NO_TRADE"
]


@dataclass(frozen=True)
class ScenarioTreeConfig:
    """Frozen plan-time values; defaults are initial test hypotheses only."""

    atr_period: int = 14
    swing_left: int = 2
    swing_right: int = 2
    max_levels_each_side: int = 3
    merge_distance_atr: float = 0.35
    reference_half_width_atr: float = 0.08
    approach_distance_atr: float = 0.60
    touch_tolerance_atr: float = 0.10
    break_buffer_atr: float = 0.05
    break_min_body_atr: float = 0.50
    bounce_confirmation_atr: float = 0.30
    stop_buffer_atr: float = 0.15
    min_reward_risk: float = 1.35
    fallback_target_rr: float = 1.50
    max_retest_bars: int = 8
    max_plan_age_bars: int = 64
    probability_window_days: int = 90
    minimum_probability_samples: int = 30

    def validate(self) -> None:
        if self.atr_period < 2:
            raise ValueError("atr_period must be >= 2")
        if self.swing_left < 1 or self.swing_right < 1:
            raise ValueError("swing_left and swing_right must be >= 1")
        if self.max_levels_each_side < 1:
            raise ValueError("max_levels_each_side must be >= 1")
        for name in (
            "merge_distance_atr", "reference_half_width_atr", "approach_distance_atr",
            "touch_tolerance_atr", "break_buffer_atr", "break_min_body_atr", "bounce_confirmation_atr",
            "stop_buffer_atr",
        ):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be non-negative")
        if self.min_reward_risk <= 0 or self.fallback_target_rr <= 0:
            raise ValueError("reward-risk thresholds must be > 0")
        if self.max_retest_bars < 1 or self.max_plan_age_bars < 1:
            raise ValueError("plan and retest expiry must be positive")
        if self.probability_window_days < 1 or self.minimum_probability_samples < 1:
            raise ValueError("probability window and sample threshold must be positive")


@dataclass(frozen=True)
class LevelZone:
    level_id: str
    kind: LevelKind
    low: float
    high: float
    sources: tuple[str, ...]
    strength: float
    observed_at: datetime

    @property
    def midpoint(self) -> float:
        return (self.low + self.high) / 2.0


@dataclass(frozen=True)
class OutcomeObservation:
    """Resolved, deduplicated outcome label used for display-only calibration."""

    observation_id: str
    resolved_at: datetime
    branch_kind: BranchKind
    level_kind: LevelKind
    target_before_stop: bool
    source_group: str


@dataclass(frozen=True)
class ProbabilityEstimate:
    status: Literal["INSUFFICIENT_DATA", "ESTIMATED"]
    estimate: float | None
    lower_95: float | None
    upper_95: float | None
    sample_count: int
    successes: int
    window_start: datetime
    as_of: datetime
    calibration_id: str
    source_group: str
    is_execution_gate: bool = False


@dataclass(frozen=True)
class ScenarioBranch:
    branch_id: str
    level_id: str
    level_kind: LevelKind
    branch_kind: BranchKind
    side: Side
    trigger: str
    confirmation: str
    order_policy: str
    entry_low: float
    entry_high: float
    stop_price: float
    target_level_id: str | None
    target_price: float | None
    planned_reward_risk: float | None
    eligible_after_trigger: bool
    block_reason: str | None
    invalidation: str
    expiry_bars: int
    calibration_group: str
    probability: ProbabilityEstimate
    state: BranchState = "PLANNED"
    state_reason: str = "WAITING_FOR_TRIGGER"
    bars_in_state: int = 0
    target_policy: str = "NEXT_CONFIRMED_LEVEL"


@dataclass(frozen=True)
class ScenarioTree:
    strategy_id: str
    strategy_version: str
    symbol: str
    as_of: datetime
    current_price: float
    atr_value: float
    levels: tuple[LevelZone, ...]
    branches: tuple[ScenarioBranch, ...]
    config: ScenarioTreeConfig
    config_sha256: str
    map_snapshot_id: str
    data_sha256: str = ""
    age_bars: int = 0
    current_context: str = "NO_TRADE_MID_RANGE"
    context_reason: str = "NO_VALID_LEVELS"
    last_closed_time: datetime | None = None


@dataclass(frozen=True)
class _CandidateLevel:
    kind: LevelKind
    low: float
    high: float
    source: str
    strength: float
    observed_at: datetime


def _aware_utc(value: datetime, field_name: str) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(f"{field_name} must be timezone-aware")
    return value.astimezone(timezone.utc)


def _config_digest(config: ScenarioTreeConfig) -> str:
    raw = "|".join(f"{name}={getattr(config, name)}" for name in config.__dataclass_fields__)
    return sha256(raw.encode("utf-8")).hexdigest()


def _ohlcv_digest(candles: Iterable[Candle]) -> str:
    digest = sha256()
    for candle in candles:
        row = (
            f"{candle.time.isoformat()}|{candle.open:.12g}|{candle.high:.12g}|"
            f"{candle.low:.12g}|{candle.close:.12g}|{candle.volume:.12g}\n"
        )
        digest.update(row.encode("utf-8"))
    return digest.hexdigest()


def _map_snapshot_id(
    symbol: str, as_of: datetime, config_hash: str, data_hash: str,
    strategy_version: str, levels: Iterable[LevelZone]
) -> str:
    parts = [symbol, as_of.isoformat(), config_hash, data_hash, strategy_version]
    parts.extend(f"{x.level_id}:{x.low:.8f}:{x.high:.8f}:{','.join(x.sources)}" for x in levels)
    return sha256("|".join(parts).encode("utf-8")).hexdigest()[:24]


def _wilson(successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
    if total <= 0:
        return (0.0, 1.0)
    p = successes / total
    z2 = z * z
    denom = 1.0 + z2 / total
    center = (p + z2 / (2.0 * total)) / denom
    margin = z * math.sqrt((p * (1.0 - p) / total) + (z2 / (4.0 * total * total))) / denom
    return max(0.0, center - margin), min(1.0, center + margin)


def estimate_probability(
    observations: Iterable[OutcomeObservation],
    branch_kind: BranchKind,
    level_kind: LevelKind,
    source_group: str,
    as_of: datetime,
    config: ScenarioTreeConfig,
) -> ProbabilityEstimate:
    """Estimate target-before-stop frequency from prior 90d labels only.

    The returned value is advisory/display-only; is_execution_gate is always
    false. A Jeffreys-smoothed point estimate and Wilson interval avoid treating
    a small raw hit rate as certain.
    """
    as_of = _aware_utc(as_of, "as_of")
    start = as_of - timedelta(days=config.probability_window_days)
    unique: dict[str, OutcomeObservation] = {}
    for obs in observations:
        resolved = _aware_utc(obs.resolved_at, "observation.resolved_at")
        if (
            obs.branch_kind == branch_kind
            and obs.level_kind == level_kind
            and obs.source_group == source_group
            and start <= resolved <= as_of
        ):
            unique.setdefault(obs.observation_id, obs)
    rows = list(unique.values())
    wins = sum(1 for row in rows if row.target_before_stop)
    calibration_payload = (
        f"{branch_kind}|{level_kind}|{source_group}|{start.isoformat()}|{as_of.isoformat()}|"
        + "|".join(sorted(unique))
    ).encode("utf-8")
    calibration_id = sha256(calibration_payload).hexdigest()[:20]
    if len(rows) < config.minimum_probability_samples:
        return ProbabilityEstimate(
            "INSUFFICIENT_DATA", None, None, None, len(rows), wins,
            start, as_of, calibration_id, source_group, False,
        )
    lower, upper = _wilson(wins, len(rows))
    # Jeffreys Beta(0.5, 0.5) posterior mean; the interval remains a Wilson
    # interval for broad standard-library compatibility.
    estimate = (wins + 0.5) / (len(rows) + 1.0)
    return ProbabilityEstimate(
        "ESTIMATED", estimate, lower, upper, len(rows), wins,
        start, as_of, calibration_id, source_group, False,
    )


def _candidate_levels(candles: list[Candle], atr_value: float, config: ScenarioTreeConfig) -> list[_CandidateLevel]:
    current = candles[-1].close
    now = _aware_utc(candles[-1].time, "candle.time")
    structure = analyze_structure(candles, config.swing_left, config.swing_right)
    zones = build_zones(structure, atr_value, merge_atr=config.merge_distance_atr)
    candidates: list[_CandidateLevel] = [
        _CandidateLevel(
            kind=zone.kind, low=zone.low, high=zone.high,
            source=f"CONFIRMED_SWING:{zone.source}", strength=zone.strength, observed_at=now,
        )
        for zone in zones
    ]
    width = max(atr_value * config.reference_half_width_atr, 1e-8)
    for reference in build_reference_levels(candles):
        # The existing intraday session labels use fixed UTC hours without a
        # broker/DST profile; only completed prior-day/week levels are trusted.
        if reference.kind not in {"SUPPORT", "RESISTANCE"} or not reference.name.startswith(("PREVIOUS_DAY_", "PREVIOUS_WEEK_")):
            continue
        candidates.append(_CandidateLevel(
            kind=reference.kind,
            low=reference.price - width,
            high=reference.price + width,
            source=f"CALENDAR:{reference.name}:{reference.period}",
            strength=0.55,
            observed_at=now,
        ))
    return candidates


def _merge_levels(candidates: list[_CandidateLevel], atr_value: float, config: ScenarioTreeConfig) -> tuple[LevelZone, ...]:
    threshold = max(atr_value * config.merge_distance_atr, 1e-8)
    output: list[LevelZone] = []
    for kind in ("SUPPORT", "RESISTANCE"):
        group = sorted((x for x in candidates if x.kind == kind), key=lambda x: (x.low, x.high, x.source))
        clusters: list[list[_CandidateLevel]] = []
        for item in group:
            if clusters and item.low <= max(x.high for x in clusters[-1]) + threshold:
                clusters[-1].append(item)
            else:
                clusters.append([item])
        for cluster in clusters:
            low = min(x.low for x in cluster)
            high = max(x.high for x in cluster)
            sources = tuple(sorted({x.source for x in cluster}))
            strength = min(1.0, sum(x.strength for x in cluster) / len(cluster) + min(0.15, 0.03 * (len(sources) - 1)))
            observed_at = min(x.observed_at for x in cluster)
            identity = f"{kind}|{low:.8f}|{high:.8f}|{'|'.join(sources)}"
            level_id = sha256(identity.encode("utf-8")).hexdigest()[:16]
            output.append(LevelZone(level_id, kind, low, high, sources, strength, observed_at))
    return tuple(sorted(output, key=lambda x: (x.midpoint, x.kind, x.level_id)))


def _eligible(side: Side, entry_low: float, entry_high: float, stop: float, target: float | None, minimum_rr: float) -> tuple[bool, float | None, str | None]:
    if target is None:
        return False, None, "NO_NEXT_TARGET_LEVEL"
    if side is Side.BUY:
        risk = entry_high - stop
        reward = target - entry_high
    else:
        risk = stop - entry_low
        reward = entry_low - target
    if risk <= 0 or reward <= 0:
        return False, None, "INVALID_ENTRY_STOP_TARGET_GEOMETRY"
    rr = reward / risk
    if rr < minimum_rr:
        return False, rr, "TARGET_R_BELOW_MINIMUM"
    return True, rr, None


def _target_for(level: LevelZone, levels: tuple[LevelZone, ...], side: Side) -> LevelZone | None:
    if side is Side.BUY:
        targets = [x for x in levels if x.kind == "RESISTANCE" and x.low > level.high]
        return min(targets, key=lambda x: x.low) if targets else None
    targets = [x for x in levels if x.kind == "SUPPORT" and x.high < level.low]
    return max(targets, key=lambda x: x.high) if targets else None


def _source_group(level: LevelZone) -> str:
    return "+".join(sorted({source.split(":", 1)[0] for source in level.sources}))


def _make_branch(
    level: LevelZone,
    branch_kind: BranchKind,
    levels: tuple[LevelZone, ...],
    atr_value: float,
    config: ScenarioTreeConfig,
    probability: ProbabilityEstimate,
) -> ScenarioBranch:
    calibration_group = _source_group(level)
    if branch_kind == "BOUNCE":
        side = Side.BUY if level.kind == "SUPPORT" else Side.SELL
        order_policy = "WAIT_FOR_CLOSED_BAR_CONFIRMATION_THEN_LIMIT_OR_RETEST"
        trigger = (
            "Support touched, then a closed bullish rejection candle reclaims above the support zone"
            if side is Side.BUY else
            "Resistance touched, then a closed bearish rejection candle reclaims below the resistance zone"
        )
        confirmation = f"Closed-candle rejection and displacement >= {config.bounce_confirmation_atr:.3f} x plan ATR"
        invalidation = "Closed candle beyond the far edge of the level by the frozen break buffer"
        stop = level.low - config.stop_buffer_atr * atr_value if side is Side.BUY else level.high + config.stop_buffer_atr * atr_value
    else:
        side = Side.SELL if level.kind == "SUPPORT" else Side.BUY
        order_policy = "WAIT_FOR_CLOSED_BREAK_THEN_RETEST; NEVER_CHASE"
        trigger = (
            f"Closed candle body >= {config.break_min_body_atr:.3f} x plan ATR below support by the frozen break buffer, then retest from underneath"
            if side is Side.SELL else
            f"Closed candle body >= {config.break_min_body_atr:.3f} x plan ATR above resistance by the frozen break buffer, then retest from above"
        )
        confirmation = "Break close first; on a later closed candle the level is retested and reclaimed in breakout direction"
        invalidation = "Close through the opposite side of the broken zone or expire before a qualifying retest"
        stop = level.high + config.stop_buffer_atr * atr_value if side is Side.SELL else level.low - config.stop_buffer_atr * atr_value

    target_level = _target_for(level, levels, side)
    target = None
    target_policy = "NEXT_CONFIRMED_LEVEL"
    if target_level is not None:
        target = target_level.low if side is Side.BUY else target_level.high
    else:
        risk = (level.high - stop) if side is Side.BUY else (stop - level.low)
        if risk > 0:
            target = level.high + config.fallback_target_rr * risk if side is Side.BUY else level.low - config.fallback_target_rr * risk
            target_policy = "RR_FALLBACK_NO_NEXT_LEVEL"
    eligible, rr, block = _eligible(
        side, level.low, level.high, stop, target, config.min_reward_risk
    )
    branch_id = sha256(f"{level.level_id}|{branch_kind}|{side.value}".encode("utf-8")).hexdigest()[:20]
    return ScenarioBranch(
        branch_id=branch_id,
        level_id=level.level_id,
        level_kind=level.kind,
        branch_kind=branch_kind,
        side=side,
        trigger=trigger,
        confirmation=confirmation,
        order_policy=order_policy,
        entry_low=level.low,
        entry_high=level.high,
        stop_price=stop,
        target_level_id=target_level.level_id if target_level else None,
        target_price=target,
        planned_reward_risk=rr,
        eligible_after_trigger=eligible,
        block_reason=block,
        invalidation=invalidation,
        expiry_bars=config.max_retest_bars if branch_kind == "BREAK_RETEST" else config.max_plan_age_bars,
        calibration_group=calibration_group,
        probability=probability,
        target_policy=target_policy,
    )


def _context(price: float, levels: tuple[LevelZone, ...], atr_value: float, config: ScenarioTreeConfig) -> tuple[str, str]:
    if not levels:
        return "NO_TRADE_MID_RANGE", "NO_VALID_LEVELS"
    nearest = min(levels, key=lambda item: max(item.low - price, price - item.high, 0.0))
    distance = 0.0 if nearest.low <= price <= nearest.high else min(abs(price - nearest.low), abs(price - nearest.high))
    if distance > config.approach_distance_atr * atr_value:
        return "NO_TRADE_MID_RANGE", "PRICE_BETWEEN_LEVELS"
    if nearest.low <= price <= nearest.high:
        return "LEVEL_TOUCHED_WAITING_FOR_REJECTION", "LEVEL_TOUCHED_BEFORE_CURRENT_BAR_WAITING_FOR_CONFIRMATION"
    return "LEVEL_APPROACHING", f"APPROACHING_{nearest.kind}"


def build_scenario_tree(
    candles: list[Candle],
    symbol: str,
    config: ScenarioTreeConfig | None = None,
    observations: Iterable[OutcomeObservation] = (),
    strategy_version: str = "scenario-tree-prototype-0.1",
) -> ScenarioTree:
    """Build and freeze a plan from information available through the last bar only."""
    config = config or ScenarioTreeConfig()
    config.validate()
    minimum_bars = max(config.atr_period, config.swing_left + config.swing_right + 3)
    if len(candles) < minimum_bars:
        raise ValueError(f"Need at least {minimum_bars} completed candles")
    if not symbol.strip():
        raise ValueError("symbol must be non-empty")
    candles = [replace(candle, time=_aware_utc(candle.time, "candle.time")) for candle in candles]
    if any(candles[i].time >= candles[i + 1].time for i in range(len(candles) - 1)):
        raise ValueError("candles must have strictly increasing timestamps")
    as_of = _aware_utc(candles[-1].time, "as_of")
    atr_value = atr(candles, config.atr_period)
    if atr_value <= 0:
        raise ValueError("ATR must be positive to plan level buffers")

    candidates = _candidate_levels(candles, atr_value, config)
    all_levels = _merge_levels(candidates, atr_value, config)
    price = candles[-1].close
    supports = sorted((x for x in all_levels if x.kind == "SUPPORT" and x.high < price), key=lambda x: price - x.high)[:config.max_levels_each_side]
    resistances = sorted((x for x in all_levels if x.kind == "RESISTANCE" and x.low > price), key=lambda x: x.low - price)[:config.max_levels_each_side]
    inside = [x for x in all_levels if x.low <= price <= x.high]
    chosen_ids = {x.level_id for x in supports + resistances + inside}
    levels = tuple(x for x in all_levels if x.level_id in chosen_ids)

    calibration_rows = tuple(observations)
    branches: list[ScenarioBranch] = []
    for level in levels:
        for branch_kind in ("BOUNCE", "BREAK_RETEST"):
            probability = estimate_probability(
                calibration_rows, branch_kind, level.kind, _source_group(level), as_of, config
            )
            branch = _make_branch(level, branch_kind, levels, atr_value, config, probability)
            if level.low <= price <= level.high and branch_kind == "BOUNCE":
                # This map uses only bars closed before the evaluation candle;
                # the prior touch can seed a branch but cannot itself trigger entry.
                branch = replace(
                    branch, state="TOUCHED",
                    state_reason="PRIOR_CLOSED_BAR_TOUCHED_WAITING_FOR_REJECTION",
                    bars_in_state=0,
                )
            elif level.low <= price <= level.high:
                branch = replace(branch, state="NO_TRADE", state_reason="BREAK_PLAN_CREATED_AFTER_LEVEL_TOUCH")
            branches.append(branch)

    config_hash = _config_digest(config)
    data_hash = _ohlcv_digest(candles)
    snapshot_id = _map_snapshot_id(symbol.strip().upper(), as_of, config_hash, data_hash, strategy_version, levels)
    context, reason = _context(price, levels, atr_value, config)
    return ScenarioTree(
        strategy_id="LEVEL_MAP_SCENARIO_TREE",
        strategy_version=strategy_version,
        symbol=symbol.strip().upper(),
        as_of=as_of,
        current_price=price,
        atr_value=atr_value,
        levels=levels,
        branches=tuple(branches),
        config=config,
        config_sha256=config_hash,
        map_snapshot_id=snapshot_id,
        data_sha256=data_hash,
        current_context=context,
        context_reason=reason,
        last_closed_time=as_of,
    )


def _touches(candle: Candle, level: LevelZone, tolerance: float) -> bool:
    return candle.low <= level.high + tolerance and candle.high >= level.low - tolerance


def _level_for(tree: ScenarioTree, level_id: str) -> LevelZone:
    return next(level for level in tree.levels if level.level_id == level_id)


def _advance_branch(
    branch: ScenarioBranch,
    candle: Candle,
    level: LevelZone,
    tree: ScenarioTree,
) -> ScenarioBranch:
    if branch.state in {"CONFIRMED", "INVALIDATED", "EXPIRED", "NO_TRADE"}:
        return branch

    next_age = branch.bars_in_state + 1
    buffer = tree.config.break_buffer_atr * tree.atr_value
    touch_tolerance = tree.config.touch_tolerance_atr * tree.atr_value
    next_state: BranchState = branch.state
    reason = branch.state_reason

    if branch.branch_kind == "BOUNCE":
        if branch.level_kind == "SUPPORT":
            broken = candle.close < level.low - buffer
            confirmed = (
                (_touches(candle, level, touch_tolerance) or branch.state == "TOUCHED")
                and candle.close > level.high
                and candle.close > candle.open
                and candle.close - candle.low >= tree.config.bounce_confirmation_atr * tree.atr_value
            )
        else:
            broken = candle.close > level.high + buffer
            confirmed = (
                (_touches(candle, level, touch_tolerance) or branch.state == "TOUCHED")
                and candle.close < level.low
                and candle.close < candle.open
                and candle.high - candle.close >= tree.config.bounce_confirmation_atr * tree.atr_value
            )
        if broken:
            next_state, reason = "INVALIDATED", "LEVEL_BROKEN_BEFORE_BOUNCE_CONFIRMATION"
        elif confirmed:
            if branch.eligible_after_trigger:
                next_state, reason = "CONFIRMED", "CLOSED_BAR_BOUNCE_CONFIRMED"
            else:
                next_state, reason = "NO_TRADE", branch.block_reason or "BRANCH_FAILED_REWARD_RISK_GUARD"
        elif _touches(candle, level, touch_tolerance):
            next_state, reason = "TOUCHED", "LEVEL_TOUCHED_WAITING_FOR_REJECTION"
        elif branch.state == "TOUCHED" and next_age >= tree.config.max_retest_bars:
            next_state, reason = "EXPIRED", "NO_BOUNCE_CONFIRMATION_AFTER_TOUCH"
        elif branch.state != "TOUCHED" and tree.age_bars + 1 >= tree.config.max_plan_age_bars:
            next_state, reason = "EXPIRED", "PLAN_MAX_AGE_REACHED"
    else:
        if branch.state == "PLANNED":
            broke = (
                candle.close < level.low - buffer
                and candle.close < candle.open
                and abs(candle.close - candle.open) >= tree.config.break_min_body_atr * tree.atr_value
                if branch.side is Side.SELL else
                candle.close > level.high + buffer
                and candle.close > candle.open
                and abs(candle.close - candle.open) >= tree.config.break_min_body_atr * tree.atr_value
            )
            if broke:
                next_state, reason, next_age = "WAIT_RETEST", "CLOSED_BREAK_CONFIRMED_WAIT_FOR_RETEST", 0
            elif tree.age_bars + 1 >= tree.config.max_plan_age_bars:
                next_state, reason = "EXPIRED", "NO_CLOSED_BREAK_BEFORE_EXPIRY"
        elif branch.state == "WAIT_RETEST":
            crossed_back = (
                candle.close > level.high + buffer if branch.side is Side.SELL
                else candle.close < level.low - buffer
            )
            if crossed_back:
                next_state, reason = "INVALIDATED", "BREAK_FAILED_CLOSED_BACK_THROUGH_ZONE"
            elif branch.side is Side.SELL:
                if candle.high >= level.low - touch_tolerance and candle.close < level.low and candle.close < candle.open:
                    if branch.eligible_after_trigger:
                        next_state, reason = "CONFIRMED", "CLOSED_RETEST_REJECTED_FROM_BELOW"
                    else:
                        next_state, reason = "NO_TRADE", branch.block_reason or "BRANCH_FAILED_REWARD_RISK_GUARD"
                elif next_age >= tree.config.max_retest_bars:
                    next_state, reason = "EXPIRED", "NO_QUALIFYING_RETEST"
            else:
                if candle.low <= level.high + touch_tolerance and candle.close > level.high and candle.close > candle.open:
                    if branch.eligible_after_trigger:
                        next_state, reason = "CONFIRMED", "CLOSED_RETEST_RECLAIMED_FROM_ABOVE"
                    else:
                        next_state, reason = "NO_TRADE", branch.block_reason or "BRANCH_FAILED_REWARD_RISK_GUARD"
                elif next_age >= tree.config.max_retest_bars:
                    next_state, reason = "EXPIRED", "NO_QUALIFYING_RETEST"
    return replace(branch, state=next_state, state_reason=reason, bars_in_state=next_age)


def advance_scenario_tree(tree: ScenarioTree, candle: Candle) -> ScenarioTree:
    """Advance the frozen plan by exactly one later, closed candle; never place an order."""
    candle_time = _aware_utc(candle.time, "candle.time")
    if tree.last_closed_time is None or candle_time <= tree.last_closed_time:
        raise ValueError("new candle time must be later than the last processed closed candle")
    branches = list(
        _advance_branch(branch, candle, _level_for(tree, branch.level_id), tree)
        for branch in tree.branches
    )
    confirmed = [i for i, branch in enumerate(branches) if branch.state == "CONFIRMED"]
    if len(confirmed) > 1:
        for i, branch in enumerate(branches):
            if branch.state not in {"EXPIRED", "INVALIDATED", "NO_TRADE"}:
                branches[i] = replace(branch, state="NO_TRADE", state_reason="MULTIPLE_BRANCHES_CONFIRMED_ON_SAME_CANDLE")
    elif len(confirmed) == 1:
        for i, branch in enumerate(branches):
            if i != confirmed[0] and branch.state in {"PLANNED", "TOUCHED", "WAIT_RETEST"}:
                branches[i] = replace(branch, state="INVALIDATED", state_reason="TREE_BRANCH_ALREADY_CONFIRMED")
    age = tree.age_bars + 1
    context, reason = _context(candle.close, tree.levels, tree.atr_value, tree.config)
    return replace(
        tree,
        current_price=candle.close,
        branches=tuple(branches),
        age_bars=age,
        current_context=context,
        context_reason=reason,
        last_closed_time=candle_time,
    )
