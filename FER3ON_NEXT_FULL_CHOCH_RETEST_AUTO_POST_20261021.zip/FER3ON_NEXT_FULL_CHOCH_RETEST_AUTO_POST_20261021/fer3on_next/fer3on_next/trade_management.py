from __future__ import annotations
from dataclasses import dataclass
from .domain import Side

@dataclass(frozen=True)
class ProfitPlan:
    entry: float
    stop: float
    tp1: float
    tp2: float
    final_target: float
    breakeven_trigger: float
    partial_fraction: float

def build_profit_plan(side: Side, entry: float, stop: float, target: float) -> ProfitPlan:
    risk=abs(entry-stop); direction=1 if side is Side.BUY else -1
    tp1=entry+direction*risk*1.0; tp2=entry+direction*risk*1.5
    return ProfitPlan(entry,stop,tp1,tp2,target,tp1,.50)

def management_action(side: Side, current: float, plan: ProfitPlan) -> str:
    if side is Side.BUY:
        if current>=plan.final_target: return 'CLOSE_FULL_TARGET'
        if current>=plan.tp2: return 'TAKE_PARTIAL_2_AND_TRAIL'
        if current>=plan.tp1: return 'TAKE_PARTIAL_1_MOVE_BE'
    else:
        if current<=plan.final_target: return 'CLOSE_FULL_TARGET'
        if current<=plan.tp2: return 'TAKE_PARTIAL_2_AND_TRAIL'
        if current<=plan.tp1: return 'TAKE_PARTIAL_1_MOVE_BE'
    return 'HOLD'
