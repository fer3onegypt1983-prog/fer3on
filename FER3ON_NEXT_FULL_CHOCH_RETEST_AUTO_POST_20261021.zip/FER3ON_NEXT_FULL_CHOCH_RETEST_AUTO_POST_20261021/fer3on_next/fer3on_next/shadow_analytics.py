from __future__ import annotations
from collections import defaultdict

def summarize(records: list[dict], min_samples: int=50, min_delta: float=.15) -> dict:
    groups=defaultdict(lambda:[0,0,0.0])
    for r in records:
        key=str(r.get('quality_bucket','UNKNOWN')); groups[key][0]+=1; groups[key][1]+=int(bool(r.get('won'))); groups[key][2]+=float(r.get('pnl') or 0)
    table={k:{'n':v[0],'win_rate':v[1]/v[0] if v[0] else 0,'pnl':v[2]} for k,v in groups.items()}
    rates=[x['win_rate'] for x in table.values() if x['n']>=5]
    delta=max(rates)-min(rates) if rates else 0
    ready=len(records)>=min_samples and delta>=min_delta
    return {'records':len(records),'groups':table,'discrimination_delta':delta,'evidence_ready':ready,'reason':'PASS' if ready else f'NEED_MORE_EVIDENCE:n={len(records)},delta={delta:.3f}'}
