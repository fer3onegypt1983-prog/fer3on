from __future__ import annotations
from collections import defaultdict

def _bucket(rows, key):
    out=defaultdict(lambda:{'total':0,'resolved':0,'wins':0,'losses':0,'not_filled':0,'pnl':0.0})
    for row in rows:
        value=key(row) or 'UNKNOWN'; x=out[str(value)]; x['total']+=1; status=row.get('status')
        if status=='WIN': x['wins']+=1; x['resolved']+=1
        elif status=='LOSS': x['losses']+=1; x['resolved']+=1
        elif status=='NOT_FILLED': x['not_filled']+=1
        if isinstance(row.get('pnl'),(int,float)): x['pnl']+=float(row['pnl'])
    for x in out.values(): x['win_rate']=x['wins']/x['resolved'] if x['resolved'] else None
    return dict(out)

def _scenario(row):
    s=row.get('scenarios') or (row.get('metadata') or {}).get('scenarios') or {}
    return s.get('selected') if isinstance(s,dict) else None

def _contradiction_bucket(row):
    s=row.get('scenarios') or (row.get('metadata') or {}).get('scenarios') or {}
    try: score=float(s.get('contradiction_score',0))
    except (TypeError,ValueError): score=0
    return 'LOW_0_25' if score<=25 else 'MEDIUM_25_50' if score<=50 else 'HIGH_50_75' if score<=75 else 'EXTREME_75_100'

def analyze_opportunities(opportunities: list[dict]) -> dict:
    return {
        'total_opportunities':len(opportunities),
        'status_counts':_bucket(opportunities,lambda r:r.get('status')),
        'by_build_id':_bucket(opportunities,lambda r:r.get('build_id')),
        'by_data_source':_bucket(opportunities,lambda r:r.get('data_source')),
        'by_reason':_bucket(opportunities,lambda r:r.get('reason')),
        'by_event':_bucket(opportunities,lambda r:r.get('forecast',{}).get('event') if isinstance(r.get('forecast'),dict) else (r.get('metadata') or {}).get('forecast',{}).get('event')),
        'by_scenario':_bucket(opportunities,_scenario),
        'by_contradiction':_bucket(opportunities,_contradiction_bucket),
        'by_reaction':_bucket(opportunities,lambda r:r.get('reaction')),
        'by_state':_bucket(opportunities,lambda r:r.get('state')),
        'by_location':_bucket(opportunities,lambda r:r.get('location')),
        'by_trend':_bucket(opportunities,lambda r:(r.get('metadata') or {}).get('trend')),
        'by_entry_quality':_bucket(opportunities,lambda r:r.get('entry_quality',{}).get('reason') if isinstance(r.get('entry_quality'),dict) else (r.get('metadata') or {}).get('entry_quality',{}).get('reason')),
        'by_execution_quality':_bucket(opportunities,lambda r:r.get('execution_quality',{}).get('grade') if isinstance(r.get('execution_quality'),dict) else (r.get('metadata') or {}).get('execution_quality',{}).get('grade')),
    }
