from __future__ import annotations
import csv
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import replace
from .domain import AccountState, BotConfig, Candle, Decision
from .execution import PaperBroker
from .strategy import decide_candidates
from .experimental_strategies import StrategyRuntimeState
from .journal import Journal
from .identity import BUILD_ID, SCHEMA_VERSION, data_source_for, new_run_id

def load_csv(path: str | Path) -> list[Candle]:
    rows=[]
    with open(path, newline='', encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            def num(k): return float(r[k])
            raw=r.get('time') or r.get('timestamp') or r.get('date')
            try: t=datetime.fromisoformat(raw.replace('Z','+00:00'))
            except Exception: t=datetime.fromtimestamp(len(rows), tz=timezone.utc)
            rows.append(Candle(t, num('open'), num('high'), num('low'), num('close'), float(r.get('volume') or 0)))
    return rows

def _decision_record(d: Decision, time: datetime) -> dict:
    return {
        'schema_version': SCHEMA_VERSION, 'time': time.isoformat(), 'build_id': d.build_id, 'run_id': d.run_id,
        'data_source': d.data_source, 'action': d.action, 'status': 'REJECTED' if d.action!='ENTER' else 'CANDIDATE',
        'reason': d.reason, 'side': d.side.value if d.side else None, 'entry': d.entry, 'stop': d.stop,
        'target': d.target, 'state': d.state.value, 'location': d.location, 'reaction': d.reaction,
        'thesis': d.thesis, 'invalidation': d.invalidation, 'risk_fraction': d.risk_fraction,
        'decision_key': d.idempotency_key, 'strategy_id': d.strategy_id or d.metadata.get('strategy_id'), 'thesis_id': d.metadata.get('thesis_id'),
        'strategy_version': d.metadata.get('strategy_version'),
        'entry_reasons': d.metadata.get('entry_reasons', []), 'entry_quality': d.metadata.get('entry_quality'),
        'execution_quality': d.metadata.get('execution_quality'), 'forecast': d.metadata.get('forecast'),
        'scenarios': d.metadata.get('scenarios'), 'market_context': d.metadata.get('market_context'),
        'metadata':d.metadata.copy(),
    }

def _attach_identity(decision: Decision, c: Candle, candles: list[Candle], account: AccountState, cfg: BotConfig, run_id: str, source: str) -> Decision:
    metadata=decision.metadata.copy()
    metadata['time']=c.time
    metadata['market_context']={
        'symbol':cfg.symbol, 'timeframe':cfg.timeframe, 'decision_time':c.time.isoformat(),
        'current_candle':{'open':c.open,'high':c.high,'low':c.low,'close':c.close,'volume':c.volume},
        'lookback_bars':len(candles), 'lookback_start':candles[0].time.isoformat() if candles else None,
        'lookback_end':candles[-1].time.isoformat() if candles else None,
        'account':{'equity':account.equity,'open_trades':account.open_trades,'consecutive_losses':account.consecutive_losses,'loss_pause':account.loss_pause},
        'risk_policy':{'risk_per_trade':cfg.risk_per_trade,'max_daily_loss':cfg.max_daily_loss,'target_rr':cfg.target_rr},
    }
    metadata['build_id']=BUILD_ID; metadata['run_id']=run_id; metadata['data_source']=source
    return replace(decision, metadata=metadata, build_id=BUILD_ID, run_id=run_id, data_source=source,
                   strategy_id=decision.strategy_id or metadata.get('strategy_id',''))

def run(candles: list[Candle], cfg: BotConfig, starting_equity: float = 1000.0, start_at: int | None = None, journal_path: str|Path|None = None, run_id: str|None = None, data_source: str|None = None, strategy_version: str | None = None) -> dict:
    source=data_source_for('backtest',data_source); run_id=run_id or new_run_id('walk' if 'walk' in source else 'backtest')
    account=AccountState(starting_equity, starting_equity); broker=PaperBroker(starting_equity)
    journal=Journal(journal_path,build_id=BUILD_ID,run_id=run_id,data_source=source) if journal_path else None
    trades=[]; opportunities=[]; waits={}; status_counts={'REJECTED':0,'CANDIDATE':0,'FILLED':0,'NOT_FILLED':0,'WIN':0,'LOSS':0,'FLAT':0}; peak=starting_equity; max_dd=0.0
    strategy_states={name:StrategyRuntimeState() for name in cfg.active_strategies}
    first=cfg.lookback if start_at is None else max(cfg.lookback,start_at)
    for i in range(first,len(candles)):
        c=candles[i]; closed=broker.on_candle(c,account)
        for closed_trade in closed:
            trades.append(closed_trade); outcome=closed_trade.metadata.get('outcome','FLAT'); status_counts[outcome]=status_counts.get(outcome,0)+1
            for prior in reversed(opportunities):
                if prior.get('decision_key')==closed_trade.decision_key:
                    prior.update({'status':outcome,'exit_time':closed_trade.exit_time.isoformat() if closed_trade.exit_time else None,'exit':closed_trade.exit,'pnl':closed_trade.pnl,'exit_reason':closed_trade.reason,'r_multiple':closed_trade.metadata.get('r_multiple')}); break
            if journal: journal.trade(closed_trade)
        if account.open_trades < cfg.max_concurrent:
            open_by_strategy={}
            for position in broker.open_trades.values():
                open_by_strategy[position.strategy_id]=open_by_strategy.get(position.strategy_id,0)+1
            # Decisions may inspect only bars before the simulated fill candle.
            # The current candle is reserved for fill/exit simulation (conservative OHLC sequencing).
            for raw_decision in decide_candidates(candles[:i],account,cfg,strategy_states=strategy_states,
                                                  open_positions_by_strategy=open_by_strategy):
                if strategy_version:
                    raw_decision.metadata['strategy_version']=strategy_version
                decision=_attach_identity(raw_decision,c,candles[:i],account,cfg,run_id,source)
                record=_decision_record(decision,c.time); opportunities.append(record); waits[decision.reason]=waits.get(decision.reason,0)+1; status_counts[record['status']]=status_counts.get(record['status'],0)+1
                if journal: journal.decision(decision); journal.opportunity(record)
                if decision.action=='ENTER':
                    try:
                        broker.enter(decision,account,cfg); record['status']='FILLED'; record['filled_time']=c.time.isoformat(); status_counts['CANDIDATE']-=1; status_counts['FILLED']+=1
                    except Exception as e:
                        record['status']='NOT_FILLED'; record['execution_error']=f'{type(e).__name__}:{e}'; status_counts['CANDIDATE']-=1; status_counts['NOT_FILLED']+=1; waits['RISK_'+type(e).__name__]=waits.get('RISK_'+type(e).__name__,0)+1
                    if journal: journal.opportunity(record)
        account.bars_since_last_entry+=1; peak=max(peak,account.equity); max_dd=max(max_dd,(peak-account.equity)/peak)
    wins=[t.pnl for t in trades if t.pnl is not None and t.pnl>0]; losses=[t.pnl for t in trades if t.pnl is not None and t.pnl<0]; gross_loss=abs(sum(losses))
    return {'schema_version':SCHEMA_VERSION,'build_id':BUILD_ID,'run_id':run_id,'data_source':source,'symbol':cfg.symbol,'timeframe':cfg.timeframe,'trades':trades,'opportunities':opportunities,'trade_count':len(trades),'wins':len(wins),'losses':len(losses),'net_pnl':sum(t.pnl or 0 for t in trades),'profit_factor':sum(wins)/gross_loss if gross_loss else None,'max_drawdown':max_dd,'ending_equity':account.equity,'wait_reasons':waits,'status_counts':status_counts}
