from __future__ import annotations
from dataclasses import dataclass
from .domain import Candle

@dataclass(frozen=True)
class VolumeProfile:
    poc: float
    value_area_low: float
    value_area_high: float
    hvn: tuple[float,...]
    lvn: tuple[float,...]
    total_volume: float
    source: str = 'tick_volume_or_uniform'
    bin_size: float = 0.0

def build_volume_profile(candles: list[Candle], bins: int=24, value_area: float=.70) -> VolumeProfile:
    if len(candles)<5: return VolumeProfile(0,0,0,(),(),0,'none',0)
    lo=min(c.low for c in candles); hi=max(c.high for c in candles); span=max(hi-lo,1e-9); bins=max(6,min(int(bins),200)); step=span/bins; hist=[0.0]*bins
    for c in candles:
        weight=max(c.volume,1.0)
        lo_i=max(0,min(bins-1,int((c.low-lo)/step))); hi_i=max(0,min(bins-1,int((c.high-lo)/step)))
        share=weight/max(1,hi_i-lo_i+1)
        for i in range(lo_i,hi_i+1): hist[i]+=share
    total=sum(hist); poc_i=max(range(bins),key=lambda i:hist[i]); included={poc_i}; covered=hist[poc_i]
    while covered<total*value_area and len(included)<bins:
        candidates=[i for i in range(bins) if i not in included]; i=max(candidates,key=lambda j:hist[j]); included.add(i); covered+=hist[i]
    low_i=min(included); high_i=max(included); hvn_i=sorted(range(bins),key=lambda i:hist[i],reverse=True)[:3]; lvn_i=sorted(range(bins),key=lambda i:hist[i])[:3]
    return VolumeProfile(lo+(poc_i+.5)*step,lo+low_i*step,lo+(high_i+1)*step,tuple(lo+(i+.5)*step for i in hvn_i),tuple(lo+(i+.5)*step for i in lvn_i),total,'candle_volume_distributed',step)
