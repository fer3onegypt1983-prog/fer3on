from __future__ import annotations
from statistics import mean, pstdev
from .domain import Candle, MarketState

def true_range(c: Candle, prev: Candle | None) -> float:
    if prev is None:
        return c.high - c.low
    return max(c.high - c.low, abs(c.high - prev.close), abs(c.low - prev.close))

def atr(candles: list[Candle], period: int) -> float:
    if not candles:
        return 0.0
    vals = [true_range(c, candles[i-1] if i else None) for i, c in enumerate(candles[-period:])]
    return mean(vals) if vals else 0.0

def body(c: Candle) -> float:
    return abs(c.close - c.open)

def direction(c: Candle) -> int:
    return 1 if c.close > c.open else -1 if c.close < c.open else 0

def classify_state(candles: list[Candle], a: float) -> MarketState:
    if len(candles) < 8 or a <= 0:
        return MarketState.UNKNOWN
    recent = candles[-8:]
    net = recent[-1].close - recent[0].open
    spread = max(c.high for c in recent) - min(c.low for c in recent)
    avg_body = mean(body(c) for c in recent)
    volatility = pstdev(c.close for c in recent) if len(recent) > 1 else 0.0
    if avg_body < a * 0.18 and volatility < a * 0.55:
        return MarketState.COMPRESSION
    if spread < a * 2.2:
        return MarketState.RANGE
    if abs(net) > a * 1.8:
        if net > 0:
            return MarketState.EXHAUSTION_UP if body(recent[-1]) < body(recent[-2]) * 0.65 else MarketState.EXPANSION_UP
        return MarketState.EXHAUSTION_DOWN if body(recent[-1]) < body(recent[-2]) * 0.65 else MarketState.EXPANSION_DOWN
    if net > 0:
        return MarketState.PULLBACK_UP if recent[-1].close < recent[-2].close else MarketState.EXPANSION_UP
    if net < 0:
        return MarketState.PULLBACK_DOWN if recent[-1].close > recent[-2].close else MarketState.EXPANSION_DOWN
    return MarketState.UNKNOWN

def location(candles: list[Candle], window: int) -> tuple[str, float]:
    if len(candles) < window:
        return "UNKNOWN", 0.5
    segment = candles[-window:]
    lo = min(c.low for c in segment); hi = max(c.high for c in segment)
    span = hi - lo
    if span <= 0:
        return "BALANCED", 0.5
    pos = (segment[-1].close - lo) / span
    if pos <= 0.22: return "LOW_EXTREME", pos
    if pos >= 0.78: return "HIGH_EXTREME", pos
    if pos <= 0.42: return "LOW_HALF", pos
    if pos >= 0.58: return "HIGH_HALF", pos
    return "BALANCED", pos

def reaction(candles: list[Candle], a: float) -> tuple[str, int]:
    if len(candles) < 3 or a <= 0:
        return "NONE", 0
    prev, cur = candles[-2], candles[-1]
    cur_body = body(cur)
    if cur.low < prev.low and cur.close > prev.close and cur.close > cur.open and cur_body >= a * 0.20:
        return "RECLAIM_UP", 1
    if cur.high > prev.high and cur.close < prev.close and cur.close < cur.open and cur_body >= a * 0.20:
        return "RECLAIM_DOWN", -1
    if cur.close > prev.high and cur_body >= a * 0.80:
        return "DISPLACEMENT_UP", 1
    if cur.close < prev.low and cur_body >= a * 0.80:
        return "DISPLACEMENT_DOWN", -1
    return "NONE", 0
