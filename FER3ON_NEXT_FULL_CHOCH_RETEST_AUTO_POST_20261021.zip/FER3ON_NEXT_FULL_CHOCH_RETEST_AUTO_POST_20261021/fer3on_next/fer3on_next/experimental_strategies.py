from __future__ import annotations

"""Independent active Paper/MT5 strategy plugins for FER3ON Next.

These are experimental rules, not performance claims. The scenario-tree planner
keeps its frozen map across closed candles and emits a decision only when a
pre-planned branch becomes newly confirmed. This module never connects to MT5.
"""

from dataclasses import dataclass, replace
from hashlib import sha256
from typing import Any

from .domain import AccountState, BotConfig, Candle, Decision, MarketState, Side
from .market import atr
from .position_sizing import build_position_plan
from .scenario_tree import ScenarioTree, ScenarioTreeConfig, advance_scenario_tree, build_scenario_tree


@dataclass
class StrategyRuntimeState:
    scenario_tree: ScenarioTree | None = None
    pending_pullback: dict[str, Any] | None = None
    last_emitted_branch: str | None = None
    bars_since_last_entry: int = 10_000
    last_processed_candle_time: Any = None
    last_logged_candle_time: Any = None
    cached_decision: Decision | None = None


def _wait(strategy_id: str, reason: str, metadata: dict[str, Any] | None = None) -> Decision:
    meta = dict(metadata or {})
    meta.update({"strategy_id": strategy_id, "active_strategy": True})
    return Decision("WAIT", reason=reason, thesis=reason, metadata=meta, strategy_id=strategy_id)


def _decision(
    strategy_id: str,
    version: str,
    candle: Candle,
    side: Side,
    entry: float,
    stop: float,
    target: float,
    atr_value: float,
    account: AccountState,
    cfg: BotConfig,
    reason: str,
    metadata: dict[str, Any],
) -> Decision:
    if side is Side.BUY and not stop < entry < target:
        return _wait(strategy_id, "INVALID_LONG_GEOMETRY", metadata)
    if side is Side.SELL and not target < entry < stop:
        return _wait(strategy_id, "INVALID_SHORT_GEOMETRY", metadata)
    risk_distance = abs(entry - stop)
    reward_distance = abs(target - entry)
    if risk_distance <= 0:
        return _wait(strategy_id, "ZERO_STOP_DISTANCE", metadata)
    try:
        sizing = build_position_plan(
            account.equity,
            cfg.risk_per_trade,
            risk_distance,
            atr_value,
            cfg.point_value,
            cfg.max_unit_size,
            cfg.volatility_target_atr if cfg.enable_volatility_sizing and cfg.volatility_target_atr > 0 else None,
        )
    except ValueError as exc:
        return _wait(strategy_id, f"POSITION_SIZE_INVALID:{exc}", metadata)
    metadata.update({
        "strategy_id": strategy_id,
        "active_strategy": True,
        "strategy_version": version,
        "entry_reasons": [reason],
        "risk_distance": risk_distance,
        "reward_distance": reward_distance,
        "rr": reward_distance / risk_distance,
        "position_sizing": {
            "risk_cash": sizing.risk_cash,
            "risk_fraction": sizing.risk_fraction,
            "unit_size": sizing.unit_size,
            "volatility_scalar": sizing.volatility_scalar,
            "reason": sizing.reason,
            "point_value": cfg.point_value,
        },
        "signal_candle": {
            "time": candle.time.isoformat(), "open": candle.open, "high": candle.high,
            "low": candle.low, "close": candle.close, "volume": candle.volume,
        },
    })
    key = sha256(
        f"{strategy_id}|{version}|{candle.time.isoformat()}|{side.value}|{entry:.10f}|{stop:.10f}|{target:.10f}".encode()
    ).hexdigest()[:24]
    thesis = f"{strategy_id}: {reason}; closed-candle signal at {entry:.5f}"
    return Decision(
        action="ENTER", side=side, entry=entry, stop=stop, target=target,
        state=MarketState.UNKNOWN, location="EXPERIMENTAL_SIGNAL", reaction=reason,
        thesis=thesis, invalidation=f"Stop at {stop:.5f}", reason=reason,
        risk_fraction=sizing.risk_fraction, idempotency_key=key,
        metadata=metadata, strategy_id=strategy_id,
    )


def _scenario_config(cfg: BotConfig) -> ScenarioTreeConfig:
    return ScenarioTreeConfig(
        atr_period=cfg.atr_period,
        swing_left=cfg.scenario_swing_left,
        swing_right=cfg.scenario_swing_right,
        max_levels_each_side=cfg.scenario_max_levels_each_side,
        merge_distance_atr=cfg.scenario_merge_distance_atr,
        reference_half_width_atr=cfg.scenario_reference_half_width_atr,
        approach_distance_atr=cfg.scenario_approach_distance_atr,
        touch_tolerance_atr=cfg.scenario_touch_tolerance_atr,
        break_buffer_atr=cfg.scenario_break_buffer_atr,
        break_min_body_atr=cfg.scenario_break_min_body_atr,
        bounce_confirmation_atr=cfg.scenario_bounce_confirmation_atr,
        stop_buffer_atr=cfg.scenario_stop_buffer_atr,
        min_reward_risk=cfg.scenario_min_reward_risk,
        fallback_target_rr=cfg.scenario_fallback_target_rr,
        max_retest_bars=cfg.scenario_max_retest_bars,
        max_plan_age_bars=cfg.scenario_max_plan_age_bars,
        probability_window_days=cfg.scenario_probability_window_days,
        minimum_probability_samples=cfg.scenario_min_probability_samples,
    )


def _tree_metadata(tree: ScenarioTree) -> dict[str, Any]:
    return {
        "scenario_tree": {
            "strategy_id": tree.strategy_id,
            "strategy_version": tree.strategy_version,
            "symbol": tree.symbol,
            "as_of": tree.as_of.isoformat(),
            "current_price": tree.current_price,
            "atr": tree.atr_value,
            "map_snapshot_id": tree.map_snapshot_id,
            "data_sha256": tree.data_sha256,
            "config_sha256": tree.config_sha256,
            "age_bars": tree.age_bars,
            "context": tree.current_context,
            "context_reason": tree.context_reason,
            "levels": [
                {"level_id": level.level_id, "kind": level.kind, "low": level.low,
                 "high": level.high, "midpoint": level.midpoint, "sources": list(level.sources),
                 "strength": level.strength, "observed_at": level.observed_at.isoformat()}
                for level in tree.levels
            ],
            "branches": [
                {"branch_id": branch.branch_id, "level_id": branch.level_id,
                 "level_kind": branch.level_kind, "branch_kind": branch.branch_kind,
                 "side": branch.side.value, "state": branch.state,
                 "state_reason": branch.state_reason, "trigger": branch.trigger,
                 "confirmation": branch.confirmation, "order_policy": branch.order_policy,
                 "entry_zone": [branch.entry_low, branch.entry_high],
                 "stop": branch.stop_price, "target_level_id": branch.target_level_id,
                 "target": branch.target_price, "target_policy": branch.target_policy,
                 "planned_rr": branch.planned_reward_risk,
                 "eligible": branch.eligible_after_trigger, "block_reason": branch.block_reason,
                 "invalidation": branch.invalidation, "expiry_bars": branch.expiry_bars,
                 "probability": {
                     "status": branch.probability.status,
                     "estimate": branch.probability.estimate,
                     "lower_95": branch.probability.lower_95,
                     "upper_95": branch.probability.upper_95,
                     "sample_count": branch.probability.sample_count,
                     "successes": branch.probability.successes,
                     "calibration_id": branch.probability.calibration_id,
                     "is_execution_gate": branch.probability.is_execution_gate,
                 }}
                for branch in tree.branches
            ],
        }
    }


def decide_scenario_tree(
    candles: list[Candle], account: AccountState, cfg: BotConfig,
    state: StrategyRuntimeState, version: str = "level-map-scenario-tree-0.2.0",
) -> Decision:
    """Plan from prior bars, advance only with later closed bars, then trade a new confirmation."""
    strategy_id = "LEVEL_MAP_SCENARIO_TREE"
    config = _scenario_config(cfg)
    min_bars = max(config.atr_period, config.swing_left + config.swing_right + 3)
    if len(candles) < min_bars + 1:
        return _wait(strategy_id, "INSUFFICIENT_SCENARIO_HISTORY")

    tree = state.scenario_tree
    terminal = {"CONFIRMED", "INVALIDATED", "EXPIRED", "NO_TRADE"}
    if tree is None or all(branch.state in terminal for branch in tree.branches):
        # Freeze the map before the newest closed candle; never plan from the
        # same bar that will be evaluated for its trigger.
        try:
            tree = build_scenario_tree(candles[:-1], cfg.symbol, config, strategy_version=version)
        except ValueError as exc:
            state.scenario_tree = None
            return _wait(strategy_id, f"SCENARIO_PLAN_UNAVAILABLE:{exc}")
        state.scenario_tree = tree

    pending = [bar for bar in candles if tree.last_closed_time and bar.time > tree.last_closed_time]
    newly_confirmed = None
    for bar in pending:
        previous = {branch.branch_id: branch.state for branch in tree.branches}
        try:
            tree = advance_scenario_tree(tree, bar)
        except ValueError as exc:
            state.scenario_tree = None
            return _wait(strategy_id, f"SCENARIO_ADVANCE_ERROR:{exc}")
        if bar.time == candles[-1].time:
            newly_confirmed = next((
                branch for branch in tree.branches
                if branch.state == "CONFIRMED" and previous.get(branch.branch_id) != "CONFIRMED"
            ), None)
    state.scenario_tree = tree
    snapshot = _tree_metadata(tree)
    if newly_confirmed is None:
        return _wait(strategy_id, tree.context_reason, snapshot)

    branch = newly_confirmed
    if branch.target_price is None:
        return _wait(strategy_id, "CONFIRMED_BRANCH_HAS_NO_TARGET", snapshot)
    candle = candles[-1]
    entry = candle.close
    rr = abs(branch.target_price - entry) / abs(entry - branch.stop_price) if entry != branch.stop_price else 0.0
    if branch.side is Side.BUY and not branch.stop_price < entry < branch.target_price:
        return _wait(strategy_id, "CONFIRMED_BRANCH_ENTRY_OUTSIDE_PLAN_GEOMETRY", snapshot)
    if branch.side is Side.SELL and not branch.target_price < entry < branch.stop_price:
        return _wait(strategy_id, "CONFIRMED_BRANCH_ENTRY_OUTSIDE_PLAN_GEOMETRY", snapshot)
    if rr < config.min_reward_risk:
        return _wait(strategy_id, "CONFIRMED_BRANCH_CURRENT_RR_TOO_LOW", snapshot)
    state.last_emitted_branch = branch.branch_id
    snapshot["scenario_tree"]["confirmed_branch_id"] = branch.branch_id
    snapshot["scenario_tree"]["entry_rr_at_confirmation"] = rr
    return _decision(
        strategy_id, version, candle, branch.side, entry, branch.stop_price, branch.target_price,
        tree.atr_value, account, cfg, f"SCENARIO_{branch.branch_kind}_{branch.state_reason}", snapshot,
    )


def _latest_impulse(candles: list[Candle], cfg: BotConfig) -> tuple[int, Candle, float, int] | None:
    if len(candles) < cfg.atr_period + 3:
        return None
    last_index = len(candles) - 3  # reserve one retest bar and the current confirmation bar
    first_index = max(cfg.atr_period, len(candles) - cfg.impulse_max_age_bars - 2)
    for index in range(last_index, first_index - 1, -1):
        prior = candles[max(0, index - cfg.atr_period):index]
        value = atr(prior, cfg.atr_period)
        candle = candles[index]
        body = abs(candle.close - candle.open)
        direction = 1 if candle.close > candle.open else -1 if candle.close < candle.open else 0
        if value > 0 and direction and body >= cfg.impulse_min_body_atr * value:
            return index, candle, value, direction
    return None


def decide_impulse_retest(
    candles: list[Candle], account: AccountState, cfg: BotConfig,
    version: str = "impulse-retest-0.1.0",
) -> Decision:
    """Trade continuation only after price returns to the impulse midpoint and confirms."""
    strategy_id = "IMPULSE_RETEST"
    found = _latest_impulse(candles, cfg)
    if found is None:
        return _wait(strategy_id, "NO_RECENT_QUALIFIED_IMPULSE")
    index, impulse, impulse_atr, direction = found
    current = candles[-1]
    age = len(candles) - 1 - index
    midpoint = (impulse.high + impulse.low) / 2.0
    confirmation_body = abs(current.close - current.open)
    confirmed = (
        current.low <= midpoint and current.close > midpoint and current.close > current.open
        and confirmation_body >= cfg.impulse_confirmation_body_atr * impulse_atr
        if direction > 0 else
        current.high >= midpoint and current.close < midpoint and current.close < current.open
        and confirmation_body >= cfg.impulse_confirmation_body_atr * impulse_atr
    )
    metadata = {
        "impulse": {"index": index, "time": impulse.time.isoformat(), "open": impulse.open,
                    "high": impulse.high, "low": impulse.low, "close": impulse.close,
                    "atr_before_impulse": impulse_atr, "body_atr": abs(impulse.close-impulse.open)/impulse_atr,
                    "direction": "UP" if direction > 0 else "DOWN", "age_bars": age,
                    "midpoint": midpoint, "setup": "MIDPOINT_RETEST_THEN_CONTINUATION"},
    }
    if age < 1 or age > cfg.impulse_max_age_bars:
        return _wait(strategy_id, "IMPULSE_RETEST_EXPIRED", metadata)
    if not confirmed:
        return _wait(strategy_id, "WAITING_FOR_MIDPOINT_RETEST_CONFIRMATION", metadata)
    side = Side.BUY if direction > 0 else Side.SELL
    buffer = cfg.impulse_stop_buffer_atr * impulse_atr
    stop = impulse.low - buffer if side is Side.BUY else impulse.high + buffer
    entry = current.close
    risk = abs(entry - stop)
    if side is Side.BUY:
        target = max(impulse.high, entry + cfg.target_rr * risk)
    else:
        target = min(impulse.low, entry - cfg.target_rr * risk)
    rr = abs(target-entry)/risk if risk else 0.0
    metadata["impulse"]["planned_rr"] = rr
    if rr < cfg.impulse_min_reward_risk:
        return _wait(strategy_id, "IMPULSE_RETEST_RR_TOO_LOW", metadata)
    return _decision(strategy_id, version, current, side, entry, stop, target, impulse_atr,
                     account, cfg, "IMPULSE_MIDPOINT_RETEST_CONTINUATION_CONFIRMED", metadata)


def decide_impulse_midpoint_reversal(
    candles: list[Candle], account: AccountState, cfg: BotConfig,
    version: str = "impulse-midpoint-reversal-0.1.0",
) -> Decision:
    """Trade a confirmed early pullback against a large impulse, targeting its midpoint."""
    strategy_id = "IMPULSE_MIDPOINT_REVERSAL"
    found = _latest_impulse(candles, cfg)
    if found is None:
        return _wait(strategy_id, "NO_RECENT_QUALIFIED_IMPULSE")
    index, impulse, impulse_atr, direction = found
    current = candles[-1]
    previous = candles[-2]
    age = len(candles) - 1 - index
    midpoint = (impulse.high + impulse.low) / 2.0
    full_range = impulse.high - impulse.low
    depth = cfg.midpoint_retrace_fraction
    if not 0.05 <= depth < 0.50:
        return _wait(strategy_id, "MIDPOINT_RETRACE_FRACTION_OUT_OF_RANGE", {"retrace_fraction": depth})
    if direction > 0:
        trigger = impulse.high - depth * full_range
        confirmed = previous.close > trigger and current.close <= trigger and current.close > midpoint and current.close < current.open
        side = Side.SELL
        stop = impulse.high + cfg.impulse_stop_buffer_atr * impulse_atr
        target = midpoint
    else:
        trigger = impulse.low + depth * full_range
        confirmed = previous.close < trigger and current.close >= trigger and current.close < midpoint and current.close > current.open
        side = Side.BUY
        stop = impulse.low - cfg.impulse_stop_buffer_atr * impulse_atr
        target = midpoint
    metadata = {
        "impulse": {"index": index, "time": impulse.time.isoformat(), "open": impulse.open,
                    "high": impulse.high, "low": impulse.low, "close": impulse.close,
                    "atr_before_impulse": impulse_atr, "body_atr": abs(impulse.close-impulse.open)/impulse_atr,
                    "direction": "UP" if direction > 0 else "DOWN", "age_bars": age,
                    "midpoint": midpoint, "retrace_trigger": trigger,
                    "retrace_fraction": depth, "setup": "COUNTER_IMPULSE_TO_MIDPOINT"},
    }
    if age < 1 or age > cfg.impulse_max_age_bars:
        return _wait(strategy_id, "MIDPOINT_REVERSAL_EXPIRED", metadata)
    if not confirmed:
        return _wait(strategy_id, "WAITING_FOR_EARLY_COUNTER_IMPULSE_RETRACE", metadata)
    entry = current.close
    risk = abs(entry-stop)
    rr = abs(target-entry)/risk if risk else 0.0
    metadata["impulse"]["planned_rr"] = rr
    if rr < cfg.midpoint_min_reward_risk:
        return _wait(strategy_id, "MIDPOINT_REVERSAL_RR_TOO_LOW", metadata)
    return _decision(strategy_id, version, current, side, entry, stop, target, impulse_atr,
                     account, cfg, "COUNTER_IMPULSE_RETRACE_TARGETS_CANDLE_MIDPOINT", metadata)


def decide_experimental(
    strategy_id: str, candles: list[Candle], account: AccountState, cfg: BotConfig,
    state: StrategyRuntimeState | None = None, version: str | None = None,
) -> Decision:
    name = strategy_id.upper()
    state = state if state is not None else StrategyRuntimeState()
    if name == "LEVEL_MAP_SCENARIO_TREE":
        return decide_scenario_tree(candles, account, cfg, state, version or "level-map-scenario-tree-0.2.0")
    if name == "IMPULSE_RETEST":
        return decide_impulse_retest(candles, account, cfg, version or "impulse-retest-0.1.0")
    if name == "IMPULSE_MIDPOINT_REVERSAL":
        decision = decide_impulse_midpoint_reversal(candles, account, cfg, version or "impulse-midpoint-reversal-0.1.0")
        if decision.action == "ENTER":
            metadata = dict(decision.metadata)
            metadata.update({
                "research_only": True,
                "execution_disabled": True,
                "candidate_action": "ENTER",
                "candidate_reason": decision.reason,
            })
            return replace(decision, action="WAIT", reason="RESEARCH_ONLY_EXECUTION_DISABLED",
                           thesis=f"{decision.thesis} [RESEARCH_ONLY]", metadata=metadata)
        return decision
    return _wait(name, "STRATEGY_NOT_IMPLEMENTED")
