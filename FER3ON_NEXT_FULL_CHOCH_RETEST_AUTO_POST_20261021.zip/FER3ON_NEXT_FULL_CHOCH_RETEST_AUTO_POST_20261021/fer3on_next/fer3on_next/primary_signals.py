from __future__ import annotations
from dataclasses import dataclass
from .domain import Candle, Side
from .market_events import detect_events, find_fvgs
from .structure import analyze_structure
from .market import atr

@dataclass(frozen=True)
class Signal:
    name: str
    side: Side | None
    value: float
    reason: str
    metadata: dict


def time_series_momentum(candles: list[Candle], lookback: int) -> Signal:
    if lookback <= 0 or len(candles) <= lookback:
        return Signal("TSM", None, 0.0, "INSUFFICIENT_MOMENTUM_HISTORY", {})
    current = candles[-1].close; reference = candles[-1-lookback].close
    change = (current / reference) - 1.0 if reference else 0.0
    side = Side.BUY if change > 0 else Side.SELL if change < 0 else None
    return Signal("TSM", side, change, "POSITIVE_MOMENTUM" if change > 0 else "NEGATIVE_MOMENTUM" if change < 0 else "FLAT_MOMENTUM", {
        "lookback_bars": lookback, "reference_close": reference, "signal_close": current, "return": change})


def tsm_choch_retest(candles: list[Candle], momentum_lookback: int, atr_period: int = 14,
                     max_age_bars: int = 8, retest_tolerance_atr: float = 0.25,
                     confirmation_body_atr: float = 0.10, min_score: float = 0.70,
                     require_retest: bool = True) -> Signal:
    """TSM continuation only after a confirmed CHOCH, later retest and acceptance.

    A current FVG is never sufficient by itself.  The event must be a historical
    CHOCH, followed by a separate retest candle and a current closed-candle
    acceptance in the same direction as momentum.
    """
    if len(candles) < max(momentum_lookback + 1, atr_period + 12, 20):
        return Signal("TSM", None, 0.0, "INSUFFICIENT_TSM_CHOCH_HISTORY", {})
    current = candles[-1]
    current_atr = atr(candles, atr_period)
    if current_atr <= 0:
        return Signal("TSM", None, 0.0, "TSM_CHOCH_ATR_UNAVAILABLE", {})
    momentum = (current.close / candles[-1 - momentum_lookback].close) - 1.0
    momentum_side = Side.BUY if momentum > 0 else Side.SELL if momentum < 0 else None
    if momentum_side is None:
        return Signal("TSM", None, 0.0, "TSM_FLAT_MOMENTUM", {"return": momentum})

    candidates = []
    # j is the closed CHOCH bar; k is a later retest bar; the final bar is
    # reserved for acceptance.  This prevents same-bar look-ahead.
    # Older CHOCH events cannot still produce a valid retest for the current
    # candle. Restricting the scan keeps live and walk-backtest cost bounded.
    first_choch = max(12, atr_period + 2, len(candles) - max(1, max_age_bars) - 3)
    for j in range(first_choch, len(candles) - 2):
        prefix = candles[:j + 1]
        a = atr(prefix, atr_period)
        if a <= 0:
            continue
        structure = analyze_structure(prefix, 2, 2)
        events = [e for e in detect_events(prefix, structure, a)
                  if e.name == "CHOCH" and e.confirmed and e.retest and e.continuation_score >= min_score]
        for event in events:
            side = Side.BUY if event.direction == "BUY" else Side.SELL
            if side is not momentum_side:
                continue
            for k in range(j + 1, min(len(candles) - 1, j + 1 + max(1, max_age_bars))):
                retest = candles[k]
                tolerance = a * max(0.0, retest_tolerance_atr)
                touched = ((side is Side.BUY and retest.low <= event.level + tolerance and retest.close >= event.level) or
                            (side is Side.SELL and retest.high >= event.level - tolerance and retest.close <= event.level))
                if touched:
                    candidates.append((j, k, event, a))
                    break
    if not candidates:
        return Signal("TSM", None, 0.0, "TSM_WAITING_FOR_CHOCH_RETEST", {
            "momentum_return": momentum, "momentum_side": momentum_side.value,
            "require_retest": require_retest, "blocked_direct_fvg": True,
            "max_age_bars": max_age_bars})
    j, k, event, event_atr = candidates[-1]
    side = Side.BUY if event.direction == "BUY" else Side.SELL
    body_atr = abs(current.close - current.open) / current_atr
    accepted = ((side is Side.BUY and current.close > event.level and current.close > current.open) or
                (side is Side.SELL and current.close < event.level and current.close < current.open))
    if not accepted or body_atr < confirmation_body_atr:
        return Signal("TSM", None, 0.0, "TSM_CHOCH_RETEST_WAITING_ACCEPTANCE", {
            "choch_index": j, "retest_index": k, "choch_level": event.level,
            "direction": event.direction, "body_atr": body_atr,
            "confirmation_body_atr": confirmation_body_atr, "blocked_direct_fvg": True})
    return Signal("TSM", side, event.continuation_score, "TSM_CHOCH_RETEST_CONFIRMED", {
        "choch_index": j, "retest_index": k, "choch_level": event.level,
        "direction": event.direction, "momentum_return": momentum,
        "momentum_lookback": momentum_lookback, "body_atr": body_atr,
        "choch_score": event.continuation_score, "retest": True,
        "confirmation": "closed candle accepted beyond CHOCH level",
        "blocked_direct_fvg": True})


def donchian_breakout(candles: list[Candle], entry_window: int, exit_window: int,
                      atr_period: int = 14, buffer_atr: float = 0.05,
                      require_retest: bool = True, retest_max_bars: int = 6,
                      retest_tolerance_atr: float = 0.20,
                      min_breakout_body_atr: float = 0.30,
                      max_breakout_body_atr: float = 2.50) -> Signal:
    if entry_window <= 0 or exit_window <= 0 or len(candles) <= max(entry_window, exit_window):
        return Signal("DONCHIAN", None, 0.0, "INSUFFICIENT_DONCHIAN_HISTORY", {})
    current = candles[-1]
    current_atr = atr(candles, atr_period) if len(candles) > atr_period else 0.0
    tolerance = max(0.0, current_atr * retest_tolerance_atr)
    # Search only completed candles before the current confirmation candle.
    candidates = []
    first = max(entry_window, atr_period + 1)
    for index in range(first, len(candles) - 1):
        prior = candles[:index]
        upper = max(c.high for c in prior[-entry_window:])
        lower = min(c.low for c in prior[-entry_window:])
        bar = candles[index]
        bar_atr = atr(prior, atr_period)
        buffer = max(0.0, bar_atr * buffer_atr)
        body_atr = abs(bar.close - bar.open) / bar_atr if bar_atr > 0 else 0.0
        if bar.close > upper + buffer and bar.close > bar.open and min_breakout_body_atr <= body_atr <= max_breakout_body_atr:
            candidates.append((index, Side.BUY, upper, bar_atr, body_atr))
        elif bar.close < lower - buffer and bar.close < bar.open and min_breakout_body_atr <= body_atr <= max_breakout_body_atr:
            candidates.append((index, Side.SELL, lower, bar_atr, body_atr))
    if not candidates:
        return Signal("DONCHIAN", None, 0.0, "NO_QUALIFIED_DONCHIAN_BREAKOUT", {
            "entry_window": entry_window, "exit_window": exit_window,
            "require_retest": require_retest, "min_breakout_body_atr": min_breakout_body_atr,
            "max_breakout_body_atr": max_breakout_body_atr})
    index, breakout_side, level, breakout_atr, body_atr = candidates[-1]
    age = len(candles) - 1 - index
    if not require_retest:
        return Signal("DONCHIAN", breakout_side, body_atr, "QUALIFIED_DONCHIAN_BREAKOUT", {
            "breakout_index": index, "breakout_level": level, "age": age,
            "body_atr": body_atr, "retest_required": False})
    if age < 1 or age > max(1, retest_max_bars):
        return Signal("DONCHIAN", None, 0.0, "WAITING_FOR_DONCHIAN_RETEST", {
            "breakout_index": index, "breakout_level": level, "age": age,
            "retest_max_bars": retest_max_bars, "body_atr": body_atr})
    bullish_confirmation = breakout_side is Side.BUY and current.low <= level + tolerance and current.close > level and current.close > current.open
    bearish_confirmation = breakout_side is Side.SELL and current.high >= level - tolerance and current.close < level and current.close < current.open
    if not (bullish_confirmation or bearish_confirmation):
        return Signal("DONCHIAN", None, 0.0, "WAITING_FOR_DONCHIAN_RETEST_CONFIRMATION", {
            "breakout_index": index, "breakout_level": level, "age": age,
            "tolerance": tolerance, "current_close": current.close,
            "retest_required": True})
    return Signal("DONCHIAN", breakout_side, body_atr, "DONCHIAN_BREAKOUT_RETEST_CONFIRMED", {
        "breakout_index": index, "breakout_level": level, "age": age,
        "tolerance": tolerance, "body_atr": body_atr,
        "retest_required": True, "confirmation_close": current.close})


def _event_signal(candles: list[Candle], name: str, fvg_min_gap_atr: float = 0.10,
                  fvg_max_age: int = 24, fvg_min_displacement_atr: float = 0.65) -> Signal:
    if len(candles) < 10:
        return Signal(name, None, 0.0, "INSUFFICIENT_EVENT_HISTORY", {})
    a = atr(candles, 14)
    structure = analyze_structure(candles, 2, 2)
    if name == "FVG":
        current_index = len(candles) - 1
        valid = [f for f in find_fvgs(candles) if current_index - f.created_index <= fvg_max_age and (f.high-f.low) >= a*fvg_min_gap_atr]
        valid = [f for f in valid if abs(candles[f.created_index].close-candles[max(0,f.created_index-1)].close) >= a*fvg_min_displacement_atr]
        if not valid:
            return Signal(name, None, 0.0, "NO_QUALIFIED_FVG", {"min_gap_atr": fvg_min_gap_atr, "max_age": fvg_max_age})
        current = candles[-1]
        retested = [f for f in valid if f.low <= current.close <= f.high or (f.direction == 'BUY' and current.low <= f.high and current.close > f.high) or (f.direction == 'SELL' and current.high >= f.low and current.close < f.low)]
        if not retested:
            return Signal(name, None, 0.0, "FVG_NOT_RETESTED", {"qualified_count": len(valid), "max_age": fvg_max_age})
        f = retested[-1]; side = Side.BUY if f.direction == 'BUY' else Side.SELL
        return Signal(name, side, (f.high-f.low)/a, "QUALIFIED_FVG_RETEST", {"direction": f.direction, "low": f.low, "high": f.high, "created_index": f.created_index, "age": current_index-f.created_index, "gap_atr": (f.high-f.low)/a, "retest": True})
    events = [e for e in detect_events(candles, structure, a) if e.name == name and e.confirmed]
    if not events:
        return Signal(name, None, 0.0, f"NO_CONFIRMED_{name}", {"event_count": 0})
    event = max(events, key=lambda e: (e.retest, e.continuation_score))
    side = Side.BUY if event.direction == "BUY" else Side.SELL
    score = event.continuation_score if event.retest else event.continuation_score * 0.8
    return Signal(name, side, score, f"CONFIRMED_{name}_{'RETEST' if event.retest else 'BREAK'}", {
        "event": event.name, "direction": event.direction, "level": event.level,
        "confirmed": event.confirmed, "retest": event.retest,
        "continuation_score": event.continuation_score, "reversal_score": event.reversal_score,
        "event_reason": event.reason, "structure_bias": structure.bias})


def order_block_signal(candles: list[Candle], max_age: int = 24, min_displacement_atr: float = 0.60,
                       max_width_atr: float = 1.75, structure_left: int = 2, structure_right: int = 2) -> Signal:
    if len(candles) < 12:
        return Signal("ORDER_BLOCK", None, 0.0, "INSUFFICIENT_ORDER_BLOCK_HISTORY", {})
    a = atr(candles, 14); structure = analyze_structure(candles, structure_left, structure_right)
    events = [e for e in detect_events(candles, structure, a) if e.name == "BOS" and e.confirmed]
    if not events:
        return Signal("ORDER_BLOCK", None, 0.0, "NO_BOS_FOR_ORDER_BLOCK", {})
    event = max(events, key=lambda e: (e.retest, e.level or 0.0))
    direction = event.direction
    # The block is the latest opposite candle before the confirmed break.
    break_index = len(candles) - 1
    candidates=[]
    for i in range(max(0, break_index-8), break_index):
        c=candles[i]; body=c.close-c.open
        opposite=(direction == 'BUY' and body < 0) or (direction == 'SELL' and body > 0)
        if opposite: candidates.append((i,c))
    if not candidates:
        return Signal("ORDER_BLOCK", None, 0.0, "NO_OPPOSITE_ORDER_BLOCK", {"bos_level": event.level, "direction": direction})
    index, block = candidates[-1]; close=candles[-1].close
    if break_index-index > max_age:
        return Signal("ORDER_BLOCK", None, 0.0, "ORDER_BLOCK_TOO_OLD", {"block_index": index, "age": break_index-index, "max_age": max_age})
    if block.high-block.low > a*max_width_atr:
        return Signal("ORDER_BLOCK", None, 0.0, "ORDER_BLOCK_TOO_WIDE", {"block_index": index, "width_atr": (block.high-block.low)/a, "max_width_atr": max_width_atr})
    if event.level is None or abs(event.level-block.close) < a*min_displacement_atr:
        return Signal("ORDER_BLOCK", None, 0.0, "ORDER_BLOCK_NO_DISPLACEMENT", {"block_index": index, "displacement_atr": abs((event.level or block.close)-block.close)/a, "min_displacement_atr": min_displacement_atr})
    inside = block.low <= close <= block.high
    side = Side.BUY if direction == 'BUY' else Side.SELL if direction == 'SELL' else None
    if not inside:
        return Signal("ORDER_BLOCK", None, 0.0, "ORDER_BLOCK_NOT_RETESTED", {"block_index": index, "block_low": block.low, "block_high": block.high, "bos_level": event.level})
    return Signal("ORDER_BLOCK", side, 0.75, "ORDER_BLOCK_RETEST_CONFIRMED", {
        "block_index": index, "block_low": block.low, "block_high": block.high,
        "bos_level": event.level, "direction": direction, "retest": True})


def primary_signal(candles: list[Candle], mode: str, momentum_lookback: int, donchian_entry: int, donchian_exit: int,
                   atr_period: int = 14, donchian_buffer_atr: float = 0.05,
                   donchian_require_retest: bool = True, donchian_retest_max_bars: int = 6,
                   donchian_retest_tolerance_atr: float = 0.20, donchian_min_breakout_body_atr: float = 0.30,
                   donchian_max_breakout_body_atr: float = 2.50,
                   fvg_min_gap_atr: float = 0.10, fvg_max_age: int = 24,
                   fvg_min_displacement_atr: float = 0.65, ob_max_age: int = 24,
                   ob_min_displacement_atr: float = 0.60, ob_max_width_atr: float = 1.75,
                   ob_structure_left: int = 2, ob_structure_right: int = 2,
                   tsm_require_choch_retest: bool = True, tsm_choch_max_age_bars: int = 8,
                   tsm_choch_retest_tolerance_atr: float = 0.25,
                   tsm_choch_confirmation_body_atr: float = 0.10,
                   tsm_choch_min_score: float = 0.70) -> Signal:
    mode = mode.upper().strip()
    requested_mode = mode
    if mode == "TSM":
        return tsm_choch_retest(candles, momentum_lookback, atr_period, tsm_choch_max_age_bars,
                                tsm_choch_retest_tolerance_atr, tsm_choch_confirmation_body_atr,
                                tsm_choch_min_score, tsm_require_choch_retest)
    if mode == "DONCHIAN":
        return donchian_breakout(candles, donchian_entry, donchian_exit, atr_period, donchian_buffer_atr,
                                 donchian_require_retest, donchian_retest_max_bars,
                                 donchian_retest_tolerance_atr, donchian_min_breakout_body_atr,
                                 donchian_max_breakout_body_atr)
    if mode == "FVG_MODERATE":
        signal = _event_signal(candles, "FVG", fvg_min_gap_atr, fvg_max_age, fvg_min_displacement_atr)
        return Signal(requested_mode, signal.side, signal.value, signal.reason, signal.metadata)
    if mode == "BOS": return _event_signal(candles, mode)
    if mode == "ORDER_BLOCK_MODERATE":
        signal = order_block_signal(candles, ob_max_age, ob_min_displacement_atr, ob_max_width_atr, ob_structure_left, ob_structure_right)
        return Signal(requested_mode, signal.side, signal.value, signal.reason, signal.metadata)
    return Signal(mode, None, 0.0, "STRATEGY_NOT_IMPLEMENTED", {})


def exit_signal(candles: list[Candle], side: Side, mode: str, exit_window: int) -> bool:
    if mode.upper() != "DONCHIAN" or len(candles) <= exit_window: return False
    history = candles[:-1][-exit_window:]; close = candles[-1].close
    return close < min(c.low for c in history) if side is Side.BUY else close > max(c.high for c in history)


__all__ = ["Signal", "time_series_momentum", "tsm_choch_retest", "donchian_breakout", "primary_signal", "exit_signal", "order_block_signal"]
