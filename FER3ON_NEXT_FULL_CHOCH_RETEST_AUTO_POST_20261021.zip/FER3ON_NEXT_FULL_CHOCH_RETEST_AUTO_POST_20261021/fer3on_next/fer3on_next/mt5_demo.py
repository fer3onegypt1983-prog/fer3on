from __future__ import annotations
from datetime import datetime, timezone
from datetime import timedelta
from .domain import AccountState, BotConfig, Candle, Decision, Side
from .execution import RiskError, validate_risk

class DemoOnlyError(RuntimeError): pass

class MT5DemoBroker:
    """Optional MT5 adapter. It refuses real accounts and live mode by design."""
    def __init__(self, symbol: str, deviation: int = 20):
        try:
            import MetaTrader5 as mt5
        except ImportError as e:
            raise RuntimeError('Install MetaTrader5 on the machine running the terminal') from e
        self.mt5=mt5; self.symbol=symbol; self.deviation=deviation
        self._position_management={}
        self._connect_and_verify_demo()

    def _connect_and_verify_demo(self):
        import os
        if os.getenv('FER3ON_MODE','').upper() != 'DEMO':
            raise DemoOnlyError('Set FER3ON_MODE=DEMO; live mode is not implemented here')
        if os.getenv('FER3ON_DEMO_CONFIRM','') != 'YES':
            raise DemoOnlyError('Set FER3ON_DEMO_CONFIRM=YES to acknowledge demo execution')
        if not self.mt5.initialize():
            raise RuntimeError(f'MT5 initialize failed: {self.mt5.last_error()}')
        info=self.mt5.account_info()
        if info is None:
            raise DemoOnlyError('Cannot verify account type; refusing to trade')
        demo_mode=getattr(self.mt5,'ACCOUNT_TRADE_MODE_DEMO',0)
        if getattr(info,'trade_mode',-1) != demo_mode:
            raise DemoOnlyError('Non-DEMO account detected; demo adapter refuses it')

    def candles(self, timeframe, count: int) -> list[Candle]:
        tf=getattr(self.mt5, f'TIMEFRAME_{timeframe}')
        rates=self.mt5.copy_rates_from_pos(self.symbol,tf,1,count)  # closed candles only
        if rates is None: raise RuntimeError(f'No rates: {self.mt5.last_error()}')
        out=[]
        names = getattr(getattr(rates, 'dtype', None), 'names', None) or ()
        for r in rates:
            tick_volume = r['tick_volume'] if 'tick_volume' in names else 0
            out.append(Candle(datetime.fromtimestamp(int(r['time']),tz=timezone.utc),float(r['open']),float(r['high']),float(r['low']),float(r['close']),float(tick_volume)))
        return out

    def account_state(self) -> AccountState:
        info=self.mt5.account_info()
        if info is None: raise RuntimeError('account_info unavailable')
        equity=float(info.equity)
        positions=self.mt5.positions_get(symbol=self.symbol)
        if positions is None:
            raise RuntimeError(f'positions_get failed: {self.mt5.last_error()}')
        return AccountState(equity,equity,open_trades=len(positions),bars_since_last_entry=0 if positions else 10_000)

    def paused_strategies(self, cfg: BotConfig):
        """Return strategies whose realized bot losses reached the configured pause limit."""
        if not cfg.enable_strategy_loss_pause or not hasattr(self.mt5,'history_deals_get'):
            return {}
        now=datetime.now(timezone.utc); start=now-timedelta(hours=cfg.strategy_loss_pause_hours)
        deals=self.mt5.history_deals_get(start,now) or []
        losses={}
        for d in deals:
            comment=str(getattr(d,'comment','') or '')
            if not comment.startswith('FER3ON_') or getattr(d,'entry',None) != getattr(self.mt5,'DEAL_ENTRY_OUT',1): continue
            parts=comment.split('_'); strategy=parts[1] if len(parts)>1 else 'UNKNOWN'
            pnl=float(getattr(d,'profit',0.0) or 0.0)+float(getattr(d,'swap',0.0) or 0.0)+float(getattr(d,'commission',0.0) or 0.0)
            losses[strategy]=losses.get(strategy,0.0)+pnl
        info=self.mt5.account_info(); equity=float(getattr(info,'equity',0.0) or 0.0) if info else 0.0
        threshold=equity*cfg.strategy_loss_pause_fraction
        return {s:p for s,p in losses.items() if p <= -threshold and threshold>0}

    def manage_positions(self, closed_price: float, cfg: BotConfig, logger=None):
        """Manage only FER3ON positions using the last closed candle."""
        if not cfg.enable_break_even:
            return []
        positions=self.mt5.positions_get(symbol=self.symbol)
        if positions is None:
            raise RuntimeError(f'positions_get failed during break-even: {self.mt5.last_error()}')
        info=self.mt5.symbol_info(self.symbol); tick=self.mt5.symbol_info_tick(self.symbol)
        if info is None or tick is None:
            raise RuntimeError('symbol info/tick unavailable during break-even')
        point=float(getattr(info,'point',0.0) or 0.0)
        digits=int(getattr(info,'digits',2) or 2)
        spread=max(0.0,float(tick.ask)-float(tick.bid))
        buffer=max(spread,point*cfg.break_even_buffer_points)
        moved=[]
        buy_type=getattr(self.mt5,'POSITION_TYPE_BUY',0)
        for p in positions:
            comment=str(getattr(p,'comment','') or '')
            if not comment.startswith('FER3ON_'): continue
            key=str(getattr(p,'ticket',''))
            side_buy=getattr(p,'type',None)==buy_type
            entry=float(getattr(p,'price_open',0.0) or 0.0)
            old_sl=float(getattr(p,'sl',0.0) or 0.0)
            tp=float(getattr(p,'tp',0.0) or 0.0)
            state=self._position_management.setdefault(key,{'initial_sl':old_sl,'be_done':False,'partial_done':False})
            risk=abs(entry-float(state['initial_sl'])) if state['initial_sl'] else 0.0
            if risk<=0: continue
            favorable=(float(closed_price)-entry) if side_buy else (entry-float(closed_price))
            if cfg.enable_break_even and not state['be_done'] and favorable >= cfg.break_even_trigger_r*risk:
                min_dist=max(float(getattr(info,'trade_stops_level',0) or 0)*point,float(getattr(info,'trade_freeze_level',0) or 0)*point)
                new_sl=round(entry+max(buffer,min_dist+point) if side_buy else entry-max(buffer,min_dist+point),digits)
                improves=(old_sl<=0 or new_sl>old_sl) if side_buy else (old_sl<=0 or new_sl<old_sl)
                valid=(new_sl < float(tick.bid)-min_dist) if side_buy else (new_sl > float(tick.ask)+min_dist)
                if improves and valid:
                    request={'action':self.mt5.TRADE_ACTION_SLTP,'symbol':self.symbol,'position':int(p.ticket),'sl':new_sl,'tp':tp}
                    result=self.mt5.order_send(request); done=getattr(self.mt5,'TRADE_RETCODE_DONE',10009)
                    if result is not None and getattr(result,'retcode',0)==done:
                        state['be_done']=True; moved.append((p.ticket,new_sl))
                        if logger: logger.stop_moved_to_be(p,old_sl,new_sl,cfg.break_even_trigger_r)
                    elif logger: logger.stop_modification_rejected(p,request,result)
            if cfg.enable_partial_profit and not state['partial_done'] and favorable >= cfg.partial_profit_trigger_r*risk:
                step=float(getattr(info,'volume_step',0.01) or 0.01); minimum=float(getattr(info,'volume_min',0.01) or 0.01)
                current_volume=float(getattr(p,'volume',0.0) or 0.0); close_volume=round((current_volume*cfg.partial_profit_fraction)//step*step,8)
                if close_volume>=minimum and close_volume<current_volume:
                    request={'action':self.mt5.TRADE_ACTION_DEAL,'symbol':self.symbol,'position':int(p.ticket),'volume':close_volume,
                             'type':self.mt5.ORDER_TYPE_SELL if side_buy else self.mt5.ORDER_TYPE_BUY,
                             'price':float(tick.bid if side_buy else tick.ask),'deviation':self.deviation,
                             'magic':260923,'comment':'FER3ON_PARTIAL_DEMO','type_time':self.mt5.ORDER_TIME_GTC,'type_filling':self.mt5.ORDER_FILLING_IOC}
                    result=self.mt5.order_send(request); done=getattr(self.mt5,'TRADE_RETCODE_DONE',10009)
                    if result is not None and getattr(result,'retcode',0)==done:
                        state['partial_done']=True
                        if logger: logger.partial_profit_taken(p,close_volume,cfg.partial_profit_trigger_r)
        return moved

    def send(self, decision: Decision, account: AccountState, cfg: BotConfig):
        risk=validate_risk(decision,account,cfg)
        tick=self.mt5.symbol_info_tick(self.symbol)
        if tick is None: raise RuntimeError('symbol tick unavailable')
        price=float(tick.ask if decision.side is Side.BUY else tick.bid)
        order_type=self.mt5.ORDER_TYPE_BUY if decision.side is Side.BUY else self.mt5.ORDER_TYPE_SELL
        info=self.mt5.symbol_info(self.symbol)
        if info is None: raise RuntimeError('symbol_info unavailable')
        minimum=max(float(getattr(info,'volume_min',0.01) or 0.01),0.01)
        maximum=float(getattr(info,'volume_max',minimum) or minimum)
        requested=float(decision.metadata.get('position_sizing',{}).get('unit_size',minimum) or minimum)
        volume=min(maximum,max(minimum,requested))
        step=float(getattr(info,'volume_step',volume) or volume)
        volume=round(round(volume/step)*step,8)
        point=float(getattr(info,'point',0.0) or 0.0)
        stops_level=float(getattr(info,'trade_stops_level',0.0) or 0.0)*point
        if stops_level>0 and abs(price-float(decision.stop))<stops_level:
            raise RiskError('stop is inside broker minimum distance')
        # A successful account_info() may still be followed by order_check
        # returning 10019 when the requested lot size consumes too much
        # free margin. Reserve 20% of free margin and reduce by broker steps.
        account_info=self.mt5.account_info()
        free_margin=float(getattr(account_info,'margin_free',0.0) or 0.0) if account_info else 0.0
        if account_info is None:
            raise RuntimeError('MT5 account_info unavailable before margin check')
        if free_margin <= 0:
            raise RuntimeError(f'MT5 reports no free margin before order_check: free_margin={free_margin:.2f}')
        calc_margin=getattr(self.mt5,'order_calc_margin',None)
        if calc_margin and free_margin>0:
            budget=free_margin*0.80
            while volume >= minimum:
                required=calc_margin(order_type,self.symbol,volume,price)
                if required is None or float(required)<=budget:
                    break
                next_volume=round(volume-step,8)
                if next_volume < minimum or next_volume >= volume:
                    volume=0.0
                    break
                volume=next_volume
            if volume < minimum:
                raise RuntimeError(f'Insufficient free margin for minimum volume {minimum}; free_margin={free_margin:.2f}')
        request={'action':self.mt5.TRADE_ACTION_DEAL,'symbol':self.symbol,'volume':volume,'type':order_type,'price':price,
                 'sl':float(decision.stop),'tp':float(decision.target),'deviation':self.deviation,
                 'magic':260923,'comment':f'FER3ON_{decision.strategy_id or "ACTIVE"}_DEMO','type_time':self.mt5.ORDER_TIME_GTC,
                 'type_filling':self.mt5.ORDER_FILLING_IOC}
        if hasattr(self.mt5,'order_check'):
            check=self.mt5.order_check(request)
            done=getattr(self.mt5,'TRADE_RETCODE_DONE',10009)
            # MT5 commonly returns retcode=0 (TRADE_RETCODE_CHECK_DONE)
            # for a successful order_check; 10009 is the successful deal
            # code used by order_send and may also be returned by wrappers.
            check_done=getattr(self.mt5,'TRADE_RETCODE_CHECK_DONE',0)
            accepted_check_codes={0, check_done, done}
            if check is None or getattr(check,'retcode',None) not in accepted_check_codes:
                raise RuntimeError(f'DEMO order_check rejected: {check}')
        result=self.mt5.order_send(request)
        if result is None or getattr(result,'retcode',0) != self.mt5.TRADE_RETCODE_DONE:
            raise RuntimeError(f'DEMO order rejected: {result}')
        return result
