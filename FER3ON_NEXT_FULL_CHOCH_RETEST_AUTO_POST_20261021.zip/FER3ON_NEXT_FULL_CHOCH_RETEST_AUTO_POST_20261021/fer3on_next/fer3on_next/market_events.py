from __future__ import annotations
from dataclasses import dataclass
from .domain import Candle
from .structure import StructureSnapshot, Label

@dataclass(frozen=True)
class FVG:
    direction: str
    low: float
    high: float
    created_index: int
    filled: float

@dataclass(frozen=True)
class MarketEvent:
    name: str
    direction: str
    level: float|None
    confirmed: bool
    retest: bool
    continuation_score: float
    reversal_score: float
    reason: str

def find_fvgs(candles: list[Candle], max_items: int=12) -> list[FVG]:
    out=[]
    for i in range(2,len(candles)):
        a,b,c=candles[i-2:i+1]
        if a.high<c.low: out.append(FVG('BUY',a.high,c.low,i,0.0))
        elif a.low>c.high: out.append(FVG('SELL',c.high,a.low,i,0.0))
    return out[-max_items:]

def detect_events(candles: list[Candle], structure: StructureSnapshot, atr_value: float) -> list[MarketEvent]:
    if len(candles)<4 or atr_value<=0: return []
    c=candles[-1]; prev=candles[-2]; events=[]
    high=structure.last_high; low=structure.last_low
    if high and c.close>high.price:
        retest=prev.high>=high.price and c.low<=high.price+atr_value*.2
        events.append(MarketEvent('BOS','BUY',high.price,True,retest,.82 if retest else .60,.20,'close above confirmed swing high'))
    if low and c.close<low.price:
        retest=prev.low<=low.price and c.high>=low.price-atr_value*.2
        events.append(MarketEvent('BOS','SELL',low.price,True,retest,.82 if retest else .60,.20,'close below confirmed swing low'))
    labels=[p.label for p in structure.points[-6:] if p.label]
    if Label.LL in labels[-2:] and c.close>prev.high:
        events.append(MarketEvent('CHOCH','BUY',prev.high,True,True,.70,.45,'down structure failed and price reclaimed'))
    if Label.HH in labels[-2:] and c.close<prev.low:
        events.append(MarketEvent('CHOCH','SELL',prev.low,True,True,.70,.45,'up structure failed and price lost'))
    for f in find_fvgs(candles):
        inside=f.low<=c.close<=f.high or (f.direction=='BUY' and c.low<=f.high and c.close>f.high) or (f.direction=='SELL' and c.high>=f.low and c.close<f.low)
        if inside:
            events.append(MarketEvent('FVG',f.direction,(f.low+f.high)/2,True,True,.68,.42,'price reacted at fair value gap'))
    return events

def select_event(events: list[MarketEvent], direction: str) -> MarketEvent|None:
    xs=[e for e in events if e.direction==direction and e.confirmed]
    if not xs: return None
    return max(xs,key=lambda e:(e.retest,e.continuation_score))
