from __future__ import annotations
from dataclasses import dataclass
from .domain import Candle
from .market import atr
from .structure import analyze_structure
from .trend import infer_trend

@dataclass(frozen=True)
class TimeframeView:
    name: str
    candles: int
    direction: str
    phase: str
    confidence: float

def aggregate(candles: list[Candle], factor: int) -> list[Candle]:
    out=[]
    for i in range(0,len(candles)-factor+1,factor):
        chunk=candles[i:i+factor]
        out.append(Candle(chunk[0].time,chunk[0].open,max(x.high for x in chunk),min(x.low for x in chunk),chunk[-1].close,sum(x.volume for x in chunk)))
    return out

def timeframe_views(candles: list[Candle]) -> dict[str,TimeframeView]:
    views={}
    for name,factor in (('H1',4),('H4',16)):
        xs=aggregate(candles,factor)
        if len(xs)<8:
            views[name]=TimeframeView(name,len(xs),'UNKNOWN','INSUFFICIENT',0.0); continue
        s=analyze_structure(xs,1,1); t=infer_trend(s)
        views[name]=TimeframeView(name,len(xs),t.direction,t.phase,t.confidence)
    return views
