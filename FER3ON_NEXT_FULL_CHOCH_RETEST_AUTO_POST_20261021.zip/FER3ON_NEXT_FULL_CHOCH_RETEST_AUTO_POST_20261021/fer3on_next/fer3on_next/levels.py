from __future__ import annotations
from dataclasses import dataclass
from .structure import PivotKind, StructureSnapshot

@dataclass(frozen=True)
class PriceZone:
    kind: str
    low: float
    high: float
    touches: int
    source: str
    strength: float
    @property
    def midpoint(self): return (self.low+self.high)/2

def build_zones(structure: StructureSnapshot, atr_value: float, merge_atr: float=0.35) -> list[PriceZone]:
    width=max(atr_value*merge_atr,1e-8)
    candidates=[]
    for p in structure.points:
        kind='RESISTANCE' if p.kind is PivotKind.HIGH else 'SUPPORT'
        candidates.append([kind,p.price-width/2,p.price+width/2,1,p.label.value if p.label else 'PIVOT',p.strength])
    zones=[]
    for item in sorted(candidates,key=lambda x:x[1]):
        if zones and zones[-1].kind==item[0] and item[1] <= zones[-1].high+width:
            old=zones[-1]; low=min(old.low,item[1]); high=max(old.high,item[2]); touches=old.touches+1
            strength=min(1.0,(old.strength+item[5])/2+0.08)
            zones[-1]=PriceZone(old.kind,low,high,touches,old.source+'+'+item[4],strength)
        else: zones.append(PriceZone(item[0],item[1],item[2],item[3],item[4],item[5]))
    return zones

def nearest_level(zones: list[PriceZone], price: float, kind: str, direction: str) -> PriceZone|None:
    candidates=[z for z in zones if z.kind==kind and (z.low>price if direction=='ABOVE' else z.high<price)]
    if not candidates: return None
    return min(candidates,key=lambda z:abs(z.midpoint-price))

def level_context(zones: list[PriceZone], price: float) -> dict:
    support=nearest_level(zones,price,'SUPPORT','BELOW')
    resistance=nearest_level(zones,price,'RESISTANCE','ABOVE')
    return {'support':support,'resistance':resistance,'inside_zone':next((z for z in zones if z.low<=price<=z.high),None)}
