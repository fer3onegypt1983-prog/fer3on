from __future__ import annotations
from datetime import datetime, timezone
from uuid import uuid4

BUILD_ID = "FER3ON-NEXT-0.1.0"
SCHEMA_VERSION = "trade-ledger.v2"


def new_run_id(prefix: str = "backtest") -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}-{stamp}-{uuid4().hex[:8]}"


def data_source_for(mode: str, source: str | None = None) -> str:
    if source:
        return source
    return {
        "backtest": "historical_ohlcv",
        "walk_backtest": "historical_ohlcv_walk_forward",
        "demo": "mt5_demo",
        "paper": "paper_broker",
    }.get(mode, "unknown")
