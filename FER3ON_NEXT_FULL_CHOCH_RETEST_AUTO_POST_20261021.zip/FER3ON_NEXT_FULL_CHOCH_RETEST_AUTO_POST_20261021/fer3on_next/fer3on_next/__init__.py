"""FER3ON Next: a single-path, test-first trading research engine."""
from .domain import BotConfig, Candle, Decision, Trade
from .strategy import decide, decide_candidates
from .structure import analyze_structure
from .trend import infer_trend
from .levels import build_zones
from .primary_signals import Signal, primary_signal
from .position_sizing import PositionPlan, build_position_plan
from .acceptance import AcceptancePolicy, evaluate_walk_forward

__all__ = ["BotConfig", "Candle", "Decision", "Trade", "decide", "decide_candidates", "analyze_structure", "infer_trend", "build_zones", "Signal", "primary_signal", "PositionPlan", "build_position_plan", "AcceptancePolicy", "evaluate_walk_forward"]
