from __future__ import annotations
from dataclasses import dataclass
from .domain import Candle
from .structure import PivotKind, StructureSnapshot

@dataclass(frozen=True)
class LiquidityPool:
    kind: str
    price: float
    count: int
    tolerance: float
    source: str

@dataclass(frozen=True)
class LiquidityEvent:
    event: str
    direction: str
    pool_price: float|None
    strength: float

def find_equal_pools(structure: StructureSnapshot, atr_value: float, tolerance_atr: float=.20) -> list[LiquidityPool]:
    tol=max(atr_value*tolerance_atr,1e-8); pools=[]
    for kind in (PivotKind.HIGH,PivotKind.LOW):
        pts=[p for p in structure.points if p.kind is kind]
        for p in pts:
            near=[q for q in pts if abs(q.price-p.price)<=tol]
            if len(near)>=2:
                pools.append(LiquidityPool('EQUAL_HIGH' if kind is PivotKind.HIGH else 'EQUAL_LOW',sum(q.price for q in near)/len(near),len(near),tol,'CONFIRMED_PIVOTS'))
    unique=[]
    for p in pools:
        if not any(p.kind==q.kind and abs(p.price-q.price)<=p.tolerance for q in unique): unique.append(p)
    return unique

def detect_sweep(candles: list[Candle], pools: list[LiquidityPool], atr_value: float) -> LiquidityEvent:
    if not candles or not pools: return LiquidityEvent('NONE','NONE',None,0)
    c=candles[-1]
    for p in pools:
        if p.kind=='EQUAL_LOW' and c.low<p.price and c.close>p.price:
            return LiquidityEvent('SELL_SIDE_SWEEP','BUY',p.price,min(1.0,(c.close-p.price)/max(atr_value,1e-9)))
        if p.kind=='EQUAL_HIGH' and c.high>p.price and c.close<p.price:
            return LiquidityEvent('BUY_SIDE_SWEEP','SELL',p.price,min(1.0,(p.price-c.close)/max(atr_value,1e-9)))
    return LiquidityEvent('NONE','NONE',None,0)
