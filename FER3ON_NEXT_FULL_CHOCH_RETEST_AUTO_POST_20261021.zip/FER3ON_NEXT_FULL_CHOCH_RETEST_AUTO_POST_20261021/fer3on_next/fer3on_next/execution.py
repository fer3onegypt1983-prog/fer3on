from __future__ import annotations
from dataclasses import dataclass, field
from .domain import AccountState, BotConfig, Decision, Side, Trade

class RiskError(ValueError): pass


def validate_risk(decision: Decision, account: AccountState, cfg: BotConfig) -> float:
    if decision.action != "ENTER" or not decision.side or decision.entry is None or decision.stop is None or decision.target is None:
        raise RiskError("decision is not executable")
    if account.open_trades >= cfg.max_concurrent:
        raise RiskError("position limit")
    daily_limit = min(account.day_start_equity * cfg.max_daily_loss, cfg.max_daily_loss_cash)
    if account.daily_loss_cash >= daily_limit:
        raise RiskError("daily loss limit")
    distance = abs(decision.entry - decision.stop)
    if distance <= 0:
        raise RiskError("invalid stop distance")
    if decision.side is Side.BUY and not (decision.stop < decision.entry < decision.target):
        raise RiskError("BUY geometry invalid")
    if decision.side is Side.SELL and not (decision.target < decision.entry < decision.stop):
        raise RiskError("SELL geometry invalid")
    return account.equity * decision.risk_fraction

@dataclass
class PaperBroker:
    equity: float
    open_trades: dict[str, Trade] = field(default_factory=dict)
    last_keys: set[str] = field(default_factory=set)

    def enter(self, decision: Decision, account: AccountState, cfg: BotConfig) -> Trade:
        risk = validate_risk(decision, account, cfg)
        if decision.idempotency_key in self.last_keys:
            raise RiskError("duplicate decision key")
        self.last_keys.add(decision.idempotency_key)
        trade = Trade(decision.metadata.get("time", None), None, decision.side, decision.entry,
                      decision.stop, decision.target, None, risk, None, "OPEN", decision.idempotency_key,
                      decision.metadata.copy(), decision.build_id, decision.run_id, decision.data_source,
                      decision.strategy_id or decision.metadata.get("strategy_id", "UNKNOWN"))
        self.open_trades[decision.idempotency_key] = trade
        account.open_trades = len(self.open_trades)
        return trade

    def on_candle(self, candle, account: AccountState) -> list[Trade]:
        closed=[]
        for key, trade in list(self.open_trades.items()):
            hit_stop = candle.low <= trade.stop if trade.side is Side.BUY else candle.high >= trade.stop
            hit_target = candle.high >= trade.target if trade.side is Side.BUY else candle.low <= trade.target
            if not hit_stop and not hit_target:
                continue
            if hit_stop:
                exit_price, reason = trade.stop, "STOP"
            else:
                exit_price, reason = trade.target, "TARGET"
            points = (exit_price-trade.entry) if trade.side is Side.BUY else (trade.entry-exit_price)
            risk_distance = abs(trade.entry-trade.stop)
            pnl = trade.risk_amount * points / risk_distance
            trade.exit_time, trade.exit, trade.pnl, trade.reason = candle.time, exit_price, pnl, reason
            trade.metadata['outcome'] = 'WIN' if pnl > 0 else 'LOSS' if pnl < 0 else 'FLAT'
            trade.metadata['exit_reason'] = reason
            trade.metadata['r_multiple'] = points / risk_distance if risk_distance else 0.0
            self.equity += pnl
            closed.append(trade)
            del self.open_trades[key]
            if pnl < 0:
                account.consecutive_losses += 1
                account.last_loss_thesis = str(trade.metadata.get('thesis_id') or '')
                account.last_loss_decision_key = trade.decision_key
                if account.consecutive_losses >= 3:
                    account.loss_pause = True
            elif pnl > 0:
                account.consecutive_losses = 0
                account.loss_pause = False
                account.last_loss_thesis = ''
                account.last_loss_decision_key = ''
        account.equity = self.equity
        account.open_trades = len(self.open_trades)
        if closed:
            account.bars_since_last_entry = 0
        return closed
