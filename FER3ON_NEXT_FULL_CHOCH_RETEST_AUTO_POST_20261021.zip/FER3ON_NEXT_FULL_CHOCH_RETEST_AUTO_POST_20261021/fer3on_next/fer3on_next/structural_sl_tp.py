from __future__ import annotations
from .domain import Candle, Side
from .levels import PriceZone
from .structure import StructureSnapshot

def structural_exit(side: Side, entry: float, atr_value: float, structure: StructureSnapshot, zones: list[PriceZone], rr: float=1.8) -> dict:
    buffer=max(atr_value*0.15,1e-8)
    if side is Side.BUY:
        anchor=structure.protected_low or structure.last_low
        if anchor is None: raise ValueError('no confirmed structural low')
        stop=anchor.price-buffer
        invalidation='break below protected HL / confirmed structural low'
        resist=[z for z in zones if z.kind=='RESISTANCE' and z.low>entry]
        next_res=min(resist,key=lambda z:z.midpoint-entry) if resist else None
        structural_target=(next_res.low-buffer) if next_res else None
        risk=entry-stop
        target=max(entry+risk*rr, entry+risk*1.35)
        if structural_target and structural_target>entry+risk*1.35: target=min(structural_target,entry+risk*rr)
    else:
        anchor=structure.protected_high or structure.last_high
        if anchor is None: raise ValueError('no confirmed structural high')
        stop=anchor.price+buffer
        invalidation='break above protected LH / confirmed structural high'
        supports=[z for z in zones if z.kind=='SUPPORT' and z.high<entry]
        next_sup=max(supports,key=lambda z:entry-z.midpoint) if supports else None
        structural_target=(next_sup.high+buffer) if next_sup else None
        risk=stop-entry
        target=entry-risk*rr
        if structural_target and structural_target<entry-risk*1.35: target=max(structural_target,entry-risk*rr)
    if risk<=0: raise ValueError('structural stop is on wrong side')
    return {'stop':stop,'target':target,'risk_distance':risk,'invalidation':invalidation,'anchor_index':anchor.index,'anchor_label':anchor.label.value if anchor.label else 'PIVOT'}
