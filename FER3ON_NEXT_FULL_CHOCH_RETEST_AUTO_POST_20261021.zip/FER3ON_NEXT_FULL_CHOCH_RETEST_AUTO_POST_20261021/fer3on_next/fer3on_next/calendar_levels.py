from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from datetime import timedelta
from .domain import Candle

@dataclass(frozen=True)
class ReferenceLevel:
    name: str
    price: float
    kind: str
    period: str

def _day_key(t): return t.date()
def _week_key(t): return (t.isocalendar().year,t.isocalendar().week)
def _session(t):
    h=t.hour
    if 0<=h<7: return 'ASIA'
    if 7<=h<13: return 'LONDON'
    if 13<=h<20: return 'NEWYORK'
    return 'OFF_HOURS'

def build_reference_levels(candles: list[Candle]) -> list[ReferenceLevel]:
    if not candles: return []
    days=defaultdict(list); weeks=defaultdict(list); sessions=defaultdict(list)
    for c in candles:
        days[_day_key(c.time)].append(c); weeks[_week_key(c.time)].append(c); sessions[(_day_key(c.time),_session(c.time))].append(c)
    cur_day=_day_key(candles[-1].time); cur_week=_week_key(candles[-1].time)
    levels=[]
    prev_days=[k for k in days if k<cur_day]
    if prev_days:
        d=max(prev_days); xs=days[d]; levels += [ReferenceLevel('PREVIOUS_DAY_HIGH',max(x.high for x in xs),'RESISTANCE',str(d)),ReferenceLevel('PREVIOUS_DAY_LOW',min(x.low for x in xs),'SUPPORT',str(d))]
    prev_weeks=[k for k in weeks if k<cur_week]
    if prev_weeks:
        w=max(prev_weeks); xs=weeks[w]; levels += [ReferenceLevel('PREVIOUS_WEEK_HIGH',max(x.high for x in xs),'RESISTANCE',str(w)),ReferenceLevel('PREVIOUS_WEEK_LOW',min(x.low for x in xs),'SUPPORT',str(w))]
    for name in ('ASIA','LONDON','NEWYORK'):
        keys=[k for k in sessions if k[1]==name and k[0]==cur_day]
        if keys:
            xs=sessions[keys[0]]
            levels += [ReferenceLevel(f'{name}_HIGH',max(x.high for x in xs),'RESISTANCE',str(cur_day)),ReferenceLevel(f'{name}_LOW',min(x.low for x in xs),'SUPPORT',str(cur_day))]
    return levels

def nearest_reference(levels: list[ReferenceLevel], price: float, side: str):
    kind='RESISTANCE' if side=='BUY' else 'SUPPORT'
    xs=[x for x in levels if x.kind==kind and ((x.price>price) if side=='BUY' else (x.price<price))]
    return min(xs,key=lambda x:abs(x.price-price)) if xs else None
