from __future__ import annotations
from dataclasses import dataclass
from .domain import Side

@dataclass(frozen=True)
class EntryQuality:
    velocity: float
    velocity_class: str
    late: bool
    hard_late: bool
    score: float
    reason: str

def assess_entry_quality(closes: list[float], atr_value: float, side: Side, location_percent: float) -> EntryQuality:
    if atr_value<=0 or len(closes)<6: return EntryQuality(0,'UNKNOWN',False,False,0,'INSUFFICIENT')
    velocity=abs(closes[-1]-closes[-6])/atr_value
    cls='WEAK' if velocity<.8 else 'NORMAL' if velocity<1.2 else 'STRONG' if velocity<1.8 else 'EXPLOSIVE'
    mid_chase=velocity>=.70 and .42<location_percent<.58
    directional_late=velocity>=1.20 and ((side is Side.BUY and location_percent>.58) or (side is Side.SELL and location_percent<.42))
    late=mid_chase or directional_late
    hard_late=velocity>=1.35
    score=max(0,min(100,70+velocity*8-(28 if late else 0)))
    reason='HARD_LATE' if hard_late else 'MID_CHASE' if mid_chase else 'LATE_AFTER_DISPLACEMENT' if directional_late else 'TIMING_ACCEPTED'
    return EntryQuality(velocity,cls,late,hard_late,score,reason)
