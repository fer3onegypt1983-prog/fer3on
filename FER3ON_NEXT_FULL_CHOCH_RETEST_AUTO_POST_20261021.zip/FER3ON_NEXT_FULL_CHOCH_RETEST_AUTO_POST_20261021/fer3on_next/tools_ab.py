from __future__ import annotations
import json,sys
from dataclasses import replace
from pathlib import Path
from fer3on_next.backtest import load_csv,run
from fer3on_next.domain import BotConfig
from fer3on_next.analytics import analyze_opportunities

def main():
    csv_path,report=sys.argv[1:]
    candles=load_csv(csv_path); base=BotConfig()
    baseline=run(candles,replace(base,enable_entry_quality_guard=False,enable_repeat_thesis_guard=False))
    guarded=run(candles,base)
    out={'method':'same_data_ab','baseline':{'trades':baseline['trade_count'],'wins':baseline['wins'],'losses':baseline['losses'],'net_pnl':baseline['net_pnl'],'max_drawdown':baseline['max_drawdown'],'analysis':analyze_opportunities(baseline['opportunities'])},'guarded':{'trades':guarded['trade_count'],'wins':guarded['wins'],'losses':guarded['losses'],'net_pnl':guarded['net_pnl'],'max_drawdown':guarded['max_drawdown'],'analysis':analyze_opportunities(guarded['opportunities'])}}
    Path(report).write_text(json.dumps(out,indent=2,default=str)); print(json.dumps(out,indent=2,default=str))
if __name__=='__main__': main()
