# سجل تفسير الصفقات

كل دورة قرار تنتج سجل `OPPORTUNITY` في JSONL. لا يتم تسجيل الصفقة فقط؛ يتم تسجيل الفرص المرفوضة أيضًا حتى نعرف ما الذي منعه النظام من الدخول.

## الحالات

| الحالة | المعنى |
|---|---|
| `REJECTED` | القرار لم يستوفِ بوابة من بوابات النواة، مثل تضارب الاتجاه أو عدم وجود حدث أو تكرار الأطروحة |
| `CANDIDATE` | قرار ENTER قبل محاولة التنفيذ |
| `NOT_FILLED` | القرار كان صالحًا لكن الوسيط الورقي/التنفيذ رفضه |
| `WIN` | صفقة منفذة وأغلقت بربح |
| `LOSS` | صفقة منفذة وأغلقت بخسارة |
| `FLAT` | صفقة منفذة وأغلقت دون ربح أو خسارة معتبرة |

## حقول سبب الدخول

لكل قرار ENTER تظهر الحقول التالية:

- `thesis_id`: هوية الأطروحة لمنع تكرار الفكرة بعد خسارتها.
- `entry_reasons`: اتجاه الصفقة، الاتجاه العام، الهيكل، الحدث، رد الفعل، الموقع، وحالة السوق.
- `metadata.forecast`: BOS/CHOCH/FVG والنمط واستمرار الحركة أو انعكاسها.
- `metadata.entry_quality`: velocity، تصنيف السرعة، late/mid chase، والسبب.
- `metadata.execution_quality`: درجة التنفيذ، RR، السبريد/ATR، وSL/ATR.
- `metadata.structure_bias` و`metadata.trend` و`metadata.mtf`.
- `metadata.liquidity` و`metadata.volume_profile` و`metadata.reference_levels`.
- `stop`, `target`, `invalidation`, و`risk_fraction`.

## حقول النتيجة

بعد الإغلاق تتم إضافة:

- `status`: `WIN` أو `LOSS` أو `FLAT`.
- `pnl`.
- `exit_reason`: `STOP` أو `TARGET`.
- `r_multiple`.
- `exit_time` و`exit`.

## تحليل النتائج

يولد `tools_walk.py` ملفين:

```text
reports/walk_*.json
reports/walk_*.ledger.jsonl
```

يحتوي ملف JSON على تجميع النتائج حسب:

- سبب الرفض.
- BOS/CHOCH/FVG.
- رد الفعل.
- حالة السوق.
- الموقع.
- الاتجاه.
- جودة الدخول.
- جودة التنفيذ.

ولا يجوز استنتاج جودة سبب من حالات `NOT_FILLED` كأنها خسائر؛ يتم فصلها عن `LOSS` في التحليل.
