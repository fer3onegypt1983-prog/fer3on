from __future__ import annotations
import csv, json, sys
from datetime import datetime, timezone
from pathlib import Path


def prepare(input_dir: str, output_dir: str, report_path: str) -> dict:
    src=Path(input_dir); out=Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    report={"source":str(src),"files":{}}
    for path in sorted(src.glob("XAU_*_data.csv")):
        timeframe=path.name.removeprefix("XAU_").removesuffix("_data.csv")
        target=out/f"xauusd_{timeframe}.csv"
        rows=0; valid=0; invalid=0; duplicates=0; previous=None; first=None; last=None
        with path.open(newline='',encoding='utf-8-sig') as f, target.open('w',newline='',encoding='utf-8') as g:
            reader=csv.DictReader(f, delimiter=';')
            writer=csv.DictWriter(g, fieldnames=['time','open','high','low','close','volume']); writer.writeheader()
            for raw in reader:
                rows += 1
                try:
                    t=datetime.strptime(raw['Date'].strip(), '%Y.%m.%d %H:%M').replace(tzinfo=timezone.utc)
                    o,h,l,c,v=(float(raw[k]) for k in ('Open','High','Low','Close','Volume'))
                    if not (l <= min(o,c) <= max(o,c) <= h and h >= l and h > 0): raise ValueError('OHLC geometry')
                    if previous is not None and t <= previous:
                        duplicates += 1
                        if t == previous: continue
                    previous=t; first=first or t; last=t; valid += 1
                    writer.writerow({'time':t.isoformat(),'open':o,'high':h,'low':l,'close':c,'volume':v})
                except Exception:
                    invalid += 1
        report['files'][timeframe]={'source':str(path),'output':str(target),'rows':rows,'valid_rows':valid,'invalid_rows':invalid,'duplicate_or_out_of_order_rows':duplicates,'first':first.isoformat() if first else None,'last':last.isoformat() if last else None}
    Path(report_path).write_text(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    if len(sys.argv)!=4: raise SystemExit('usage: tools_prepare_xauusd.py INPUT_DIR OUTPUT_DIR REPORT_JSON')
    print(json.dumps(prepare(*sys.argv[1:]),indent=2))
