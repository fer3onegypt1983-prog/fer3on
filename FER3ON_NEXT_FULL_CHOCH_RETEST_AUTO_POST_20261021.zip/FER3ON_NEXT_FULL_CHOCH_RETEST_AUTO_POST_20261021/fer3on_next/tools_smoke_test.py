from __future__ import annotations
import csv,json,sys
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from fer3on_next.domain import Candle
from fer3on_next.primary_signals import primary_signal

STRATEGIES=('FVG','ORDER_BLOCK','DONCHIAN')

def load(path):
    out=[]
    with open(path,newline='') as f:
        for r in csv.DictReader(f):
            out.append(Candle(datetime.fromisoformat(r['time']),float(r['open']),float(r['high']),float(r['low']),float(r['close']),float(r['volume'])))
    return out

def run_one(candles,name,tail,timeframe):
    start=max(0,len(candles)-tail); reasons=Counter(); sides=Counter(); qualified=[]; evaluated=0
    context_bars=300
    for i in range(max(80,start),len(candles),1):
        history=candles[max(0,i-context_bars+1):i+1]
        is_4h=timeframe=='4h'
        s=primary_signal(history,name,48,20,10,14,0.05,0.10,20,0.80,
                         30 if is_4h else 20, 0.45 if is_4h else 0.80, 2.25 if is_4h else 1.50,
                         1 if is_4h else 2, 1 if is_4h else 2)
        evaluated+=1; reasons[s.reason]+=1
        if s.side is not None:
            sides[s.side.value]+=1; qualified.append({'time':history[-1].time.isoformat(),'reason':s.reason,'side':s.side.value,'value':s.value,'metadata':s.metadata})
    return {'strategy':name,'evaluated':evaluated,'qualified_signals':len(qualified),'sides':dict(sides),'reason_counts':reasons.most_common(),'sample_signals':qualified[-10:]}

def main(root,out):
    report={'type':'SMOKE_TEST','purpose':'signal production only; no PnL claim','timeframes':{}}
    for tf in ('1h','4h'):
        candles=load(Path(root)/f'xauusd_{tf}.csv')
        # Approximately the last six months, but no fewer than 1500 bars when available.
        tail=min(len(candles), 4500 if tf=='1h' else 1500)
        report['timeframes'][tf]={'rows':len(candles),'tested_tail':tail,'first_test_time':candles[-tail].time.isoformat(),'last_test_time':candles[-1].time.isoformat(),'strategies':{n:run_one(candles,n,tail,tf) for n in STRATEGIES}}
    Path(out).write_text(json.dumps(report,indent=2,default=str)); return report

if __name__=='__main__':
    if len(sys.argv)!=3: raise SystemExit('usage: tools_smoke_test.py NORMALIZED_DIR REPORT_JSON')
    print(json.dumps(main(*sys.argv[1:]),indent=2,default=str))
