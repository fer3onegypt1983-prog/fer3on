from __future__ import annotations
import os, time
from hashlib import sha256
from pathlib import Path
from dataclasses import replace
from .domain import BotConfig
from .identity import new_run_id
from .strategy import decide_candidates
from .mt5_demo import MT5DemoBroker
from .live_trade_logging import LiveTradeLogger


def _active_fingerprint(decision) -> str:
    raw=f'{decision.strategy_id}|{decision.side}|{decision.stop:.2f}|{decision.target:.2f}'
    return sha256(raw.encode()).hexdigest()[:20]


def run_demo_once(cfg: BotConfig, broker: MT5DemoBroker, bars_since_last_entry: int = 10_000,
                  logger: LiveTradeLogger | None = None, submitted_fingerprints: set[str] | None = None):
    candles=broker.candles(cfg.timeframe,cfg.lookback+20)
    account=broker.account_state(); account.bars_since_last_entry=bars_since_last_entry
    paused=broker.paused_strategies(cfg)
    active=tuple(s for s in cfg.active_strategies if s.upper() not in paused)
    decisions=decide_candidates(candles,account,replace(cfg,active_strategies=active)); results=[]
    for decision in decisions:
        if logger: logger.decision(decision)
        if decision.action != 'ENTER': continue
        fingerprint=_active_fingerprint(decision)
        if submitted_fingerprints is not None and fingerprint in submitted_fingerprints:
            if logger: logger.duplicate_skipped(decision,fingerprint)
            print(f'[FER3ON_NEXT][DEMO] strategy={decision.strategy_id} order=DUPLICATE_SKIPPED fingerprint={fingerprint}')
            continue
        decision.metadata['time']=candles[-1].time
        try:
            result=broker.send(decision,account,cfg)
        except Exception as exc:
            if logger: logger.order_rejected(decision,exc)
            print(f'[FER3ON_NEXT][DEMO] strategy={decision.strategy_id} order=REJECTED error={exc}')
            continue
        if logger: logger.order_result(decision,result)
        if submitted_fingerprints is not None: submitted_fingerprints.add(fingerprint)
        results.append((decision,result)); account.open_trades += 1
        if account.open_trades >= cfg.max_concurrent: break
    broker.manage_positions(candles[-1].close,cfg,logger)
    return decisions,results


def run_demo_loop(cfg: BotConfig, interval_seconds: int = 60):
    broker=MT5DemoBroker(cfg.symbol); run_id=new_run_id('demo')
    journal_path=Path(os.getenv('FER3ON_DEMO_JOURNAL','reports/live_demo_ledger.jsonl'))
    if not journal_path.is_absolute():
        journal_path=Path(__file__).resolve().parent.parent / journal_path
    logger=LiveTradeLogger(journal_path,run_id=run_id,data_source='mt5_demo')
    print(f'[FER3ON_NEXT][DEMO] ledger={journal_path.resolve()}')
    bars_since_last_entry=10_000
    submitted_fingerprints=set()
    while True:
        decisions,results=run_demo_once(cfg,broker,bars_since_last_entry,logger,submitted_fingerprints)
        for decision in decisions:
            print(f'[FER3ON_NEXT][DEMO] strategy={decision.strategy_id} action={decision.action} reason={decision.reason} side={decision.side} key={decision.idempotency_key}')
        if results:
            for decision,result in results: print(f'[FER3ON_NEXT][DEMO] strategy={decision.strategy_id} order={result}')
            bars_since_last_entry=0
        else:
            bars_since_last_entry=min(10_000,bars_since_last_entry+1)
        time.sleep(interval_seconds)
